<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}
th{background: #333;color: #ffffff;font-weight: bold;}
td, th{padding: 6px;border:2px solid #0000ff;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #0000ff;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Plan Name";}
td:nth-of-type(3):before{content: "Details";}
td:nth-of-type(4):before{content: "Action";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<?php
$insid=$_GET['asin'];
$result_policy=$dbh->prepare("select * from scrap where type='policy' and item4=:memid");
$result_policy->bindParam(":memid",$insid);
$result_policy->execute();
$row_policy=$result_policy->fetchObject();
$count_policy=$result_policy->rowCount();

?>
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h3 class="card-title text-center"><b><?php if($count_policy>0){echo $row_policy->item2; } ?></b></h3></div>
<div class="card-body">
<span><?php echo $row_policy->item3; ?><a href='policy_abouts.php?policy=<?php echo $row_policy->item; ?>' class='btn btn-sm btn-info'>Learn More</a></span>
<div class="col-lg-12"><br></div>
<div class="col-lg-12"><h4 class="card-title"><b><?php if($count_policy>0){echo $row_policy->item2; } ?> Plans</b></h4></div>
<table>
<thead>
<tr>
<th>No</th>
<th>Insurance Plan</th>
<th>Details</th>
<th>Action</th>
</tr>  
</thead>  
<?php
$result_scrap=$dbh->query("select * from scrap where type='plan' and item3='$row_policy->item' order  by item2 asc"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
echo "<tr>
<td>.".$r++."</td>
<td><span style='color:maroon;'>[".$row_scrap->item2."]</span></td>
<td>".$row_scrap->item4."</td>
<td><a href='plan_packages.php?planid=".$row_scrap->item."&&name=".$row_scrap->item2."' class='btn btn-sm btn-success btn-block'>View Packages</a></td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}
else{echo "<div>Display Directly Payment Details</div>";}
?>
</table>
</div>
</div>
</div>   
<?php lscripts(); ?>

</body>
</html>