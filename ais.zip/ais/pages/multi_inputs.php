<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="container-fluid">
  <div class="card-header"><h4 class="card-title" style="color: maroon;font-weight: bold;">Roles, Premiums & Localities</h4></div>  
<div class="row">
<div class="col-lg-4">
  <div class="card">
<div class="card-header"><h4 class="card-title"><b>New Roles</b></h4></div>
<div class="card-body"> 
<?php
if(isset($_POST["submit_role"])){
$title=$_POST["title"];
$role=$_POST["role"];

$insert_scrap=$dbh->query("insert into scrap (item,item2,type) values('$title','$role','role')");
if($insert_scrap){echo"<div class='alert alert-success'>Success: New Role Created</div>";}else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
 <div class="row">
<div class='col-lg-6'>
<input type='text' class='form-control' name='title' placeholder='Title' required>
</div>
<div class='col-lg-6'>
<input type='text' class='form-control' name='role' placeholder='Role Initials' required>
</div></div>
<br>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_role" value="Submit">
</div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#carmake" aria-expanded="false" aria-controls="collapseExample">
View Role(s)
</button>

<div class="collapse" id="carmake">
<div class="card card-body">
<table class="table">
<tr>
<th>No</th>
<th>Role(s)</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='role'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();

if($count_scrap>0){ $r=1; do{
echo "<tr>
<td>".$r++."</td>
<td>".$row_scrap->item."</td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div></div> 
<div class="col-lg-4">
  <div class="card">
<div class="card-header"><h4 class="card-title"><b>Localities</b></h4></div>
<div class="card-body"> 
<?php
if(isset($_POST["submit_locations"])){
$location_name=$_POST["location_name"];
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$locid="loc".$fyy.$mm.$dd.$hi.$mi.$fsa;
$insert_scrap=$dbh->query("insert into scrap (item,item2,type) values('$locid','$location_name','loc')");
if($insert_scrap){echo "<div class='alert alert-success'>Success: Location Added</div>";}else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class='form-group'>
<input type='text' class='form-control' name='location_name' placeholder='Location Name' required>
</div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_locations" value="Submit">
</div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#loc" aria-expanded="false" aria-controls="collapseExample">
View Location(s)
</button>

<div class="collapse" id="loc">
<div class="card card-body">
<table class="table">
<tr>
<th>No</th>
<th>Location</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='loc'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();

if($count_scrap>0){ $r=1; do{
echo "<tr>
<td>".$r++."</td>
<td>".$row_scrap->item2."</td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div></div> 
<div class="col-lg-4">
<div class="card">
<div class="card-header"><h3 class="card-title"><b>Premium Terms</b></h3></div>
<div class="card-body">
<?php
if(isset($_POST["submit_term"])){
$term_name=$_POST["term_name"];
$term_num=$_POST["term_num"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $tmid="tm10"; }else{
$tmid="tm10".($row_scrap->autoid+1);
}
$insert_insp=$dbh->query("insert into scrap (item,item2,item3,type) values('$tmid','$term_name','$term_num','prem_term')");
if($insert_insp){echo "<div class='alert alert-success'>Success: New Premium Term Added</div>";}else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class='form-group'>
<input type='text' class='form-control' name='term_name' placeholder='Term Name' required></div>
<div class='form-group'>
<input type='text' class='form-control' name='term_num' placeholder='Number Of Months' required></div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success btn-block" name="submit_term" value="Submit"></div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#prem" aria-expanded="false" aria-controls="collapseExample">
View Term(s)
</button>

<div class="collapse" id="prem">
<div class="card card-body">
<table class="table">
<tr>
<th>No</th>
<th>Term</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='prem_term'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();

if($count_scrap>0){ $r=1; do{
echo "<tr>
<td>".$r++."</td>
<td>".$row_scrap->item2."</td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div></div>
</div>
<div class="col-lg-12"><br></div>
<div class="card-header"><h4 class="card-title" style="color: maroon;font-weight: bold;">Nominees & Branches</h4></div>
<div class="row">
<div class="col-lg-4">
<div class="card">
<div class="card-header"><h4 class="card-title"><b>Nominee Relationships</b></h4></div>
  <div class="card-body">        
<?php
if(isset($_POST["submit_xships"])){
$xship_name=$_POST["xship_name"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $relid="xsp10"; }else{
$relid="xsp10".($row_scrap->autoid+1); }
$insert_scrap=$dbh->query("insert into scrap (item,item2,type) values('$relid','$xship_name','nom_rels')");
if($insert_scrap){echo "<div class='alert alert-success'>Success : Relationship Added</div>";}else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class='form-group'>
<input type='text' class='form-control' name='xship_name' placeholder='Relationship Name' required>
</div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_xships" value="Submit">
</div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#nom" aria-expanded="false" aria-controls="collapseExample">
View Relation(s)
</button>

<div class="collapse" id="nom">
<div class="card card-body">
<table class="table">
<tr>
<th>No</th>
<th>Relationship</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='nom_rels'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();

if($count_scrap>0){ $r=1; do{
echo "<tr>
<td>".$r++."</td>
<td>".$row_scrap->item2."</td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div> </div>

<div class="col-lg-4">
<div class="card">
<div class="card-header"><h4 class="card-title"><b>Nominee Priorities</b></h4></div>
  <div class="card-body">        
<?php
if(isset($_POST["submit_priors"])){
$prior_name=$_POST["prior_name"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $relid="pr10"; }else{
$relid="pr10".($row_scrap->autoid+1); }
$insert_scrap=$dbh->query("insert into scrap (item,item2,type) values('$relid','$prior_name','priors')");
if($insert_scrap){echo "<div class='alert alert-success'>Success : Priority Added</div>";}else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class='form-group'>
<input type='text' class='form-control' name='prior_name' placeholder='Priority' required>
</div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_priors" value="Submit">
</div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#pro" aria-expanded="false" aria-controls="collapseExample">
View Priorities
</button>

<div class="collapse" id="pro">
<div class="card card-body">
<table class="table">
<tr>
<th>No</th>
<th>Priority</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='priors'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();

if($count_scrap>0){ $r=1; do{
echo "<tr>
<td>".$r++."</td>
<td>".$row_scrap->item2."</td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div> </div>  

<div class="col-lg-4">
<div class="card">
<div class="card-header"><h4 class="card-title"><b>New Branches</b></h4></div>
  <div class="card-body">        
<?php
if(isset($_POST["submit_branch"])){
$locality=$_POST["locality"];
$branch_name=$_POST["branch_name"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $brid="brc10"; }else{
$brid="brc10".($row_scrap->autoid+1); }
$insert_scrap=$dbh->query("insert into scrap (item,item2,item3,type) values('$brid','$branch_name','$locality','branch')");
if($insert_scrap){echo "<div class='alert alert-success'>Success : New Branch Added</div>";}else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class="form-group">
<select name="locality" class="form-control">
<option>Select Location</option>  
<?php
$result_loc=$dbh->query("select * from scrap where type='loc' order by item2 asc");
$count_loc=$result_loc->rowCount();
$row_loc=$result_loc->fetchObject();
if($count_loc>0){do{
echo "<option value='".$row_loc->item."'>".$row_loc->item2."</option>";  
}while($row_loc=$result_loc->fetchObject());}
?>
</select>
</div>
<div class='form-group'>
<input type='text' class='form-control' name='branch_name' placeholder='Branch Name' required>
</div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_branch" value="Submit">
</div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#bra" aria-expanded="false" aria-controls="collapseExample">
View Branches
</button>

<div class="collapse" id="bra">
<div class="card card-body">
<table class="table">
<tr>
<th>No</th>
<th>Branch</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='branch'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
$result_loc=$dbh->query("select * from scrap where type='loc' and item='$row_scrap->item3'"); 
$row_loc=$result_loc->fetchObject(); 
$count_loc=$result_loc->rowCount();  
echo "<tr>
<td>".$r++."</td>
<td>".$row_scrap->item2."<br><span style='color:maroon'>[".$row_loc->item2." Branch]</span></td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div> </div>

</div> 
<div class="col-lg-12"><br></div>
<div class="card-header"><h4 class="card-title" style="color: maroon;font-weight: bold;">Policies & Guidelines</h4></div>
<div class="row">
<div class="col-lg-8">
<div class="card">
<div class="card-header"><h3 class="card-title"><b>Insurance Policies</b></h3></div>
<div class="card-body">
<?php
if(isset($_POST["submit_inspol"])){
$policy_name=$_POST["policy_name"];
$policy_dets=addslashes($_POST["policy_dets"]);
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $polid="pol10"; }else{
$polid="pol10".($row_scrap->autoid+1);
}
$insert_insp=$dbh->query("insert into scrap (item,item2,item3,type) values('$polid','$policy_name','$policy_dets','policy')");
if($insert_insp){echo "<div class='alert alert-success'>Success: New Policy Added</div>";}
else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class='form-group'>
<input type='text' class='form-control' name='policy_name' placeholder='Insurance Policy Name' required></div>
<div class='form-group'>
<textarea class='form-control para' name='policy_dets' placeholder='Insurance Plan Details' rows="10"></textarea></div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success btn-block" name="submit_inspol" value="Submit"></div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#pols" aria-expanded="false" aria-controls="collapseExample">
View Policies
</button>

<div class="collapse" id="pols">
<div class="card card-body">
<table class="table table-striped">
<tr>
<th>No</th>
<th>policy</th>
<th width="90%">Details</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='policy'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
echo "<tr>
<td>".$r++.".</td>
<td><b>".$row_scrap->item2."</b></td>
<td>".$row_scrap->item3."</td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div></div>

<div class="col-lg-4">
<div class="card">
<div class="card-header"><h3 class="card-title"><b>Insurance Guidelines & Tips</b></h3></div>
<div class="card-body">
<?php
if(isset($_POST["submit_guide"])){
$insurance_guideline=$_POST["insurance_guideline"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $polid="gds10"; }else{
$polid="gds10".($row_scrap->autoid+1);
}
$insert_insp=$dbh->query("insert into scrap (item,item2,type) values('$polid','$insurance_guideline','guide')");
if($insert_insp){echo "<div class='alert alert-success'>Success: New Guideline Added</div>";}
else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class='form-group'>
<textarea class='form-control para' name='insurance_guideline' placeholder='Insurance Guideline Details' rows="9"></textarea></div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success btn-block" name="submit_guide" value="Submit"></div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#tps" aria-expanded="false" aria-controls="collapseExample">
View Insurance Tips
</button>

<div class="collapse" id="tps">
<div class="card card-body">
<table class="table table-striped">
<tr>
<th>No</th>
<th>Tip/Guideline</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='guide'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
echo "<tr>
<td>".$r++."</td>
<td>".$row_scrap->item2."</td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div></div>
</div> 
<div class="col-lg-12"><br></div>
<div class="card-header"><h4 class="card-title" style="color: maroon;font-weight: bold;">Insurance Plans & Packages</h4></div>
<div class="row">
<div class="col-lg-8">
<div class="card">
<div class="card-header"><h3 class="card-title"><b>Insurance Plans</b></h3></div>
<div class="card-body">
<?php
if(isset($_POST["submit_insplan"])){
$plan_name=$_POST["plan_name"];
$plan_type=$_POST["plan_type"];
$plan_dets=addslashes($_POST["plan_dets"]);
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $polid="pln10"; }else{
$polid="pln10".($row_scrap->autoid+1);
}
$insert_insp=$dbh->query("insert into scrap (item,item2,item3,item4,type) values('$polid','$plan_name','$plan_type','$plan_dets','plan')");
if($insert_insp){echo "<div class='alert alert-success'>Success: New Plan Added</div>";}
else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class="row">
<div class="col-lg-6">
<select name="plan_type" class="form-control">
<option>Select Plan Type</option>  
<?php
$result_pt=$dbh->query("select * from scrap where type='policy' order by item2 asc");
$count_pt=$result_pt->rowCount();
$row_pt=$result_pt->fetchObject();
if($count_pt>0){do{
echo "<option value='".$row_pt->item."'>".$row_pt->item2."</option>";  
}while($row_pt=$result_pt->fetchObject());}
?>
</select>
</div>  
<div class='col-lg-6'>
<input type='text' class='form-control' name='plan_name' placeholder='Insurance Plan Name' required></div>
</div><div class="col-lg-12"><br></div>
<div class='form-group'>
<textarea class='form-control' name='plan_dets' placeholder='Insurance Plan Details' rows="5"></textarea></div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success btn-block" name="submit_insplan" value="Submit"></div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#pln" aria-expanded="false" aria-controls="collapseExample">
View Insurance Plan(s)
</button>

<div class="collapse" id="pln">
<div class="card card-body">
<table class="table table-striped">
<tr>
<th>No</th>
<th>Insurance Plan</th>
<th>Details</th>
</tr>
<?php
$pets = $dbh->query("select * from scrap where type='plan'");
$total_pages=$pets->rowCount();
// Check if the page number is specified and check if it's a number, if not return the default page number which is 1.
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;

// Number of results to show on each page.
$num_results_on_page = 6;

$calc_page = ($page - 1) * $num_results_on_page;
$result_scrap=$dbh->query("select * from scrap where type='plan' order  by item3 asc limit $calc_page, $num_results_on_page"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_scrap->item3'"); 
$row_pol=$result_pol->fetchObject(); 
$count_pol=$result_pol->rowCount();  
echo "<tr>
<td>".$calc_page++."</td>
<td>".$row_scrap->item2."<br><span style='color:maroon'>[".$row_pol->item2." Branch]</span></td>
<td>".$row_scrap->item4."</td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
<!--pagination-->
<?php if (ceil($total_pages / $num_results_on_page) > 0): ?>
<ul class="pagination">
  <?php if ($page > 1): ?>
  <li class="prev"><a href="multi_inputs.php?page=<?php echo $page-1 ?>">Prev</a></li>
  <?php endif; ?>

  <?php if ($page > 3): ?>
  <li class="start"><a href="multi_inputs.php?page=1">1</a></li>
  <li class="dots">...</li>
  <?php endif; ?>

  <?php if ($page-2 > 0): ?><li class="page"><a href="multi_inputs.php?page=<?php echo $page-2 ?>"><?php echo $page-2 ?></a></li><?php endif; ?>
  <?php if ($page-1 > 0): ?><li class="page"><a href="multi_inputs.php?page=<?php echo $page-1 ?>"><?php echo $page-1 ?></a></li><?php endif; ?>

  <li class="currentpage"><a href="multi_inputs.php?page=<?php echo $page ?>"><?php echo $page ?></a></li>

  <?php if ($page+1 < ceil($total_pages / $num_results_on_page)+1): ?><li class="page"><a href="multi_inputs.php?page=<?php echo $page+1 ?>"><?php echo $page+1 ?></a></li><?php endif; ?>
  <?php if ($page+2 < ceil($total_pages / $num_results_on_page)+1): ?><li class="page"><a href="multi_inputs.php?page=<?php echo $page+2 ?>"><?php echo $page+2 ?></a></li><?php endif; ?>

  <?php if ($page < ceil($total_pages / $num_results_on_page)-2): ?>
  <li class="dots">...</li>
  <li class="end"><a href="multi_inputs.php?page=<?php echo ceil($total_pages / $num_results_on_page) ?>"><?php echo ceil($total_pages / $num_results_on_page) ?></a></li>
  <?php endif; ?>

  <?php if ($page < ceil($total_pages / $num_results_on_page)): ?>
  <li class="next"><a href="multi_inputs.php?page=<?php echo $page+1 ?>">Next</a></li>
  <?php endif; ?>
</ul>
<?php endif; ?>
<!--end of pagination-->
</div>
</div>
</div>
</div></div>
<div class="col-lg-4">
<div class="card">
<div class="card-header"><h4 class="card-title"><b>Billing Packages</b></h4></div>
  <div class="card-body">        
<?php
if(isset($_POST["submit_pack"])){
$package_name=$_POST["package_name"];
$package_num=$_POST["package_num"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $relid="pk10"; }else{
$relid="pk10".($row_scrap->autoid+1); }
$insert_scrap=$dbh->query("insert into scrap (item,item2,item3,type) values('$relid','$package_name','$package_num','pac')");
if($insert_scrap){echo "<div class='alert alert-success'>Success : Package Added</div>";}else{echo"<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<form method="post" autocomplete="off">
<div class='form-group'>
<input type='text' class='form-control' name='package_name' placeholder='Package Name' required>
</div>
<div class='form-group'>
<input type='number' class='form-control' name='package_num' placeholder='Number Of People' required>
</div>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_pack" value="Submit">
</div>
</form>
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#pac" aria-expanded="false" aria-controls="collapseExample">
View Insurance Packages
</button>

<div class="collapse" id="pac">
<div class="card card-body">
<table class="table">
<tr>
<th>No</th>
<th>Package</th>
</tr>
<?php
$result_scrap=$dbh->query("select * from scrap where type='pac'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
  if($row_scrap->item3<=1){$ident="person";}
  else{$ident="people";}
echo "<tr>
<td>".$r++."</td>
<td>".$row_scrap->item2."<br><span style='color:maroon'>[".$row_scrap->item3."] ".$ident."</span></td>
</tr>";
}while($row_scrap=$result_scrap->fetchObject());}


?>
</table>
</div>
</div>
</div>
</div> </div>  
</div> 
<?php lscripts(); ?>
</body>
</html>