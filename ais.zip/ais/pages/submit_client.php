<?php
@session_start();
include 'connect.php';
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$phone_num=$_POST["phone_num"];
$gender=$_POST["gender"];
$title='cls';
$username=strtolower(substr($lname, 0,1).$fname);
$password=$phone_num;
$address=$_POST["address"];
$dob=$_POST["dob"];
$nin_num=$_POST['nin_num'];
$marital=$_POST['marital'];
$clientid=$_POST['clientid'];
$entrant=$_SESSION['rolenumber'];
$datefrom=date("Y-m-d");
$dateto=date("Y-m-d", strtotime( $datefrom." +12 month" ));
$result_scrap=$dbh->query("select * from scrap where item2='$title' and type='role'");
$row_scrap=$result_scrap->fetchObject();
//nominee details
$fullname=$_POST["fullname"];
$nin=$_POST["nin"];
$phone=$_POST["phone"];
$rel=$_POST["rel"];
$prior=$_POST["prior"];
$result_nin=$dbh->query("select * from users where nin_number='$nin_num'");
$count_nin=$result_nin->rowCount();
if ($count_nin<=0) {
$insert_keyfields=$dbh->prepare("insert into keyfields (rolenumber,password,username,pswdexpiry,status) values('$clientid','$password','$username','$dateto','1')");
$insert_keyfields->execute();
$insert_users=$dbh->prepare("insert into users (role,firstname,lastname,phonenumber,nin_number,address,username,status,rolenumber,marital,gender,fulltitle,dbirth,ouruser) values('$title','$fname','$lname','$phone_num','$nin_num','$address','$username','active','$clientid','$marital','$gender','$row_scrap->item','$dob','$entrant')");
$insert_users->execute();
echo 1;
}else{echo 0;}
//submitting moninees
$select_noms=$dbh->query("select * from nominees order by autoid desc");
$count_noms=$select_noms->rowCount();
$row_noms=$select_noms->fetchObject();
if ($count_noms<0) { $nomid="nm10"; }else{
$nomid="nm10".($row_noms->autoid+1);
}
$insert_nominees=$dbh->query("insert into nominees(clientid,fullname,nin,phone,rel,prior,ouruser,nomid) values('$clientid','$fullname','$nin','$phone','$rel','$prior','$entrant','$nomid')");
?>