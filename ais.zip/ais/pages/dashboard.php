<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}th{background: #333;color: #ffffff;font-weight: bold;}td, th{padding: 6px;border:1px solid #ccc;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Date Paid";}
td:nth-of-type(3):before{content: "Owner";}
td:nth-of-type(4):before{content: "Payment Method";}
td:nth-of-type(5):before{content: "Ammount Paid";}
td:nth-of-type(6):before{content: "Approver";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="row">
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-4">
<span class="info-box-icon bg-info elevation-1"><i class="fas fa-edit"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Clients</b></span>
<span class="info-box-number">
<?php echo "<span style='color:maroon'>".number_format(countMembers())."</span>"; ?></span></div></div></div>
          <!-- /.col -->
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-4">
<span class="info-box-icon bg-danger elevation-1"><i class="fas fa-clock"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Requests</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".countTables("client_policies","autoid>0")."</span>"; ?></span>
</div></div></div>
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-4">
<span class="info-box-icon bg-primary elevation-1"><i class="fas fa-check-circle"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Approved</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".countTables("client_policies","status=1")."</span>"; ?></span>
</div></div></div>
          <!-- /.col -->
<div class="clearfix hidden-md-up"></div>
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-4">
<span class="info-box-icon bg-success elevation-1"><i class="fas fa-briefcase"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Payments</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".countTables("payments","autoid>0")."</span>"; ?></span>
</div>
</div></div>
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-2">
<span class="info-box-icon bg-primary elevation-1"><i class="fas fa-handshake"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Recent Approvals</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".countTables("client_policies","status=1 order by autoid desc limit 10")."</span>"; ?></span>
</div></div></div>
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-2">
<span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Nominees</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".countTables("nominees","autoid>0")."</span>"; ?></span>
</div></div></div>
</div>
<?php 
$role=$_SESSION['role'];
if($role=='cls'){?>
<div class='alert alert-warning' style='text-align:center;font-weight:bold;font-style:italic;'>Hello, <span style='color:maroon'><?php echo $_SESSION['firstname']; ?></span> You Last Saved On: <span style='color:maroon'><?php echo lastSavedOn(); ?></span></div>    <?php } ?>
<div class="col-lg-12">
<div class="row">
  <div class="col-lg-6">
    <div class="card card-default">
      <div class="card-header"><h5 class="crad-title"><b>Recent Payments</b></h5></div>
      <div class="card-body">
  <table id="box">
<thead>
<tr>
<th>No</th>
<th>Date Paid</th>
<th>Payment Id</th>
<th>Client Name</th>
<th>Amount</th>
</tr>
</thead>  
<?php
if($role=="agt"){$daquery=" and ouruser='$rolenumber'";}
else{$daquery=" ";}
$result_payment=$dbh->query("select * from payments where status=0 $daquery order by autoid desc");
$row_payment=$result_payment->fetchObject(); 
$count_payment=$result_payment->rowCount();
if($count_payment>0){ $r=1; do{
$result_user=$dbh->query("select * from users where rolenumber='$row_payment->clientid'"); 
$row_user=$result_user->fetchObject(); 
echo "<tr>
<td>".$r++.".</td>
<td>".$row_payment->payed_on."</td>
<td>".$row_payment->payid."</td>
<td>".$row_user->firstname." ".$row_payment->lastname."<br><span style='color:maroon'>[".$row_user->phonenumber."]</span></td>
<td>".number_format($row_payment->amount_paid)."</td>
</tr>";
}while($row_payment=$result_payment->fetchObject());}
else{echo "<div>No Policies Registered At The Moment</div>";}
?>
</table>      
      </div>
    </div>
  </div>
 <div class="col-lg-6">
    <div class="card card-default">
      <div class="card-header"><h5 class="crad-title"><b>Recent Clients</b></h5></div>
      <div class="card-body">
    <table id="box">
<thead>
<tr>
<th>No</th>
<th>Full Name</th>
<th>Phone Number</th>
<th>Address</th>
<th>Status</th>
</tr>
</thead>
<?php
if($role=="agt"){$daquery=" and ouruser='$rolenumber'";}
elseif($role=="hd" || $role=='ad'){$daquery=" and ouruser='$rolenumber'";}
else{$daquery=" ";}
$result_user=$dbh->query("select * from users where role='cls' $daquery");
$count_user=$result_user->rowCount();
$row_user=$result_user->fetchObject();
if($count_user>0){$r=1;do{
echo "
<tr>
<td>".$r++."</td>
<td>".$row_user->firstname." ".$row_user->lastname."</td>
<td>".$row_user->phonenumber."</td>
<td>".$row_user->address."</td>
<td><a href='client_status.php?ourclient=".$row_user->rolenumber."'><button class='btn btn-sm btn-success'><i class='fa fa-eye'>View Status</i></button></a></td>
</tr>
";  
}while($row_user=$result_user->fetchObject());}
?>
</table>

      </div>
    </div>
  </div>
</div> 
<div class="col-lg-12"><br></div>
<div class="row">
  <div class="col-lg-6">
    <div class="card card-default">
      <div class="card-header"><h5 class="crad-title"><b>Pending Requests</b></h5></div>
      <div class="card-body">
  <table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Date</th>
<th>Client</th>
<th>Contact</th>
<th>Package</th>
<th>Plan Abouts</th>
</tr>  
</thead>  
<?php
$rolenumber=$_SESSION['rolenumber'];
$result_item=$dbh->query("select * from client_policies where status=0 order by autoid desc limit 5");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();
if($count_item>0){ $r=1; do{
$result_pol1=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol1=$result_pol1->fetchObject();
$result_plan1=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan1=$result_plan1->fetchObject();
$result_pac1=$dbh->query("select * from scrap where type='pac' and item='$row_item->pac'"); 
$row_pac1=$result_pac1->fetchObject(); 
$result_prem1=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem'"); 
$row_prem1=$result_prem1->fetchObject();
$result_price1=$dbh->query("select * from itempricing where planid='$row_plan1->item' and package='$row_pac1->item'"); 
$row_price1=$result_price1->fetchObject();    
if($row_pac1->item3<=1){$ident="person";}
else{$ident="people";}
$result_client=$dbh->query("select * from users where role='cls' and rolenumber='$row_item->clientid'"); 
$row_client=$result_client->fetchObject();  
echo "<tr>
<td>".$r++.".</td>
<td>".datediff($today,$row_item->autodate)."</td>
<td>".$row_client->firstname." ".$row_client->lastname."<br><span style='color:maroon'>[".$row_client->gender."]</span></td>
<td>".$row_client->address."<br><span style='color:blue'>[".$row_client->phonenumber."]</span></td>
<td>".$row_pac1->item2."<br><span style='color:maroon'>[".$row_pac1->item3." ".$ident."]</span></td>
<td>".$row_plan1->item2."<br><span style='color:maroon'>[".$row_pol1->item2."]</span></td>

</tr>";
}while($row_item=$result_item->fetchObject());}
else{echo "<tr style='text-align:center'><td colspan='11'>No Pending Client Request</td></tr>";}
?>
</table>
    </div>
    </div>
  </div>
 <div class="col-lg-6">
    <div class="card card-default">
      <div class="card-header"><h5 class="crad-title"><b>Recent Approved Requests</b></h5></div>
      <div class="card-body">
  <table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Date</th>
<th>Client</th>
<th>Contact</th>
<th>Package</th>
<th>Plan Abouts</th>
</tr>  
</thead>  
<?php
$rolenumber=$_SESSION['rolenumber'];
$result_item=$dbh->query("select * from client_policies where status=1 order by autoid desc limit 5");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();
if($count_item>0){ $r=1; do{
$result_pol1=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol1=$result_pol1->fetchObject();
$result_plan1=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan1=$result_plan1->fetchObject();
$result_pac1=$dbh->query("select * from scrap where type='pac' and item='$row_item->pac'"); 
$row_pac1=$result_pac1->fetchObject(); 
$result_prem1=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem'"); 
$row_prem1=$result_prem1->fetchObject();
$result_price1=$dbh->query("select * from itempricing where planid='$row_plan1->item' and package='$row_pac1->item'"); 
$row_price1=$result_price1->fetchObject();    
if($row_pac1->item3<=1){$ident="person";}
else{$ident="people";}
$result_client=$dbh->query("select * from users where role='cls' and rolenumber='$row_item->clientid'"); 
$row_client=$result_client->fetchObject();  
echo "<tr>
<td>".$r++.".</td>
<td>".datediff($today,$row_item->autodate)."</td>
<td>".$row_client->firstname." ".$row_client->lastname."<br><span style='color:maroon'>[".$row_client->gender."]</span></td>
<td>".$row_client->address."<br><span style='color:blue'>[".$row_client->phonenumber."]</span></td>
<td>".$row_pac1->item2."<br><span style='color:maroon'>[".$row_pac1->item3." ".$ident."]</span></td>
<td>".$row_plan1->item2."<br><span style='color:maroon'>[".$row_pol1->item2."]</span></td>

</tr>";
}while($row_item=$result_item->fetchObject());}
else{echo "<tr style='text-align:center'><td colspan='11'>No Pending Client Request</td></tr>";}
?>
</table>
      </div>
    </div>
  </div>
</div>  
</div>      
<?php lscripts(); ?>

</body>
</html>