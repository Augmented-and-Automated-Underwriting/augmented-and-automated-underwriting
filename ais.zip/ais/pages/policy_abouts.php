<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<?php
$policy=$_GET['policy'];
$result_policy=$dbh->prepare("select * from scrap where type='policy' and item=:memid");
$result_policy->bindParam(":memid",$policy);
$result_policy->execute();
$row_policy=$result_policy->fetchObject();
$count_policy=$result_policy->rowCount();

?>
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h3 class="card-title text-center"><b><?php if($count_policy>0){echo $row_policy->item2; } ?></b></h3></div>
<div class="card-body">
<span><?php echo $row_policy->item5; ?></span>
</div>
</div>
</div>   
<?php lscripts(); ?>

</body>
</html>