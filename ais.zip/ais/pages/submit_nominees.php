<?php
@session_start();
include 'connect.php';
//nominee details
$fullname=$_POST["fullname"];
$nin=$_POST["nin"];
$phone=$_POST["phone"];
$rel=$_POST["rel"];
$prior=$_POST["prior"];
$clientid=$_POST['clientid'];
$entrant=$rolenumber;
$select_noms=$dbh->query("select * from nominees order by autoid desc");
$count_noms=$select_noms->rowCount();
$row_noms=$select_noms->fetchObject();
if ($count_noms<0) { $nomid="nm10"; }else{
$nomid="nm10".($row_noms->autoid+1);
}
$result_nin=$dbh->query("select * from nominees where nin='$nin'");
$count_nin=$result_nin->rowCount();
if ($count_nin<=0) {
$insert_nominees=$dbh->query("insert into nominees(clientid,fullname,nin,phone,rel,prior,ouruser,nomid) values('$clientid','$fullname','$nin','$phone','$rel','$prior','$entrant','$nomid')");
echo 1;
}else{echo 0;}
?>