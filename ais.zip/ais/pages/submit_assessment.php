<?php
@session_start();
include 'connect.php';
$planid=$_POST["planid"];
$item_name=$_POST["item_name"];
$ins_qtn=$_POST["ins_qtn"];
$qtn_type=$_POST["qtn_type"];
$insert_assessment=$dbh->query("insert into assessment_qtns(plan,item_name,ins_qtn,qtn_type) values('$planid','$item_name','$ins_qtn','$qtn_type')");
?>