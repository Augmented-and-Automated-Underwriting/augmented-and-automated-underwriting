<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<script>
function submit_teacher(){
var kp=parseInt(document.getElementById("kp_rows").value);
var x;
if(kp<=0){}
else{  
for (x=1; x<=kp; x++){
var fullname=$("#fullname"+x+"").val();
var nin=$("#nin"+x+"").val();
var phone=$("#phone"+x+"").val();
var rel=$("#rel"+x+"").val();
var prior=$("#prior"+x+"").val();
var clientid=$("#clientid").val();
var page="submit_nominees";
var no=x;
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,fullname:fullname,nin:nin,phone:phone,rel:rel,prior:prior,no:no,clientid:clientid},
beforeSend:function(){
setTimeout(page_loading,10);},
success: function(output){
setTimeout(page_close,10);
if(output==1){
document.getElementById("allrows_rows").innerHTML='';
document.getElementById("alert_out").innerHTML="<div class='alert alert-success'>Nominees have been successfully submitted. </div>";}
else{document.getElementById("alert_out").innerHTML="<div class='alert alert-success'>Nominees have been successfully submitted. </div>";}
var close_alert=function(){$("#alert_out").slideUp();
document.getElementById("alert_out").innerHTML='';$("#alert_out").slideDown();}
setTimeout(close_alert,4000);
document.location.reload();
}
});
}
}
return false; }
function rmpkg_rows(){
var kp=document.getElementById("kp_rows").value;
if(kp>1){
var us=parseInt(kp)-1;
document.getElementById("kp_rows").value=us;
$("#tb"+kp).remove();
} }
function addpkg_rows(){
var kp=document.getElementById("kp_rows").value;
var us=parseInt(kp)+1;
document.getElementById("kp_rows").value=us;
//Add row
$("#allrows_rows").append("<table id='tb"+us+"' onClick='get_no("+us+")'><tr></tr><tr><td class='td'>"+us+".</td><td class='td'><input type='text' class='form-control' id='fullname"+us+"' placeholder='Full Name' required></td><td class='td'><input type='text' id='nin"+us+"' placeholder='National Id' class='form-control'></td><td class='td'><input type='text' id='phone"+us+"' class='form-control' placeholder='Phone'></td><td class='td'><select class='form-control' id='rel"+us+"'><option>Select</option><?php $result_scrap1=$dbh->query("select * from scrap where type='nom_rels'");$count_scrap1=$result_scrap1->rowCount();$row_scrap1=$result_scrap1->fetchObject();if($count_scrap1>0){do{echo "<option value='".$row_scrap1->item."'>".$row_scrap1->item2."</option>";}while($row_scrap1=$result_scrap1->fetchObject());}?> </select></td><td class='td'><select class='form-control' id='prior"+us+"'><option>Select</option><?php $result_scrap1=$dbh->query("select * from scrap where type='priors'");$count_scrap1=$result_scrap1->rowCount();$row_scrap1=$result_scrap1->fetchObject();if($count_scrap1>0){do{echo "<option value='".$row_scrap1->item."'>".$row_scrap1->item2."</option>";}while($row_scrap1=$result_scrap1->fetchObject());}?> </select></td></tr></table>");
}
function close_out(obj){
$("#lt"+obj).hide();
} 
function fun_show(){
$(".filters").toggle();
}
function get_no(no){$("#kp").val(no);}
</script>
<style>
.blink {
animation: blink-animation 1s steps(5, start) infinite;
-webkit-animation: blink-animation 1s steps(5, start) infinite;
}
@keyframes blink-animation {
to {
visibility: hidden;
}
}
@-webkit-keyframes blink-animation {
to {
visibility: hidden;
}
}
</style> 
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}
th{background: #333;color: #ffffff;font-weight: bold;}
td, th{padding: 6px;border:2px solid #0000ff;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
.td{border: none;border-bottom: 1px solid #0000ff;position: relative;padding-left: 50%;}
.td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
.td:nth-of-type(1):before{content: "No";}
.td:nth-of-type(2):before{content: "Name";}
.td:nth-of-type(3):before{content: "Nin";}
.td:nth-of-type(4):before{content: "Phone";}
.td:nth-of-type(5):before{content: "Relation";}
.td:nth-of-type(6):before{content: "Priority";}
.ttd{border: none;border-bottom: 1px solid #0000ff;position: relative;padding-left: 50%;}
.ttd:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
.ttd:nth-of-type(1):before{content: "No";}
.ttd:nth-of-type(2):before{content: "Name";}
.ttd:nth-of-type(3):before{content: "Nin";}
.ttd:nth-of-type(4):before{content: "Phone";}
.ttd:nth-of-type(5):before{content: "Relation";}
.ttd:nth-of-type(6):before{content: "Priority";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div id='loadin' style='position:absolute;z-index:9;width:0%;height:0%;background-color: grey;opacity:0.4;overflow-y: hidden'>
<img src='../dist/img/loadin.gif' style='width:20%;margin-left:40%;margin-top:20%;'>
</div> 
<?php kleftbar(); ?>
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Manage Nominees</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">New Nominee</a></li>
<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">My Nominees</a></li>   </ul>
</div><!-- /.card-header -->
<div class="card-body">
 <div id="alert_out"></div> 
<input type='hidden' id='kp' value='1'>
<input type='hidden' id='kp_rows' value='1'>
<input type='hidden' id='clientid' value='<?php echo $rolenumber; ?>'>
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<div id='form_allrows' class='col-lg-12'>  
<div class="row">  
<table onClick='get_no(1)'>
<thead>
<tr>
<th>No</th>
<th>Full Name</th>
<th>Nation Id</th>
<th>Phone Number</th>
<th>Relationship</th>
<th>Priority</th>
</tr>
</thead>
<tr>
<td class='td'>1.</td>
<td class='td'><input type='text' class='form-control' id="fullname1" placeholder='Full Name' required></td>
<td class='td'><input type='text' class='form-control' id="nin1" placeholder='National Id' required></td>
<td class='td'><input type='text' id='phone1' class='form-control' placeholder='Phone'></td>
<td class='td'>
<select class="form-control" id="rel1">
<option>Select</option>     
<?php
$result_scrap1=$dbh->query("select * from scrap where type='nom_rels'");
$count_scrap1=$result_scrap1->rowCount();
$row_scrap1=$result_scrap1->fetchObject();
if($count_scrap1>0){do{
echo "<option value='".$row_scrap1->item."'>".$row_scrap1->item2."</option>";    
}while($row_scrap1=$result_scrap1->fetchObject());}
?>    
</select>    
</td>
<td class='td'>
<select class="form-control" id="prior1">
<option>Select</option>    
<?php
$result_scrap1=$dbh->query("select * from scrap where type='priors'");
$count_scrap1=$result_scrap1->rowCount();
$row_scrap1=$result_scrap1->fetchObject();
if($count_scrap1>0){do{
echo "<option value='".$row_scrap1->item."'>".$row_scrap1->item2."</option>";    
}while($row_scrap1=$result_scrap1->fetchObject());}
?>    
</select>    
</td>

</tr>
</table>
<div id="allrows_rows" style='width:100%;'></div>
</div>

<div class='col-lg-12'>
<div class="row">  
<div class='col-lg-2' onClick="addpkg_rows()"><br> 
<a style='color:#fff;' class='btn btn-md btn-success btn-block'><i class='fa fa-plus'></i> Nominee</a></div>
<div class='col-lg-2' onClick="rmpkg_rows()"><br> 
<a  class='btn btn-md btn-danger btn-block'><i class='fa fa-minus'></i> Nominee</a>
</div>
<div class="col-lg-2"><br>    
<input type='submit' onClick='submit_teacher()' class='btn btn-md btn-primary btn-block' value='Submit'></div>  
</div>
</div>
</div>

</div>
<!-- /.tab-pane -->
<div class='tab-pane' id='tab_2'>

<table>
<thead>
<tr>
<th>No</th>  
<th>Name</th>
<th>NIN Number</th>
<th>Phone</th>
<th>Relationship</th>
<th>Priority</th>
</tr>
</thead>  
<?php
$select_noms=$dbh->query("select * from nominees where clientid='$rolenumber' order by autoid desc");
$count_noms=$select_noms->rowCount();
$row_noms=$select_noms->fetchObject();
if($count_noms>0){$r=1;do{
$result_rel=$dbh->query("select * from scrap where type='nom_rels' and item='$row_noms->rel'");
$row_rel=$result_rel->fetchObject();
$result_pro=$dbh->query("select * from scrap where type='priors' and item='$row_noms->prior'");
$row_pro=$result_pro->fetchObject(); 
echo "
<tr>
<td class='ttd'>".$r++."</td>
<td class='ttd'>".$row_noms->fullname."</td>
<td class='ttd'>".$row_noms->nin."</td>
<td class='ttd'>".$row_noms->phone."</td>
<td class='ttd'>".$row_rel->item2."</td>
<td class='ttd'>".$row_pro->item2."</td>
</tr>
";  
}while($row_noms=$select_noms->fetchObject());}
?>
</table>      
</div>

</div>

</div>
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
function show_person(){ $("#newperson").toggle(500);}
var page_loading=function(){$("#loadin").animate({width: "100%", height: "100%", opacity: "0.4"},500);}
var page_close=function(){$("#loadin").animate({width: "0%", height: "0%", opacity: "0"},500);}
</script>
<?php lscripts(); ?>
</body>
</html>
