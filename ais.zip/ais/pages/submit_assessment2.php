<?php
@session_start();
include 'connect.php';
$planid=$_POST["planid"];
$plan_type=$_POST["plan_type"];
$clientid=$_POST["clientid"];
$client_age=$_POST["client_age"];
$marital_status=$_POST["marital_status"];
$client_gender=$_POST["client_gender"];
$emp_status=$_POST["emp_status"];
$qtn_answer=$_POST["qtn_answer"];
$questionid=$_POST["questionid"];
$cid=$_POST["cid"];
$prem_term=$_POST['prem_term'];
$pac=$_POST['pac'];
$insert_assessment=$dbh->query("insert into assessment_ans(planid,ouruser,qtn,answer) values('$planid','$clientid','$questionid','$qtn_answer')");
$result_bigtransact=$dbh->query("select * from client_policies where reqid='$cid'");
$count_bigtransact=$result_bigtransact->rowcount();
if($count_bigtransact<=0){
$insert_request=$dbh->query("insert into client_policies(planid,plan_type,age,gender,marital_status,clientid,emp_status,reqid,pac,prem) values('$planid','$plan_type','$client_age','$client_gender','$marital_status','$clientid','$emp_status','$cid','$pac','$prem_term')");
}
?>