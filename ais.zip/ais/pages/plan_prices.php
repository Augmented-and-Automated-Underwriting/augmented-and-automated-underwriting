<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<script type="text/javascript">
 
function change_values(obj){
var page="plan_cats";
var uid=obj.value;
var tt=obj.id;
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,uid:uid,tt:tt},
success: function(user_out){
document.getElementById("div_cp").innerHTML=user_out}
});

return false; }
</script>
<style>
.blink {
animation: blink-animation 1s steps(5, start) infinite;
-webkit-animation: blink-animation 1s steps(5, start) infinite;
}
@keyframes blink-animation {
to {
visibility: hidden;
}
}
@-webkit-keyframes blink-animation {
to {
visibility: hidden;
}
}
label {display: none;}
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<?php kleftbar(); ?>
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3">Insurance Plan Prices</h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Set Price</a></li>
<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Manage Prices</a></li>   </ul>
</div><!-- /.card-header -->
<div class="card-body">
<?php
if(isset($_POST['submit_price'])){
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$priceid="px".$fyy.$mm.$dd.$hi.$mi.$fsa;
$plan_type=$_POST['plan_type'];
$planid=$_POST['planid'];
$plan_price=$_POST['plan_price'];
$package_name=$_POST['package_name'];
$term_name=$_POST['term_name'];
$insert_price=$dbh->query("insert into itempricing(plan_type,planid,package,price1,ouruser,priceid,prem_term) values('$plan_type','$planid','$package_name','$plan_price','$rolenumber','$priceid','$term_name')");
if($insert_price){echo "<div class='alert alert-success'>Success: Price set</div>";}
else{echo "<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}

?>
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<form method="post">  
<div class='row'>
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>Plan Type</th>
<th>Insurance Plan</th>
<th>Package</th>
<th>Premium Term</th>
<th>Price</th>
<th>Action</th>
</tr>
</thead>
<tr>
<td>
<select name="plan_type" class="form-control" onchange="change_values(this);" id="plan_type">
<option>Select</option>  
<?php
$result_scrap=$dbh->query("select * from scrap where type ='policy' order by item2 asc");
$count_scrap=$result_scrap->rowCount();
$row_scrap=$result_scrap->fetchObject();
if($count_scrap>0){do{
echo"<option value='".$row_scrap->item."'>".$row_scrap->item2."</option>";
}while($row_scrap=$result_scrap->fetchObject());}
?>  
</select>
</td>
<td id="div_cp">
<select class="form-control" id="planid" name="planid">
  <option>Select</option>
</select>
</td>
<td>
<select name="package_name" class="form-control">
<option>select</option>
<?php
$result_scrap=$dbh->query("select * from scrap where type='pac'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
  if($row_scrap->item3<=1){$ident="person";}
  else{$ident="people";}
echo "
<option value='".$row_scrap->item."'>".$row_scrap->item2."-<span style='color:maroon'>[".$row_scrap->item3." ".$ident."]</span></option>";
}while($row_scrap=$result_scrap->fetchObject());}
?>  
</select>  
</td>
<td>
<select name="term_name" class="form-control">
<option>select</option>
<?php
$result_scrap=$dbh->query("select * from scrap where type='prem_term'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
echo "
<option value='".$row_scrap->item."'>".$row_scrap->item2."</option>";
}while($row_scrap=$result_scrap->fetchObject());}
?>  
</select>  
</td>
<td><input type='number' class='form-control' placeholder='Plan Price' name="plan_price"></td>
<td>
<input type="submit" name="submit_price" class="btn btn-success btn-sm btn-block" value="Submit">
</td>

</tr>
</table>
</form>

</div>

</div>
<!-- /.tab-pane -->
<div class='tab-pane' id='tab_2'>

<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Plan Details</th>
<th>Package</th>
<th>Billing</th>
</tr>
</thead>
<?php
$result_itemprices=$dbh->query("select * from itempricing order by plan_type asc");
$count_itemprices=$result_itemprices->rowCount();
$row_itemprices=$result_itemprices->fetchObject();
if($count_itemprices>0){$r=1;do{
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_itemprices->package'"); 
$row_pac=$result_pac->fetchObject(); 
$result_policy=$dbh->query("select * from scrap where type='policy' and item='$row_itemprices->plan_type'"); 
$row_policy=$result_policy->fetchObject();  
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_itemprices->planid'"); 
$row_plan=$result_plan->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_itemprices->prem_term'"); 
$row_prem=$result_prem->fetchObject(); 
echo "
<tr>
<td>".$r++."</td>
<td>".$row_plan->item2."<br><span style='color:maroon'>[".$row_policy->item2."]</span></td>
<td>".$row_pac->item2."</td>
<td>".number_format($row_itemprices->price1)."<br><span>[".$row_prem->item2."]</span></td>
</tr>
";
}while($row_itemprices=$result_itemprices->fetchObject());}

?>
</table>

</div>

</div>

</div>
<?php lscripts(); ?>
</body>
</html>
