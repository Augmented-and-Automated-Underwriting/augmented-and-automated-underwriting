<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<script>

function change_values(obj){
var page="plan_cats";
var uid=obj.value;
var tt=obj.id;
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,uid:uid,tt:tt},
success: function(user_out){
document.getElementById("div_cp").innerHTML=user_out}
});

return false; }
function submit_assessment(){
var kp=parseInt(document.getElementById("kp_rows").value);
var x;
if(kp<=0){}
else{  
for (x=1; x<=kp; x++){
var item_name=$("#item_name"+x+"").val();
var ins_qtn=$("#ins_qtn"+x+"").val();
var qtn_type=$("#qtn_type"+x+"").val();
var planid=$("#planid").val();
var page="submit_assessment";
var no=x;
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,item_name:item_name,ins_qtn:ins_qtn,qtn_type:qtn_type,no:no,planid:planid},
beforeSend:function(){
setTimeout(page_loading,10);},
success: function(output){
setTimeout(page_close,10);
if(output==1){
document.getElementById("form_allrows").innerHTML='';
document.getElementById("alert_out").innerHTML="<div class='alert alert-success'>Plan Assessment submitted. </div>";}
else{document.getElementById("alert_out").innerHTML="<div class='alert alert-info'>New Assessment Added To Already Existing Plan. </div>";}
var close_alert=function(){$("#alert_out").slideUp();
document.getElementById("alert_out").innerHTML='';$("#alert_out").slideDown();}
setTimeout(close_alert,4000);
}
});
}
}
return false; }
function rmpkg_rows(){
var kp=document.getElementById("kp_rows").value;
if(kp>1){
var us=parseInt(kp)-1;
document.getElementById("kp_rows").value=us;
$("#tb"+kp).remove();
} }
function addpkg_rows(){
var kp=document.getElementById("kp_rows").value;
var us=parseInt(kp)+1;
document.getElementById("kp_rows").value=us;
//Add row
$("#allrows_rows").append("<table id='tb"+us+"' onClick='get_no("+us+")' class='table table-striped'><tr><td  width='2%'>"+us+".</td><td><input type='text' class='form-control' id='item_name"+us+"' placeholder='Item Name' required></td><td width='60%'><input type='text' id='ins_qtn"+us+"' placeholder='Insurance Question' class='form-control'></td><td><select id='qtn_type"+us+"' class='form-control'><option value=''>Select</option><option value='1'>True/False</option><option value='2'>Detailed</option></select></td></tr></table>");
}
function close_out(obj){
$("#lt"+obj).hide();
} 
function fun_show(){
$(".filters").toggle();
}
function get_no(no){$("#kp").val(no);}
</script>
<style>
.blink {
animation: blink-animation 1s steps(5, start) infinite;
-webkit-animation: blink-animation 1s steps(5, start) infinite;
}
@keyframes blink-animation {
to {
visibility: hidden;
}
}
@-webkit-keyframes blink-animation {
to {
visibility: hidden;
}
}

</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div id='loadin' style='position:absolute;z-index:9;width:0%;height:0%;background-color: grey;opacity:0.4;overflow-y: hidden'>
<img src='../js/loadin.gif' style='width:20%;margin-left:40%;margin-top:20%;'>
</div> 
<?php kleftbar(); ?>
<div class="row">
<div class="col-lg-6">
<label>Insurance Policy</label>    
<select name="policy" class="form-control" onchange="change_values(this);" id="policy">
<option>Select</option>  
<?php
$result_scrap=$dbh->query("select * from scrap where type ='policy' order by item2 asc");
$count_scrap=$result_scrap->rowCount();
$row_scrap=$result_scrap->fetchObject();
if($count_scrap>0){do{
echo"<option value='".$row_scrap->item."'>".$row_scrap->item2."</option>";
}while($row_scrap=$result_scrap->fetchObject());}
?>  
</select>    
</div>
<div class="col-lg-6" id="div_cp">
<label>Insurance Plan</label>    
<select class="form-control" id="planid" name="planid">
  <option>Select</option>
</select>    
</div>    
</div>    
<div class="col-lg-12"><br></div>
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Generate Plan Assessment</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Manage</a></li>
   </ul>
</div><!-- /.card-header -->
<div class="card-body">
 <div id="alert_out"></div> 
<input type='hidden' id='kp' value='1'>
<input type='hidden' id='kp_rows' value='1'>
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<div id='form_allrows' class='col-lg-12'>  
<div class="row"> 
<table onClick='get_no(1)' class="table table-striped table-bordered">
<thead>
<tr>
<th width="2%">No</th>
<th>Item Name</th>
<th width="60%">Insurance Question</th>
<th>Answer Type</th>
</tr>
</thead>
<tr><td>1.</td>
<td><input type='text' class='form-control' id="item_name1" placeholder='Item Name' required></td>
<td><input type='text' class='form-control' id="ins_qtn1" placeholder='Assessing Question' required></td>
<td>
<select id="qtn_type1" class="form-control">
<option value="">Select</option>
<option value="1">True/False</option>
<option value="2">Detailed</option>    
</select>    
</td>
</tr>
</table>
<div id="allrows_rows" style='width:100%;'></div>
</div>

<div class='col-lg-12'>
<input type='submit' onClick='submit_assessment()' style='float:right;' class='btn btn-md btn-primary' value='Submit'>    
<div class='col-lg-2' style='float:left' onClick="addpkg_rows()"> 
<a style='float:right;color:#fff;' class='btn btn-md btn-success'><i class='fa fa-plus'></i>Question</a></div>

<div class='col-lg-2' style='float:left' onClick="rmpkg_rows()"> 
<a style='float:right;color:#fff;'  class='btn btn-md btn-danger'><i class='fa fa-minus'></i>Question</a>
</div>
</div>

</div>

</div>


</div>

</div>
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
function show_person(){ $("#newperson").toggle(500);}
var page_loading=function(){$("#loadin").animate({width: "100%", height: "100%", opacity: "0.4"},500);}
var page_close=function(){$("#loadin").animate({width: "0%", height: "0%", opacity: "0"},500);}
</script>
<?php lscripts(); ?>
</body>
</html>
