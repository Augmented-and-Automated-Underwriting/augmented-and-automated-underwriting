<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h4 class="card-title"><b>Pending Approval</b></h4></div>
<div class="card-body">
<?php
if(isset($_POST['approve_payment'])){
$payid=$_POST['payid'];
$status=0;
$update_payments=$dbh->query("update payments set status='$status' where payid='$payid'");
if($update_payments){echo "<div class='alert alert-success'>Payment approved</div>"; }
else{echo "<div class='alert alert-success'>Payment approved</div>";}	
}
?>	
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>PayDate</th>
<th>Client</th>
<th>Policy Abouts</th>
<th>Amount Paid</th>
<th>Balance</th>
<th>Next PayDate</th>
<?php if($role=='tech' || $role=='ad'){ ?><th>Action</th> <?php } ?>
</tr>  
</thead>  
<?php
if($role=="agt"){$daquery=" and ouruser='$rolenumber'";}
else{$daquery=" ";}
$result_payment=$dbh->query("select * from payments where status=1 $daquery order by autoid desc");
$row_payment=$result_payment->fetchObject(); 
$count_payment=$result_payment->rowCount();
if($count_payment>0){ $r=1; do{
$result_item=$dbh->query("select * from client_policies where clientid='$row_payment->clientid'");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();	
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan=$result_plan->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->pac'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem'"); 
$row_prem=$result_prem->fetchObject();    
if($row_pac->item3<=1){$ident="person";}
else{$ident="people";}
$result_user=$dbh->query("select * from users where rolenumber='$row_payment->clientid'"); 
$row_user=$result_user->fetchObject();
$result_user2=$dbh->query("select * from users where rolenumber='$row_payment->ouruser'"); 
$row_user2=$result_user2->fetchObject();	
echo "<tr>
<td>".$r++.".</td>
<td>".$row_payment->payed_on."<br><span style='color:blue'>by@".strtolower(substr($row_user2->lastname, 0,1)."".$row_user2->firstname)."</span></td>
<td>".$row_user->firstname." ".$row_payment->lastname."<br><span style='color:maroon'>[".$row_user->phonenumber."]</span></td>
<td>".$row_plan->item2."<br><span>[".$row_pol->item2."]</span><br><span style='color:maroon'>".$row_pac->item2."-[".$row_pac->item3." ".$ident."]</span></td>
<td>".number_format($row_payment->amount_paid)."<br><span style='color:maroon'>[".$row_prem->item2."]</span></td>
<td>".number_format($row_payment->balance)."</td>
<td>".$row_payment->next_pay."</td>";
if($role=='ad' || $role=='tech'){
echo"<td>
<form method='post'>
<input type='hidden' name='payid' value='".$row_payment->payid."'>
<input type='submit' name='approve_payment' class='btn btn-sm btn-success' value='Approve'>
</form>
</td>"; }
echo"</tr>";
}while($row_payment=$result_payment->fetchObject());}
else{echo "<div>No pending payments at the moment</div>";}
?>
</table>
</div>
</div>
</div>  
<?php lscripts(); ?>

</body>
</html>