<?php
$val=$_POST["val"];
$tt=$_POST["tt"];

if(!empty($val)){
$result_policy=$dbh->query("select * from scrap where type='policy' and item2 like '%$val%'");
$row_policy=$result_policy->fetchObject();
$count_policy=$result_policy->rowCount();
if($count_policy>0){ echo "<ul class='list-group' style='height:300px;overflow-y:scroll;'>"; do{ ?>
<li class='list-group-item' style='cursor:pointer;' onClick="get_values('<?php echo $row_policy->item2; ?>','<?php echo $row_policy->item; ?>','<?php echo $tt; ?>')"><?php echo $row_policy->item2;?></li>
<?php }while($row_policy=$result_policy->fetchObject());
echo "</ul>";} }
?>