<?php
@session_start();
include 'connect.php';
$reqid=$_POST['reqid'];
$userid=$_POST['userid'];
$total_amount=$_POST['total_amount'];
$plid=$_POST['plid'];
$total_wgt=$_POST['total_wgt'];
$tweight=$_POST['tweight'];
$ansid=$_POST['ansid'];
$pkg=$_POST['pkg'];
$pol=$_POST['pol'];
$about="Your request for a ".$pol." insurance policy of ".$total_amount." ".$pkg." has been approved";
$approved_on=date("Y-m-d");
$approver_comment=$_POST['approver_comment'];
$status=1;
$ouruser=$rolenumber;
$insert_notifications=$dbh->query("insert into notifications(clientid,reqid,about,ouruser) values('$userid','$reqid','$about','$ouruser')");

$update_policies=$dbh->query("UPDATE client_policies SET approver='$ouruser', date_approved='$approved_on',status='$status', total_amount='$total_amount',total_weight='$total_wgt' WHERE reqid='$reqid'");
$update_answers=$dbh->query("UPDATE assessment_ans SET weight='$tweight' WHERE autoid='$ansid'");

?>