<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<?php kleftbar(); ?>

<div class="col-md-12">
<div class="card card-default">
<div class="card-header">
<h4 class="card-title ">System Logs</h4>
</div>
<div class="card-body">
<div class="table-responsive">
<table class="table table-striped">
<thead>
<tr>
<th>Time</th>
<th>IP Address</th>
<th>User</th>
<th>Current Page</th>
<th>Previous Ppage</th>
<th>Browser</th>

</tr></thead>
<tbody>
<?php
$result = $dbh->query("select * from useractivity where userid not like '%tech%' order by autoid desc limit 100");
$row = $result->fetchObject();
$count = $result->rowCount();

if($count>0){
do{

$result2 = $dbh->query("select * from users where rolenumber='$row->userid'");
$row2 = $result2->fetchObject();
$count2 = $result2->rowCount(); 

echo "
<tr>
<td>".$row->date."</td>
<td>".$row->deviceid."</td>
<td>"; if(!empty($row->userid)){echo $row2->firstname."&nbsp".$row2->lastname;} if($row->activity!="On page"){echo "<br><span style='color:maroon;'>".$row->activity."</span><br>";}  echo "</td>
<td style='word-wrap: break-word;' title='".$row->currentpage."'>".substr($row->currentpage,0,45)."</td>
<td style='word-wrap: break-word;' title='".$row->previouspage."'>".substr($row->previouspage,0,55)."</td>
<td>".substr($row->browser,0,49)."</td>
</tr>";}while($row = $result->fetchObject());
}else{echo "<tr><td align='center' colspan='10'>There is NO data</td></tr>";}
?>
</tbody>
</table>
</div></div>
</div>

<?php lscripts(); ?>
</body>
</html>