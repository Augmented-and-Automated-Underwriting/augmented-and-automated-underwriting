<?php
$names=$_POST["uid"];

if(!empty($names)){
$result_policies=$dbh->query("select * from client_policies where clientid='$names' and status=1 order by autoid desc");
$row_policies=$result_policies->fetchObject();
$count_policies=$result_policies->rowCount(); 
echo "
<label>Policies</label>
<select class='form-control' id='reqid' name='reqid'>
<option value=''>Select Policy</option>";

if($count_policies>0){  do{ 
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_policies->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_policies->planid'"); 
$row_plan=$result_plan->fetchObject();    
echo "<option value='".$row_policies->reqid."'>".$row_plan->item2."<span>[".$row_pol->item2."]</span></option>";
}while($row_policies=$result_policies->fetchObject()); }
else{echo "<option value=''>No Plans For Selected Client.</option>";}

echo "</select>";}
?>