<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}
th{background: #333;color: #ffffff;font-weight: bold;}
td, th{padding: 6px;border:2px solid #0000ff;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #0000ff;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Package";}
td:nth-of-type(3):before{content: "Abouts";}
td:nth-of-type(4):before{content: "Amount";}
td:nth-of-type(5):before{content: "Term";}
td:nth-of-type(6):before{content: "Weight";}
td:nth-of-type(7):before{content: "Status";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h4 class="card-title"><b>Your Policies & Plans</b></h4></div>
<div class="card-body">
<table>
<thead>
<tr>
<th>No</th>
<th>Package</th>
<th>Plan Abouts</th>
<th>Amount</th>
<th>Term</th>
<th>Weight</th>
<th>Status</th>
</tr>  
</thead>  
<?php
$rolenumber=$_SESSION['rolenumber'];
$result_item=$dbh->query("select * from client_policies where clientid='$rolenumber' order by autoid desc");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();
if($count_item>0){ $r=1; do{
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan=$result_plan->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->pac'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem'"); 
$row_prem=$result_prem->fetchObject();    
if($row_pac->item3<=1){$ident="person";}
else{$ident="people";}
if($row_item->status==0){$mystatus="<badge class='btn btn-sm btn-warning'>Pending Approval</badge>";}
elseif ($row_item->status==1) {$mystatus="<badge class='btn btn-sm btn-success'>Verified & Active</badge>";}
elseif ($row_item->status==2) {$mystatus="<badge class='btn btn-sm btn-danger'>Denied</badge>";}
echo "<tr>
<td>".$r++.".</td>
<td>".$row_pac->item2."<br><span style='color:maroon'>[".$row_pac->item3." ".$ident."]</span></td>
<td>".$row_plan->item2."<br><span style='color:maroon'>[".$row_pol->item2."]</span></td>
<td>UGX:".number_format($row_item->total_amount)."</td>
<td>".$row_prem->item2."</td>
<td>".$row_item->total_weight."</td>
<td>".$mystatus."</td>
</tr>";
}while($row_item=$result_item->fetchObject());}
else{echo "<div>No Policies Registered At The Moment</div>";}
?>
</table>
</div>
</div>
</div>  
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
</script> 
<?php lscripts(); ?>

</body>
</html>