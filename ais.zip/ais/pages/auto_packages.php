<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}
th{background: #333;color: #ffffff;font-weight: bold;}
td, th{padding: 6px;border:2px solid #0000ff;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
.td{border: none;border-bottom: 1px solid #0000ff;position: relative;padding-left: 50%;}
.td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
.td:nth-of-type(1):before{content: "No";}
.td:nth-of-type(2):before{content: "Package";}
.td:nth-of-type(3):before{content: "Abouts";}
.td:nth-of-type(4):before{content: "Price";}
.td:nth-of-type(5):before{content: "Term";}
.td:nth-of-type(6):before{content: "Action";}
} 
</style> 
<script src='../js/jquery.js'></script>
<script src='../js/thousandseparator.js'></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>

<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h4 class="card-title"><b>Your Policy Match</b></h4></div>
<div class="card-body">
<?php
if(isset($_POST['submit_request'])){
$clientid=$rolenumber;
$planid=$_POST['planid'];
$plan_type=$_POST['plan_type'];
$branch_name=$_POST['branch_name'];
$pac=$_POST['pac'];
$prem=$_POST['prem'];
$price=$_POST['price'];
$dateadded=date('Y-m-d');
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$reqid="rq".$fyy.$mm.$dd.$hi.$mi.$fsa;
$insert_request=$dbh->query("insert into client_policies(planid,plan_type,clientid,dateadded,branch,reqid,pac,prem,price) value('$planid','$plan_type','$clientid','$dateadded','$branch_name','$reqid','$pac','$prem','$price')");
if($insert_request){echo "<div class='alert alert-success'>Success: Request added but pending approval</div>"; }else{echo "<div class='alert alert-danger'>Failed: Make sure branch is attached</div>";}	
}
?>	
<?php

$planid=$_POST['planid'];
$policy=$_POST['policy1'];
$package_name=$_POST['package_name'];
$term_name=$_POST['term_name'];
$min_price=$_POST['min_price'];
$max_price=$_POST['max_price'];

if(!empty($planid)){
$daplan=" and planid='$planid'";
$result_plan=$dbh->query("select * from scrap where item='$planid' and type='plan'");
$row_plan=$result_plan->fetchObject();
$pln="<span style='color:maroon;'><i>Plan:</span>".$row_plan->item2."; ";}else{$daplan='';}
// policy
if(!empty($policy)){
$dapol=" and plan_type='$policy'";
$result_policy =$dbh->query("select * from scrap where item='$policy' and type='policy'");
$row_policy=$result_policy->fetchObject();
$pol="<span style='color:maroon;'><i>Policy : </i></span>".$row_policy->item2."; ";}else{$dapol='';}
if(!empty($term_name)){$daterm="and prem_term='$term_name'";
// term
$result_term=$dbh->query("select * from scrap where item='$term_name' and type='prem_term'");
$row_term=$result_term->fetchObject();
$tm="<span style='color:maroon;'><i>Payment Mode : </i></span>".$row_term->item2."; ";}else{$daterm='';}
// pac
if(!empty($package_name)){$dapac="and package='$package_name'";
$result_pac=$dbh->query("select * from scrap where item='$package_name' and type='pac'");
$row_pac=$result_pac->fetchObject();
$pc="<span style='color:maroon;'><i>Package : </i></span>".$row_pac->item2."; ";}else{$dapac='';}
// prices
if(!empty($min_price)&&!empty($max_price)){$daprice="and (price1>='$min_price' && price1<='$max_price')"; 
$wd="For <span style='color:maroon;'><i>Price Range : </i></span>".$min_price."<span style='color:maroon;'><i> To : </i></span>".$max_price."; ";}
elseif(!empty($min_price)&&empty($max_price)){$daprice="and price1='$min_price'";
$wd="<span style='color:maroon;'><i> Of : </i></span>".$min_price."; ";}

elseif(empty($min_price)&&!empty($max_price)){$daprice="and price1='$max_price'";
$wd="<span style='color:maroon;'><i> Of : </i></span>".$max_price."; ";}

elseif(empty($max_price)&&empty($max_price)){$daprice='';}

$result_packages=$dbh->query("select * from itempricing where status=1 $daprice $daplan $dapol $daterm $dapac");
$count_packages=$result_packages->rowCount();

echo "<div class='alert alert-warning' style='text-align:center;font-weight:bold;font-style:italic;'><span style='color:maroon;'>".$count_packages."</span> insurance packages match your search ".$wd." ".$pol." ".$pln." ".$tm." ".$pc."</div>";

?>
<table>
<thead>
<tr>
<th>No</th>
<th>Package</th>
<th>Plan Abouts</th>
<th>Price</th>
<th>Term</th>
<th>Action</th>
</tr>  
</thead>  
<?php
$result_item=$dbh->query("select * from itempricing where status=1 $daprice $daplan $dapol $daterm $dapac");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();
if($count_item>0){$r=1; do{
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan=$result_plan->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->package'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem_term'"); 
$row_prem=$result_prem->fetchObject();
$count_prem=$result_prem->rowCount();
if($count_prem){if($row_pac->item3<=1){$ident="person";}else{$ident="people";}}    
echo "<tr>
<td class='td'>".$z++."</td>
<td class='td'>".$row_pac->item2."<br><span style='color:maroon'>[".$row_pac->item3." ".$ident."]</span></td>
<td class='td'>".$row_plan->item2."<br><span style='color:maroon'>[".$row_pol->item2."]</span></td>
<td class='td'>UGX:".number_format($row_item->price1)."</td>
<td class='td'>".$row_prem->item2."</td>
<td class='td'><button onClick='show_dis(".$row_item->autoid.")' class='btn btn-sm btn-primary btn-block'>Request</button></td>
</tr><tr></tr>
<tr id='dis_edit".$row_item->autoid."' style='border-bottom: 2px solid red;border-top: 2px solid red;display:none;'><form method='post'>
<input type='hidden' name='planid' value='".$row_item->planid."'>
<input type='hidden' name='plan_type' value='".$row_item->plan_type."'>  
<input type='hidden' name='pac' value='".$row_pac->item."'>
<input type='hidden' name='prem' value='".$row_prem->item."'>
<input type='hidden' name='price' value='".$row_item->priceid."'>      
<td colspan='6'><div class='row'>
<div class='col-lg-2'>Policy : 
<input type='text' class='form-control' value='".$row_pol->item2."' readonly></div>
<div class='col-lg-2'>Plan : 
<input type='text' class='form-control' value='".$row_plan->item2."' readonly></div>
<div class='col-lg-2'>Package : 
<input type='text' class='form-control' value='".$row_pac->item2."' readonly></div>
<div class='col-lg-2'>Premium Term : 
<input type='text' class='form-control' value='".$row_prem->item2."' readonly></div>
<div class='col-lg-2'>Amount : 
<input type='text' class='form-control' value='".$row_item->price1."' readonly></div>
<div class='col-lg-2'>Nearest Branch :
<select class='form-control' name='branch_name' required>
<option>Select Branch</option>";
$result_scrap=$dbh->query("select * from scrap where type='branch'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
$result_loc=$dbh->query("select * from scrap where type='loc' and item='$row_scrap->item3'"); 
$row_loc=$result_loc->fetchObject(); 
$count_loc=$result_loc->rowCount();  
echo "<option value='".$row_scrap->item."'>".$row_scrap->item2."-<span>[".$row_loc->item2." Branch]</span></option>";
}while($row_scrap=$result_scrap->fetchObject());}
echo "</select></div></div>
<div class='col-lg-12'><br></div>      
<div class='form-group'><input type='submit' name='submit_request' class='btn btn-sm btn-success form-control' value='Submit Request'></div></td></form></tr>";
}while($row_item=$result_item->fetchObject());}
else{
echo "<div class='card-header'><h4 class='card-title'>No Packages Match Your Search But We Recommend</h4></div><div class='col-lg-12'><br></div>";
$result_item=$dbh->query("select * from itempricing where status=1 and plan_type='$policy'");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();
if($count_item>0){ $r=1; do{
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan=$result_plan->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->package'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem_term'"); 
$row_prem=$result_prem->fetchObject();    
if($row_pac->item3<=1){$ident="person";}
else{$ident="people";}
echo "<tr>
<td class='td'>".$r++.".</td>
<td class='td'>".$row_pac->item2."<br><span style='color:maroon'>[".$row_pac->item3." ".$ident."]</span></td>
<td class='td'>".$row_plan->item2."<br><span style='color:maroon'>[".$row_pol->item2."]</span></td>
<td class='td'>UGX:".number_format($row_item->price1)."</td>
<td class='td'>".$row_prem->item2."</td>
<td class='td'><button onClick='show_dis(".$row_item->autoid.")' class='btn btn-sm btn-primary btn-block'>Request</button></td>
</tr><tr></tr>
<tr id='dis_edit".$row_item->autoid."' style='border-bottom: 2px solid red;border-top: 2px solid red;display:none;'><form method='post'>
<input type='hidden' name='planid' value='".$row_item->planid."'>
<input type='hidden' name='plan_type' value='".$row_item->plan_type."'>  
<input type='hidden' name='pac' value='".$row_pac->item."'>
<input type='hidden' name='prem' value='".$row_prem->item."'>
<input type='hidden' name='price' value='".$row_item->priceid."'>      
<td colspan='6'><div class='row'>
<div class='col-lg-2'>Policy : 
<input type='text' class='form-control' value='".$row_pol->item2."' readonly></div>
<div class='col-lg-2'>Plan : 
<input type='text' class='form-control' value='".$row_plan->item2."' readonly></div>
<div class='col-lg-2'>Package : 
<input type='text' class='form-control' value='".$row_pac->item2."' readonly></div>
<div class='col-lg-2'>Premium Term : 
<input type='text' class='form-control' value='".$row_prem->item2."' readonly></div>
<div class='col-lg-2'>Amount : 
<input type='text' class='form-control' value='".$row_item->price1."' readonly></div>
<div class='col-lg-2'>Nearest Branch :
<select class='form-control' name='branch_name' required>
<option>Select Branch</option>";
$result_scrap=$dbh->query("select * from scrap where type='branch'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
$result_loc=$dbh->query("select * from scrap where type='loc' and item='$row_scrap->item3'"); 
$row_loc=$result_loc->fetchObject(); 
$count_loc=$result_loc->rowCount();  
echo "<option value='".$row_scrap->item."'>".$row_scrap->item2."-<span>[".$row_loc->item2." Branch]</span></option>";
}while($row_scrap=$result_scrap->fetchObject());}
echo "</select></div></div>
<div class='col-lg-12'><br></div>      
<div class='form-group'><input type='submit' name='submit_request' class='btn btn-sm btn-success form-control' value='Submit Request'></div></td></form></tr>";
}while($row_item=$result_item->fetchObject());}
}
?>
</table>
</div>
</div>
</div>  
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
</script> 
<?php lscripts(); ?>

</body>
</html>