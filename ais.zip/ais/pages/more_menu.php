<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
 <?php kheader(); ?> 
   </head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="card card-default">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>General Reports</b></h3></div>
<div class="card-body">
<?php
$result_menutype1=$dbh->query("select * from menu where type='mo' and role like '%$role%' limit 0,8");
$row_menutype1=$result_menutype1->fetchObject();
$count_menutype1=$result_menutype1->rowCount();
if($count_menutype1>0){
echo "<div class='row'><div class='col-lg-6'>
  <a class='list-group-item' style='background-image: linear-gradient(#C0C0C0 , black);color:white;'> Extra Tools Menu </a>";
 do{
echo "<a href='".$row_menutype1->link."' class='list-group-item' title='".$row_menutype1->title."' ><i class='fa fa-fw fa-".$row_menutype1->img."'></i> &nbsp;  &nbsp;".$row_menutype1->item."</a>"; 
}while($row_menutype1=$result_menutype1->fetchObject());
echo "</div>";}
$result_menutype1=$dbh->query("select * from menu where type='mo' and role like '%$role%' limit 8,50");
$row_menutype1=$result_menutype1->fetchObject();
$count_menutype1=$result_menutype1->rowCount();
if($count_menutype1>0){ 
echo "<div class='col-lg-6'>
  <a class='list-group-item' style='background-image: linear-gradient(#C0C0C0 , black);color:white;'> Extra Tools Menu </a>";
do{
echo "<a href='".$row_menutype1->link."' class='list-group-item' title='".$row_menutype1->title."' ><i class='fa fa-fw fa-".$row_menutype1->img."'></i> &nbsp;  &nbsp;".$row_menutype1->item."</a>"; 
}while($row_menutype1=$result_menutype1->fetchObject());
echo "</div></div>";}?>
<?php lscripts(); ?>
</body>
</html>
