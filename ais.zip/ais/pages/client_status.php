<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}th{background: #333;color: #ffffff;font-weight: bold;}td, th{padding: 6px;border:1px solid #ccc;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Date Paid";}
td:nth-of-type(3):before{content: "Owner";}
td:nth-of-type(4):before{content: "Payment Method";}
td:nth-of-type(5):before{content: "Ammount Paid";}
td:nth-of-type(6):before{content: "Approver";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<?php
$myclient=$_GET['ourclient'];
$myrole='cls';
$result_client=$dbh->prepare("select * from users where role=:myuser and rolenumber=:myid");
$result_client->bindParam(':myuser',$myrole);
$result_client->bindParam(':myid',$myclient);
$result_client->execute();
$row_client=$result_client->fetchObject();
$count_client=$result_client->rowCount();
?>
<div class="col-lg-12">
<div class="card-header"><h2 class="card-title"><b><?php if($count_client>0){echo "<span style='color:maroon;font-weight:bold;'>[".$row_client->firstname." ".$row_client->lastname."'s]</span> Status"; }else{ echo"Client's Status";}?></b></h2></div>  
<div class="row">
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h5 class="crad-title"><b>Policy Information</b></h5></div>
<div class="card-body">
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Date</th>
<th>Client</th>
<th>Contact</th>
<th>Package</th>
<th>Plan Abouts</th>
<th>Policy Cover</th>
<th>Term</th>
<th>Weight</th>
</tr>  
</thead>  
<?php
$rolenumber=$_SESSION['rolenumber'];
$result_item1=$dbh->query("select * from client_policies where status=1 order by autoid desc");
$row_item1=$result_item1->fetchObject(); 
$count_item1=$result_item1->rowCount();
if($count_item1>0){ $r=1; do{
$result_pol1=$dbh->query("select * from scrap where type='policy' and item='$row_item1->plan_type'"); 
$row_pol1=$result_pol1->fetchObject();
$result_plan1=$dbh->query("select * from scrap where type='plan' and item='$row_item1->planid'"); 
$row_plan1=$result_plan1->fetchObject();
$result_price1=$dbh->query("select * from itempricing where priceid='$row_item1->price'"); 
$row_price1=$result_price1->fetchObject();
$result_pac1=$dbh->query("select * from scrap where type='pac' and item='$row_item1->pac'"); 
$row_pac1=$result_pac1->fetchObject(); 
$result_prem1=$dbh->query("select * from scrap where type='prem_term' and item='$row_item1->prem'"); 
$row_prem1=$result_prem1->fetchObject();    
if($row_pac1->item3<=1){$ident="person";}
else{$ident="people";}
$result_branch1=$dbh->query("select * from scrap where type='branch' and item='$row_item1->branch'"); 
$row_branch1=$result_branch1->fetchObject();
$count_branch1=$result_branch1->rowCount();
if($count_branch1>0){
$result_user1=$dbh->query("select * from users where branch='$row_branch1->item'"); 
$row_user1=$result_user1->fetchObject();	
}
$result_client1=$dbh->query("select * from users where role='cls' and rolenumber='$row_item1->clientid'"); 
$row_client1=$result_client1->fetchObject();	
echo "<tr>
<td>".$r++.".</td>
<td>".datediff($today,$row_item1->autodate)."</td>
<td>".$row_client1->firstname." ".$row_client1->lastname."<br><span style='color:maroon'>[".$row_client1->gender."]</span></td>
<td>".$row_client1->address."<br><span style='color:blue'>[".$row_client1->phonenumber."]</span></td>
<td>".$row_pac1->item2."<br><span style='color:maroon'>[".$row_pac1->item3." ".$ident."]</span></td>
<td>".$row_plan1->item2."<br><span style='color:maroon'>[".$row_pol1->item2."]</span></td>
<td>UGX:".number_format($row_item1->total_amount)."</td>
<td>".$row_prem1->item2."</td>
<td>".$row_item1->total_weight."</span></td>
</tr>";
}while($row_item1=$result_item1->fetchObject());}
else{echo "<tr><td>No Pending Client Request</td></tr>";}
?>
</table>
</div>
</div>
</div>
</div>  
<div class="col-lg-12"><br></div>
<div class="row">
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h5 class="crad-title"><b>Nominee(s)</b></h5></div>
<div class="card-body">
<table id="box">
<thead>
<tr>
<th>No</th>  
<th>Name</th>
<th>NIN Number</th>
<th>Phone</th>
<th>Relationship</th>
<th>Priority</th>
</tr>
</thead>  
<?php
$select_noms=$dbh->query("select * from nominees where clientid='$row_client->rolenumber' order by autoid desc");
$count_noms=$select_noms->rowCount();
$row_noms=$select_noms->fetchObject();
if($count_noms>0){$r=1;do{
$result_rel=$dbh->query("select * from scrap where type='nom_rels' and item='$row_noms->rel'");
$row_rel=$result_rel->fetchObject();
$result_pro=$dbh->query("select * from scrap where type='priors' and item='$row_noms->prior'");
$row_pro=$result_pro->fetchObject(); 
echo "
<tr>
<td>".$r++."</td>
<td>".$row_noms->fullname."</td>
<td>".$row_noms->nin."</td>
<td>".$row_noms->phone."</td>
<td>".$row_rel->item2."</td>
<td>".$row_pro->item2."</td>
</tr>
";  
}while($row_noms=$select_noms->fetchObject());}
?>
</table>      
</div>
</div>
</div>
</div> 
<div class="col-lg-12"><br></div>
<div class="row">
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h5 class="crad-title"><b>Payments</b></h5></div>
<div class="card-body">
<table>
<thead>
<tr>
<th>No</th>
<th>PayDate</th>
<th>Approver</th>
<th>Policy Abouts</th>
<th>Amount Paid</th>
<th>Balance</th>
<th>Next PayDate</th>
</tr>  
</thead>  
<?php
$rolenumber=$_SESSION['rolenumber'];
$result_payment=$dbh->query("select * from payments where status=0 and clientid='$row_client->rolenumber' order by autoid desc");
$row_payment=$result_payment->fetchObject(); 
$count_payment=$result_payment->rowCount();
if($count_payment>0){ $r=1; do{
$result_item=$dbh->query("select * from client_policies where clientid='$row_payment->clientid'");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();	
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan=$result_plan->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->pac'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem'"); 
$row_prem=$result_prem->fetchObject();    
if($row_pac->item3<=1){$ident="person";}
else{$ident="people";}
$result_user=$dbh->query("select * from users where rolenumber='$row_payment->ouruser'"); 
$row_user=$result_user->fetchObject();	
echo "<tr>
<td>".$r++.".</td>
<td>".$row_payment->payed_on."<br><span style='color:blue'></td>
<td>".$row_user->firstname." ".$row_payment->lastname."<br><span style='color:maroon'>[".$row_user->phonenumber."]</span></td>
<td>".$row_plan->item2."<br><span>[".$row_pol->item2."]</span><br><span style='color:maroon'>".$row_pac->item2."-[".$row_pac->item3." ".$ident."]</span></td>
<td>".number_format($row_payment->amount_paid)."<br><span style='color:maroon'>[".$row_prem->item2."]</span></td>
<td>".number_format($row_payment->balance)."</td>
<td>".$row_payment->next_pay."</td>
</tr>";
}while($row_payment=$result_payment->fetchObject());}
else{echo "<div>No Policies Registered At The Moment</div>";}
?>
</table>
</div>
</div>
</div>
</div> 
</div>      
<?php lscripts(); ?>

</body>
</html>