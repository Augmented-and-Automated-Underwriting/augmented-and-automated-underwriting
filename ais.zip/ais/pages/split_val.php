<?php
$names=$_POST["uid"];

if(!empty($names)){
$result_scrap=$dbh->query("select * from scrap where item3='$names' and type='plan'");
$row_scrap=$result_scrap->fetchObject();
$count_scrap=$result_scrap->rowCount(); 
echo "
 <label>Insurance Plan</label> 
<select class='form-control' id='planid' name='planid'>
<option value=''>Select</option>";

if($count_scrap>0){  do{ 
echo "<option value='".$row_scrap->item."'>".$row_scrap->item2."</option>";
}while($row_scrap=$result_scrap->fetchObject()); }
else{echo "<option value=''>No Plans In Selected Type.</option>";}

echo "</select>";}
?>