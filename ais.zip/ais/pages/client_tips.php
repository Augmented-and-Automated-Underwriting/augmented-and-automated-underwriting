<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>

</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">

<?php kleftbar(); ?>
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Learn More About Insurance With Our Tips</b></h3>
</div><!-- /.card-header -->
<div class="card-body">
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<div class="row">  
<?php
$result_scrap=$dbh->query("select * from scrap where type='guide'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
echo "<table class='table table-striped'><tr>
<td>".$row_scrap->item2."</td>
</tr></table>";
}while($row_scrap=$result_scrap->fetchObject());}
?>
</div></div></div>
</div></div>
<?php lscripts(); ?>
</body>
</html>
