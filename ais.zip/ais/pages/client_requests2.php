<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="col-lg-12">
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3">Manage Request</h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Pending Approval</a></li>
<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Client Approved Policies</a></li>   </ul>
</div><!-- /.card-header -->
<div class="card-body">
<?php
if(isset($_POST['approve_request'])){
$reqid=$_POST['reqid'];
$clientid=$_POST['clientid'];
$approved_on=$_POST['approved_on'];
$approver_comment=$_POST['approver_comment'];
$status=1;
$ouruser=$rolenumber;
$insert_notifications=$dbh->query("insert into notifications(clientid,reqid,about,ouruser) values('$clientid','$reqid','$approver_comment','$ouruser')");
if($insert_notifications){echo "<div class='alert alert-success'>Notification Sent</div>";}
$update_policies=$dbh->query("UPDATE client_policies SET approver='$ouruser', date_approved='$approved_on',status='$status' WHERE reqid='$reqid'");
if($update_policies){echo "<div class='alert alert-success'>Success: Policy request approved</div>";}
else{echo "<div class='alert alert-danger'>Failed: Policy request approval failed</div>";}
}
?>	
<?php
if(isset($_POST['reject_request'])){
$reqid=$_POST['reqid'];
$clientid=$_POST['clientid'];
$approved_on=date('Y-m-d');
$approver_comment=$_POST['approver_comment'];
$status=2;
$ouruser=$rolenumber;
$insert_notifications=$dbh->query("insert into notifications(clientid,reqid,about,ouruser) values('$clientid','$reqid','$approver_comment','$ouruser')");
if($insert_notifications){echo "<div class='alert alert-success'>Notification Sent</div>";}
$update_policies=$dbh->query("UPDATE client_policies SET approver='$ouruser', date_approved='$approved_on',status='$status' WHERE reqid='$reqid'");
if($update_policies){echo "<div class='alert alert-success'>Success: Policy request rejected</div>";}
else{echo "<div class='alert alert-danger'>Failed: Policy request approval failed</div>";}
}
?>	
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<div class='row'>	
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Date</th>
<th>Client</th>
<th>Contact</th>
<th>Age</th>
<th>Marital Status</th>
<th>Employment</th>
<th colspan="2">Action</th>
</tr>  
</thead>  
<?php
$rolenumber=$_SESSION['rolenumber'];
$result_item=$dbh->query("select * from client_policies where status=0 order by autoid asc");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();
if($count_item>0){ $r=1; do{
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan=$result_plan->fetchObject();
$result_price=$dbh->query("select * from itempricing where priceid='$row_item->price'"); 
$row_price=$result_price->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->pac'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem'"); 
$row_prem=$result_prem->fetchObject();    
if($row_pac->item3<=1){$ident="person";}
else{$ident="people";}
$result_branch=$dbh->query("select * from scrap where type='branch' and item='$row_item->branch'"); 
$row_branch=$result_branch->fetchObject();
$count_branch=$result_branch->rowCount();
if($count_branch>0){
$result_user=$dbh->query("select * from users where branch='$row_branch->item'"); 
$row_user=$result_user->fetchObject();	
}
$result_client=$dbh->query("select * from users where role='cls' and rolenumber='$row_item->clientid'"); 
$row_client=$result_client->fetchObject();	
echo "<tr>
<td>".$r++.".</td>
<td>".datediff($today,$row_item->autodate)."</td>
<td>".$row_client->firstname." ".$row_client->lastname."<br><span style='color:maroon'>[".$row_client->gender."]</span></td>
<td>".$row_client->address."<br><span style='color:blue'>[".$row_client->phonenumber."]</span></td>
<td>".$row_pac->item2."<br><span style='color:maroon'>[".$row_pac->item3." ".$ident."]</span></td>
<td>".$row_plan->item2."<br><span style='color:maroon'>[".$row_pol->item2."]</span></td>
<td>UGX:".number_format($row_price->price1)."</td>
<td>".$row_prem->item2."</td>
<td>".$row_branch->item2."<br>Agent-".$row_user->firstname." ".$row_user->lastname."<br><span style='color:maroon'>[".$row_user->phonenumber."]</span></td>
<td class='td'><button onClick='show_dis(".$row_item->autoid.")' class='btn btn-sm btn-success btn-block'>Approve</button></td>
<td class='td'><button onClick='show_dis2(".$row_item->autoid.")' class='btn btn-sm btn-danger btn-block'>Reject</button></td>
</tr><tr></tr>
<tr id='dis_edit".$row_item->autoid."' style='border-bottom: 2px solid red;border-top: 2px solid red;display:none;'><form method='post'>
<input type='hidden' name='reqid' value='".$row_item->reqid."'> 
<input type='hidden' name='clientid' value='".$row_item->clientid."'>    
<td colspan='11'><div class='row'>
<div class='col-lg-2'><label>Approved On</label> 
<input type='date' class='form-control' name='approved_on'></div>
<div class='col-lg-8'><label>Comment</label>
<input type='text' class='form-control' name='approver_comment' placeholder='Add Comment'></div>     
<div class='col-lg-2'><br>
<input type='submit' name='approve_request' class='btn btn-sm btn-info btn-block' value='Submit'></div></di></td></form></tr>
<tr id='dis_edit2".$row_item->autoid."' style='border-bottom: 2px solid red;border-top: 2px solid red;display:none;'><form method='post'>
<input type='hidden' name='reqid' value='".$row_item->reqid."'> 
<input type='hidden' name='clientid' value='".$row_item->clientid."'>    
<td colspan='11'><div class='row'>
<div class='col-lg-10'><label>Comment</label>
<input type='text' class='form-control' name='approver_comment' placeholder='Add Comment'></div>     
<div class='col-lg-2'><br>
<input type='submit' name='reject_request' class='btn btn-sm btn-warning btn-block' value='Submit'></div></di></td></form></tr>";
}while($row_item=$result_item->fetchObject());}
else{echo "<tr style='text-align:center'><td colspan='11'>No Pending Client Request</td></tr>";}
?>
</table>


</div>

</div>
<!-- /.tab-pane -->
<div class='tab-pane' id='tab_2'>

<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Date</th>
<th>Client</th>
<th>Contact</th>
<th>Package</th>
<th>Plan Abouts</th>
<th>Price</th>
<th>Term</th>
<th>Attached Branch</th>
<th>Action</th>
</tr>  
</thead>  
<?php
$rolenumber=$_SESSION['rolenumber'];
$result_item1=$dbh->query("select * from client_policies where status=1 order by autoid desc");
$row_item1=$result_item1->fetchObject(); 
$count_item1=$result_item1->rowCount();
if($count_item1>0){ $r=1; do{
$result_pol1=$dbh->query("select * from scrap where type='policy' and item='$row_item1->plan_type'"); 
$row_pol1=$result_pol1->fetchObject();
$result_plan1=$dbh->query("select * from scrap where type='plan' and item='$row_item1->planid'"); 
$row_plan1=$result_plan1->fetchObject();
$result_price1=$dbh->query("select * from itempricing where priceid='$row_item1->price'"); 
$row_price1=$result_price1->fetchObject();
$result_pac1=$dbh->query("select * from scrap where type='pac' and item='$row_item1->pac'"); 
$row_pac1=$result_pac1->fetchObject(); 
$result_prem1=$dbh->query("select * from scrap where type='prem_term' and item='$row_item1->prem'"); 
$row_prem1=$result_prem1->fetchObject();    
if($row_pac1->item3<=1){$ident="person";}
else{$ident="people";}
$result_branch1=$dbh->query("select * from scrap where type='branch' and item='$row_item1->branch'"); 
$row_branch1=$result_branch1->fetchObject();
$count_branch1=$result_branch1->rowCount();
if($count_branch1>0){
$result_user1=$dbh->query("select * from users where branch='$row_branch1->item'"); 
$row_user1=$result_user1->fetchObject();	
}
$result_client1=$dbh->query("select * from users where role='cls' and rolenumber='$row_item1->clientid'"); 
$row_client1=$result_client1->fetchObject();	
echo "<tr>
<td>".$r++.".</td>
<td>".datediff($today,$row_item1->autodate)."</td>
<td>".$row_client1->firstname." ".$row_client1->lastname."<br><span style='color:maroon'>[".$row_client1->gender."]</span></td>
<td>".$row_client1->address."<br><span style='color:blue'>[".$row_client1->phonenumber."]</span></td>
<td>".$row_pac1->item2."<br><span style='color:maroon'>[".$row_pac1->item3." ".$ident."]</span></td>
<td>".$row_plan1->item2."<br><span style='color:maroon'>[".$row_pol1->item2."]</span></td>
<td>UGX:".number_format($row_price1->price1)."</td>
<td>".$row_prem1->item2."</td>
<td>".$row_branch1->item2."<br>Agent-".$row_user1->firstname." ".$row_user1->lastname."<br><span style='color:maroon'>[".$row_user1->phonenumber."]</span></td>
<td class='td'><button class='btn btn-sm btn-info btn-block'>Payment Logs</button></td>
</tr>";
}while($row_item1=$result_item1->fetchObject());}
else{echo "<tr><td>No Pending Client Request</td></tr>";}
?>
</table>

</div>

</div>

</div>
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
function show_dis2(ai){$("#dis_edit2"+ai).toggle(500);}
</script> 
<?php lscripts(); ?>

</body>
</html>