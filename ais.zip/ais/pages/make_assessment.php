<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<script type="text/javascript">
function submit_assessment(){
if($("#reqid").val() !='' && $("#plid").val() !=''&& $("#userid").val() !=''){
var total_amount=$("#total_amount").val();
var plid=$("#plid").val();
var reqid=$("#reqid").val();
var userid=$("#userid").val();
var total_wgt=$("#total_wgt").val();
var pkg=$("#pkg").val();
var pol=$("#pol").val();
var count_field=$("#count_field").val();
var page="approve_assessment"
var y;
for(y=1;y<=count_field;y++){
var no=y;
var tweight=$("#tweight"+y).val();
var ansid=$("#ansid"+y).val();
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,no:no,total_amount:total_amount,plid:plid,reqid:reqid,userid:userid,total_wgt:total_wgt,tweight:tweight,ansid:ansid,pkg:pkg,pol:pol},
beforeSend:function(){
setTimeout(page_loading,10);},
success: function(output){
setTimeout(page_close,10);
if(output==1){
document.getElementById("small_form").innerHTML='';
document.getElementById("alert_out").innerHTML="<div class='alert alert-success'>Insurance Plan Approved Successfully. </div>";}
else{document.getElementById("alert_out").innerHTML="<div class='alert alert-success'>Plan Approved. </div>";}
var close_alert=function(){$("#alert_out").slideUp();
document.getElementById("alert_out").innerHTML='';$("#alert_out").slideDown();}
setTimeout(close_alert,4000);
}
});
}
return false;}
}    
</script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div id='loadin' style='position:absolute;z-index:20;width:0%;height:0%;background-color: grey;opacity:0.4;overflow-y: hidden'>
<img src='../js/loadin.gif' style='width:20%;margin-left:40%;margin-top:20%;'>
</div> 
<?php kleftbar(); ?>
<?php
$asin=$_GET['asin'];
$mem=$_GET['mem'];
$rolenumber=$_SESSION['rolenumber'];
$result_item=$dbh->prepare("select * from client_policies where planid=:mem and clientid=:asin");
$result_item->bindParam(":mem",$mem);
$result_item->bindParam(":asin",$asin);
$result_item->execute();
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();
if($count_item>0){
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan=$result_plan->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->pac'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem'"); 
$row_prem=$result_prem->fetchObject();
$result_price=$dbh->query("select * from itempricing where planid='$row_plan->item' and package='$row_pac->item'"); 
$row_price=$result_price->fetchObject();    
if($row_pac->item3<=1){$ident="person";}
else{$ident="people";}
$result_client=$dbh->query("select * from users where role='cls' and rolenumber='$row_item->clientid'"); 
$row_client=$result_client->fetchObject();	
}
?>	

<div class="col-lg-12">
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3">Generate Assessment</h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link" href="" data-toggle="tab"><span>Name:</span><span style="color:maroon;"><?php echo $row_client->firstname." ".$row_client->lastname; ?></span></a></li>  </ul>
</div><!-- /.card-header -->
<div class="card-body">
    <div id='alert_out'></div>
<div class="row col-lg-12">
<div class="col-lg-4">
<h4 class="card-title"><b><u>Client Abouts</u></b></h4>
<span><b>Name:</b></span><span><?php echo $row_client->firstname." ".$row_client->lastname; ?></span><br>
<span><b>Age:</b></span><span><?php echo $row_item->age; ?></span><br>
<span><b>Marital Status:</b></span><span><?php echo $row_item->marital_status; ?></span><br>
<span><b>Employment Status:</b></span><span><?php echo $row_item->emp_status; ?></span><br>
<span><b>Gender:</b></span><span><?php echo $row_item->gender; ?></span>	
</div>
<div class="col-lg-4"></div>
<div class="col-lg-4">
<h4 class="card-title"><b><u>Policy Details</u></b></h4>
<span><b>Policy:</b></span><span><?php echo $row_pol->item2; ?></span><br>
<span><b>Plan:</b></span><span><?php echo $row_plan->item2; ?></span><br>
<span><b>Package:</b></span><span><?php echo $row_pac->item2."--><span style='color:maroon'>[".$row_pac->item3." ".$ident."]".""; ?></span><br>
<span><b>Premium Term:</b></span><span><?php echo $row_prem->item2; ?></span><br>
<span><b>Basic Anount:</b></span><span><?php echo $row_price->price1; ?></span>	
</div>	
</div><div class="col-lg-12"><br></div>	
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<div class='row'><h4 class="card-title text-center"><u>ASSESSMENT DETAILS</u></h4>
	
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Question</th>
<th>Answer</th>
<th>Attach Weight</th>
</tr>  
</thead>  
<?php
$result_qtns=$dbh->query("select * from assessment_ans where ouruser='$row_client->rolenumber' and planid='$row_plan->item'");
$row_qtns=$result_qtns->fetchObject(); 
$count_qtns=$result_qtns->rowCount();
echo "
<input type='hidden' id='count_field' value='".$count_qtns."'>
<input type='hidden' id='reqid' value='".$row_item->reqid."'>
<input type='hidden' id='plid' value='".$row_plan->item."'>
<input type='hidden' id='userid' value='".$row_client->rolenumber."'>
<input type='hidden' id='pkg' value='".$row_prem->item2."'>
<input type='hidden' id='pol' value='".$row_pol->item2."'>
";
if($count_qtns>0){ $y=1;$r=1; do{
$r=$y++;	
$result_myqs=$dbh->query("select * from assessment_qtns where autoid='$row_qtns->qtn'"); 
$row_myqs=$result_myqs->fetchObject();
$count_myqs=$result_myqs->rowCount();
echo "
<input type='hidden' id='ansid".$r."' value='".$row_myqs->autoid."'>
<tr>
<td>".$r++.".</td>
<td>".$row_myqs->ins_qtn."</td>
<td>".$row_qtns->answer."</td>
<td><input type='number'  class='form-control sum' id='tweight".$r."' value='0'></td></tr>";
}while($row_qtns=$result_qtns->fetchObject());}
else{echo "<tr style='text-align:center'><td colspan='11'>No Pending Client Request</td></tr>";}
?>
</table>


</div>
<div class="row">
<div class="col-lg-3">
<label>Total Weight</label>
<input type="number" name="total_wgt" id='total_wgt' class="form-control" value="0" readonly>	
</div>
<div class="col-lg-3">
<label>Basic Price</label>
<input type="number" name="basic_price" id='basic_price' class="form-control" value="<?php echo $row_price->price1; ?>" readonly>	
</div>
<div class="col-lg-3">
<label>Total Insurance Cover</label>
<input type="number" name="total_amount" id='total_amount' class="form-control" readonly>	
</div>
<div class="col-lg-3"><br>
<button class='btn btn-sm btn-success btn-block' onClick="submit_assessment()">Approve</button>                 

</div>
</div>
</div>

</div>

</div>
 <script>
var textboxes = document.querySelectorAll(".sum");
textboxes.forEach(function(box){
    box.addEventListener("keyup", sumAll);
});
function sumAll(){
    var total = 0;
    textboxes.forEach(function(box){
        var val;
        if (box.value == "") val = 0;
        else val = parseInt(box.value);
        total += val;
    });
    document.getElementById("total_wgt").value = total;
    document.getElementById("total_wgt").style.color = 'blue';
    //basic price
    var basicp = document.getElementById("basic_price").value;
    document.getElementById("basic_price").value=basicp;
    document.getElementById("basic_price").style.color = 'green';
    //total amount
    var myPay = parseInt(total*basicp);
    document.getElementById("total_amount").value=myPay;
    document.getElementById("total_amount").style.color ='red';
}

var page_loading=function(){$("#loadin").animate({width: "100%", height: "100%", opacity: "0.4"},500);}
var page_close=function(){$("#loadin").animate({width: "0%", height: "0%", opacity: "0"},500);}
</script>

<?php lscripts(); ?>

</body>
</html>