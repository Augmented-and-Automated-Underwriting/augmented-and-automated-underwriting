<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php kheader(); ?>

<script>
function get_sub(){
setTimeout(page_loading,10);
var sub_val=$("#sub_val").val();
var page="get_subval";

$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,sub_val:sub_val},
success: function(output){
setTimeout(page_close,10);
document.getElementById("output_sub").innerHTML=output;
if(sub_val != ''){setTimeout(sub_anim,500);}
}
});
return false;
}

function get_small(){
setTimeout(page_loading,10);
var small_val=$("#small_val").val();
var sub_val=$("#sub_val").val();
var page="get_smallval";

$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,small_val:small_val,sub_val:sub_val},
success: function(output){
setTimeout(page_close,10);
document.getElementById("output_small").innerHTML=output;
if(small_val != ''){setTimeout(small_anim,500);}
}
});
return false;
}  



function submit_cat(){
if($("#clientid").val() !='' && $("#planid").val() !=''){
var plan_type=$("#plan_type").val();
var planid=$("#planid").val();
var cid=$("#cid").val();
var clientid=$("#clientid").val();
var client_age=$("#client_age").val();
var client_gender=$("#client_gender").val();
var marital_status=$("#marital_status").val();
var count_field=$("#count_field").val();
var emp_status=$("#emp_status").val();
var prem_term=$("#prem_term").val();
var pac=$("#pac").val();
var page="assessment_details"
var y;
for(y=1;y<=count_field;y++){
var no=y;
var qtn_answer=$("#qtn_answer"+y).val();
var questionid=$("#questionid"+y).val();
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,no:no,questionid:questionid,planid:planid,clientid:clientid,client_age:client_age,client_gender:client_gender,marital_status:marital_status,emp_status:emp_status,qtn_answer:qtn_answer,plan_type:plan_type,cid:cid,pac:pac,prem_term:prem_term},
beforeSend:function(){
setTimeout(page_loading,10);},
success: function(output){
setTimeout(page_close,10);
if(output==1){
document.getElementById("small_form").innerHTML='';
document.getElementById("alert_out").innerHTML="<div class='alert alert-success'>Plan Assessment submitted. </div>";}
else{document.getElementById("alert_out").innerHTML="<div class='alert alert-success'>Plan Assessment not submitted. </div>";}
var close_alert=function(){$("#alert_out").slideUp();
document.getElementById("alert_out").innerHTML='';$("#alert_out").slideDown();}
setTimeout(close_alert,4000);
}
});
}
return false;}
}


function change_values(obj){
var page="split_id";
var val=obj.value;
var tt=obj.id;

$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,val:val,tt:tt},
success: function(user_out){
$("#lt"+obj.id).show();
document.getElementById("lt"+obj.id).innerHTML=user_out;
}
});
return false; }

function get_values(names,uid,obj){
document.getElementById("id"+obj).value=uid;
document.getElementById(obj).value=names;
$("#lt"+obj).slideUp();}

</script>
<style type="text/css">
table{ width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}
th{background: #333;color: #ffffff;font-weight: bold;}
td, th{padding: 6px;text-align: left;}  

@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }

.td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
.td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
.td:nth-of-type(1):before{content: "No";}
.td:nth-of-type(2):before{content: "Category";}
.td:nth-of-type(3):before{content: "Question";}
.td:nth-of-type(4):before{content: "Answer";}

}

.inner_body{height:400px;overflow-y: scroll;padding-left:5%;}
</style>
<script src="../js/jquery.js"></script>
<script src="../js/thousandseparator.js"></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div id='loadin' style='position:absolute;z-index:20;width:0%;height:0%;background-color: grey;opacity:0.4;overflow-y: hidden'>
<img src='../js/loadin.gif' style='width:20%;margin-left:40%;margin-top:20%;'>
</div>
<input type='hidden' id='sub_val'>
<input type='hidden' id='small_val'>
<?php
$yy=date("Y"); $fyy=substr($yy,2,2);
$mm=date("m"); $dd=date("d");
$hi=date("h"); $mi=date("i");
$sa=date("sa"); $sa=date("s");
$id=$rolenumber.$fyy.$mm.$dd.$hi.$mi.$sa;
echo "<input type='hidden' id='cid' value='".$id."'>
<input type='hidden' id='clientid' value='".$rolenumber."'>
";
?>
<!-- small categories-->
<div class="col-lg-10" id="smallcat" style="margin-left:-200%;position:absolute;z-index:12;">
<div class="card card-success">
<div class="card-header">
<h4 class="card-title">Request Details</h4>

</div>
<div class="card-body"> 
<div style='padding-left:5%' id="output_small" class="inner_body">

</div>
<button class='btn btn-sm btn-warning' onClick="back_small()" style='float:left;bottom:5px;'>< Previous </button> 
<button class='btn btn-sm btn-success' onClick="submit_cat()" style='float:right;bottom:5px;'>Submit</button>                 

</div>
</div>
</div>
<!-- small categories-->

<!-- sub categories-->
<div class="col-lg-10" id="subcat" style="margin-left:-200%;position:absolute;z-index:9;">
<div class="card card-info">
<div class="card-header">
<h4 class="card-title">Insurance Plans</h4>

</div>
<div class="card-body">
<div class='inner_body' id="output_sub">

</div>
<button class='btn btn-sm btn-warning' onClick="back_sub()" style='float:left;bottom:5px;'>< Previous </button>

<button class='btn btn-sm btn-primary' onClick="get_small()" style='float:right;bottom:5px;'>Next ></button>

</div>
</div>
</div>
<!-- sub categories-->

<!--intial categories-->

<div id='main_form' >
<div class="card card-primary">
<div class="card-header">
<h4 class="card-title">Insurance Policy</h4></div>
<div class="card-body" >
<div class='inner_body'>
<?php
$result_policies=$dbh->query("select * from scrap where type='policy' order by item2 asc");
$row_policies=$result_policies->fetchObject();
$count_policies=$result_policies->rowcount();

if($count_policies>0){ do{ ?>
<table width='100%'>
<tr><td width='10%'>
<input onClick="chk_sub('<?php echo $row_policies->item; ?>')" type="radio" name='policy' value="" >
</td>
<td > <?php echo $row_policies->item2; ?></td></tr>
<tr><td colspan='2'><br></td></tr></table>

<?php }while($row_policies=$result_policies->fetchObject());}
else{echo "There is no data as yet."; }

?>
</div>

<button class='btn btn-sm btn-primary' onClick="get_sub()" style='float:right;bottom:5px;'>Next ></button>
</div>
</div>
</div>
<!--intial categories-->



<script>
function chk_sub(sub){document.getElementById("sub_val").value=sub;
$("#main_form").animate({width: "100%"},500); }

function chk_small(sub){document.getElementById("small_val").value=sub;}

var sub_anim=function(){$("#subcat").animate({left : "200%"},500);}
var small_anim=function(){$("#smallcat").animate({left : "200%"},500);} 

function back_sub(){$("#subcat").animate({left : "-200%"},500);}
function back_small(){$("#smallcat").animate({left : "-200%"},500);}


var page_loading=function(){$("#loadin").animate({width: "100%", height: "100%", opacity: "0.4"},500);}
var page_close=function(){$("#loadin").animate({width: "0%", height: "0%", opacity: "0"},500);}

</script>
<?php lscripts(); ?>
</body>
</html>
