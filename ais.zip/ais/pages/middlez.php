<?php
session_start();
if(isset($_SESSION["rolenumber"])){$rolenumber=$_SESSION["rolenumber"];}
else{$rolenumber='';}

include("connect.php");
$page=$_POST["page"];
if($page=="submit_client"){include("submit_client.php");}
elseif($page=="plan_cats"){include("split_val.php");}
elseif($page=="get_policy"){include("get_policy.php");}
elseif($page=="submit_nominees"){include("submit_nominees.php");}
elseif($page=="client_pols"){include("client_paypols.php");}
elseif($page=="get_subval"){include("output_sub.php");}
elseif($page=="get_smallval"){include("output_small.php");}
elseif($page=="submit_assessment"){include("submit_assessment.php");}
elseif($page=="assessment_details"){include("submit_assessment2.php");}
elseif($page=="approve_assessment"){include("approve_assessment.php");}
?>