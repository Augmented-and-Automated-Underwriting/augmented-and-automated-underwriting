<?php

date_default_timezone_set('Africa/Kampala');

if (isset($_GET['selector'])){$selector=$_GET['selector'];} 
elseif (isset($_POST['selector'])){$selector=$_POST['selector'];} 
elseif (isset($altselector)){$selector=$altselector;}
else 
{$selector= ""; 
/*echo "No Selector
<br>news1
<br>manylogins
<br>dailyplans
<br>tutorial
<br>fridayreport";*/
}

//if (isset($_GET['send'])){$send="1";} else {$send=""; echo "No send";}

$goodreceivers="and status='active' and email!=''";

function mailtrigger()
{

global $to;
global $subject;
global $message;
$headers = 'From: info@teacherderricksenny.com' . "\r\n" .
'Reply-To: info@teacherderricksenny.com' . "\r\n" .
'X-Mailer: PHP/' . phpversion();
$headers .= "MIME-Version: 1.0\r\n";
$headers .= 'Cc: info@teacherderricksenny.com' . "\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
mail($to, $subject, $message, $headers);
}

//echo $altselector;

if ($selector=="approve_client"){
include("../connect.php");
$send=1;
$subject="AUGMENTED & AUTOMATED INSURANCE ACCOUNT LOGINS";
$to=$client_email;

$message = "<font size='4px'>Hello <b>".$client_name."</b>, <br>You have successfully registered for Augmented & Automated Insurance System. <p>Please Find Your Username & password below ,
<center>
<span>Username:</span><span style='color:maroon;font-weight:bold'>".$myusername."</span><br>
<span>Password:</span></span style='color:maroon;font-weight:bold'>".$mypassword."</span>
<br>
<b>Disclaimer: This is an auto-generated mail. Please do not reply to it.</b>

</center> </font>
";

//include ('index.php');

     // echo $message;
mailtrigger();
}









?>