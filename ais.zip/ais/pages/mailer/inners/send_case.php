<?php 
include("connect.php");
$goodreceivers="and email!=''";
$result_advocate=$dbh->query("select * from users where userid='$userid'");
$row_advocate=$result_advocate->fetchObject();
$result_client=$dbh->query("select * from users where rolenumber='$rolenumber'");
$row_client=$result_client->fetchObject();
do{
$to=$row_advocate->email;
$receiver=$row_advocate->firstname;
$receivername2=$row_advocate->lastname;
$url="https://vlu.ckuditechnologies.com";
//$buttonurl="https://ncu.eastafrica.website/t.php?w=".$waybillid;

$subject="Virtual Legal Utopia";
$heading="Virtual legal Utopia | Pending Case(s)";
$greeting="<h2>Hi ".$receiver.",</h2>";
//$buttonwords="Track Progress";
$body="
<span style='font-size:15px;'><p>New case filed from <b style='color:maroon'>".$row_client->firstname." ".$row_client->lastname."</b> contact: <b style='color:maroon'>".$row_client->phonenumber."</b></p></span>


<p>";


$body.= "<table width='100%' style='font-size:15px;'>
<tr><td colspan='3'><span style='font-size:15px;'><b><h4>".$casetitle."</h4></span>
".$details."</td></tr>
";

$body.= "</table>
<p></p><p> Thank you for Using Virtal Utopia Legal Management System<br> Click to Visit System : <a href='http://vlu.ckuditechnologies.com' style='font-size:16px;'>Virtual Legal Utopia Management System</a>";

$footer="<span style='font-size:13px;'>This email is meant for ".$receiver." ".$receivername2."
<p style='color:#242582'>Sent by <a href='http://vlu.ckuditechnologies.com' style='color:#242582'>Virtal Legal Utopia Management System</a></p>
<p style='color:#242582'>+256-754564240 | <a href='mailto:' style='color:#242582'>systems@ckuditechnologies.com</a> | <a href='http://ckuditechnologies.com' style='color:#242582'>www.ckuditechnologies.com</a><br></p>
<b width='100%' style='font-size:15px;'>Disclaimer: This is an auto-generated mail. Please do not reply to it.</b>

";

$message="<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
    <meta name='viewport' content='width=device-width'/>

    <!-- For development, pass document through inliner -->

    <style type='text/css'>
* { margin: 0; padding: 0; font-size: 100%; font-family: 'Avenir Next', 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; line-height: 1.65; }

img { max-width: 100%; margin: 0 auto; display: block; }

body, .body-wrap { width: 100% !important; height: 100%; background: #f8f8f8; }

a { color: #71bc37; text-decoration: none; }

a:hover { text-decoration: underline; }

.text-center { text-align: center; }

.text-right { text-align: right; }

.text-left { text-align: left; }

.button { display: inline-block; color: white; background: #242582; border: solid #242582; border-width: 10px 20px 8px; font-weight: bold; border-radius: 4px; width:90%; }

.button:hover { text-decoration: none; }

h1, h2, h3, h4, h5, h6 { margin-bottom: 20px; line-height: 1.25; }

h1 { font-size: 32px; }

h2 { font-size: 28px; }

h3 { font-size: 24px; }

h4 { font-size: 20px; }

h5 { font-size: 16px; }

p, ul, ol { font-size: 16px; font-weight: normal; margin-bottom: 20px; }

.container { display: block !important; clear: both !important; margin: 0 auto !important; max-width: 580px !important; border: solid 1px #242582;}

.container table { width: 100% !important; border-collapse: collapse; }

.container .masthead { padding: 40px 0; background: #32CD32; color: white; }

.container .masthead h1 { margin: 0 auto !important; max-width: 90%;  }

.container .content { background: white; padding: 30px 35px; }

.container .content.footer { background: none; border:none !important; }

.container .content.footer p { margin-bottom: 0; color: #888; text-align: center; font-size: 14px; border:none !important;}

.container .content.footer a { color: #888; text-decoration: n one; font-weight: bold; border:none !important;}

.container .content.footer a:hover { text-decoration: underline; border:none !important;}

    

    </style>
</head>
<body>
<table class='body-wrap'>
    <tr>
        <td class='container'>

            <!-- Message start -->
            <table>
                <tr>
                    <td align='center' class='masthead'>

                        <h3>".$heading."</h3>

                    </td>
                </tr>
                <tr>
                    <td class='content'>

                        

                      ".$greeting.$body."

                      

        </td>
    </tr>
    <tr>
        <td class='container' style='border-left:none !important; 'border-right:none !important;'>

            <!-- Message start -->
            <table style='border:none !important;'>
                <tr style='border:none !important;'>
                    <td class='content footer' align='center' style='border:none !important;'>
                        ".$footer."
                    </td>
                </tr>
            </table>

        </td>
    </tr>
</table>
</body>
</html>";
//echo $message;

if($send==1){mailtrigger();}

}while($row_advocate=$result_advocate->fetchObject());
?>