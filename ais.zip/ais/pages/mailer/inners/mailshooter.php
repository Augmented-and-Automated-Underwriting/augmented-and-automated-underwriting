<?php
date_default_timezone_set('Africa/Kampala');


if (isset($_GET['selector'])){$selector=$_GET['selector'];} 
elseif (isset($_POST['selector'])){$selector=$_POST['selector'];} 
elseif (isset($alternativeselector)){$selector=$alternativeselector; $send=1;}
else {$selector= ""; echo "No Selector";}

//if (isset($_GET['send'])){$send="1";} else {$send=""; /*echo "No send";*/}


function mailtrigger()
{
include("connect.php");

global $to;
global $subject;
global $message;
$headers = 'From: systems@ckuditechnologies.com' . "\r\n" .
'Reply-To: systems@ckuditechnologies.com' . "\r\n" .
'X-Mailer: PHP/' . phpversion();
$headers .= "MIME-Version: 1.0\r\n";
$headers .= 'Cc: dkazibwe@ckuditechnologies.com' . "\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
mail($to, $subject, $message, $headers);
}

if ($selector=="appoitnment"){ include("send_appoint.php"); }
elseif ($selector=="case") {include("send_case.php");}
elseif ($selector=="probono") {include("send_probono.php");}
?>   