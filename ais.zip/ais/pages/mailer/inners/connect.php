<?php

/*** mysql hostname ***/
$hostname = 'localhost';

/*** mysql username ***/
$username = 'ckudtccj_davinnie';

/*** mysql password ***/
$password = 'davinnie@2019';

$dbname="ckudtccj_vlu";

try {
    $dbh = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);
    
    }
catch(PDOException $e)
    {
    echo $e->getMessage();
    }
?>
