<?php
$small_val=$_POST["small_val"];
$sub_val=$_POST["sub_val"];

$result_scrap2=$dbh->query("select * from scrap where type='plan' and item='$small_val'");
$row_scrap2=$result_scrap2->fetchObject();
?>
<div id='alert_out'></div>
<div style='font-size:18px;text-align:center;'><u><b><?php echo $row_scrap2->item2; ?> Details</b></u></div>
<div class="col-lg-12"><br></div>
<form id='small_form'>
<div class='row'>
<div class='col-lg-4'><label>Age:</label>
	<input type='number' class='form-control' id='client_age' placeholder='Enter Age'>
</div>
<div class='col-lg-4'><label>Gender:</label>
<select id="client_gender" class="form-control">
<option value="">Select Gender</option>
<option value="Male">Male</option>
<option value="Female">Female</option>  
</select>
</div>
<div class='col-lg-4'>
  <label>Marital Status</label>
<select class='form-control' id='marital_status'>
<option value=''>Select</option>
<option value='single'>Single</option>
<option value='married'>Married</option>
<option value='divorced'>Divorced</option>
</select>
</div>
<div class='col-lg-4'>
  <label>Employment Status</label>
<select class='form-control' id='emp_status'>
<option value=''>Select</option>
<option value='employee'>Employed</option>
<option value='employer'>Employer</option>
<option value='unemployed'>Un-Employed</option>
<option value="student">Student</option>
</select>
</div>
<div class="col-lg-4">
<label>Premium Terms</label>	
<select id="prem_term" class="form-control">
<option value="">Select</option>
<?php
$result_prems=$dbh->query("select * from scrap where type='prem_term'");
$count_prems=$result_prems->rowCount();
$row_prems=$result_prems->fetchObject();
if($count_prems>0){do{
echo "<option value='".$row_prems->item."'>".$row_prems->item2."</option>";	
}while($row_prems=$result_prems->fetchObject());}
?>	
</select>	
</div>
<div class="col-lg-4">
<label>Packages</label>	
<select id="pac" class="form-control">
<option value="">Select</option>
<?php
$result_pac=$dbh->query("select * from scrap where type='pac'");
$count_pac=$result_pac->rowCount();
$row_pac=$result_pac->fetchObject();
if($count_pac>0){do{
echo "<option value='".$row_pac->item."'>".$row_pac->item2."</option>";	
}while($row_pac=$result_pac->fetchObject());}
?>	
</select>	
</div>
<div class='col-lg-12'><br></div>
<div style='font-size:18px;text-align:center;color: maroon;'><u><b>Assessment Details</b></u></div>
<table >
	<thead>
	<tr>
		<th>No</th>
		<th>Category</th>
		<th>Question</th>
		<th>Answer</th>
	</tr>
</thead>
<?php
$result_questions=$dbh->query("select * from assessment_qtns where plan='$small_val'"); 
$row_questions=$result_questions->fetchObject(); 
$count_questions=$result_questions->rowCount();
echo "<input type='hidden' id='count_field' value='".$count_questions."'>";
if($count_questions>0){$y=1;$x=1; do{
$r=$y++;
echo"
<input type='hidden' id='plan_type' value='".$sub_val."'>
<input type='hidden' id='planid' value='".$row_questions->plan."'>
<tr>
<td class='td'>".$x++."</td>
<td class='td'>".$row_questions->item_name."</td>
<td class='td'>".$row_questions->ins_qtn."?</td>
";
if($row_questions->qtn_type==1){
echo "<td>
<input type='hidden' id='questionid".$r."' value='".$row_questions->autoid."'>
<select class='form-control' id='qtn_answer".$r."'>
<option value=''>Select</option>
<option value='Yes'>Yes</option>
<option value='No'>No</option>
</select>
  </td>";}
  elseif($row_questions->qtn_type==2){
  echo "
  <td>
  <input type='hidden' id='questionid".$r."' value='".$row_questions->autoid."'>
  <textarea id='qtn_answer".$r."' class='form-control' placeholder='Enter Details'></textarea></td>";
  } 
echo "</tr>";  
}while($row_questions=$result_questions->fetchObject()); }
else{echo "<tr><td colspan='4' align='center'>There is assessment attached to this plan.</td></tr>"; }

?>
</table>
</form>
