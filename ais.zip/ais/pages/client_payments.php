<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{ width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}
th{background: #333;color: #ffffff;font-weight: bold;}
td, th{padding: 6px;text-align: left;}  

@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }

td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "PayDate";}
td:nth-of-type(3):before{content: "Approver";}
td:nth-of-type(4):before{content: "Abouts";}
td:nth-of-type(5):before{content: "Amount";}
td:nth-of-type(6):before{content: "Balance";}
td:nth-of-type(7):before{content: "Next PayDate";}
}

.inner_body{height:400px;overflow-y: scroll;padding-left:5%;}
</style>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h4 class="card-title"><b>Approved Payments</b></h4></div>
<div class="card-body">
<table>
<thead>
<tr>
<th>No</th>
<th>PayDate</th>
<th>Approver</th>
<th>Policy Abouts</th>
<th>Amount Paid</th>
<th>Balance</th>
<th>Next PayDate</th>
</tr>  
</thead>  
<?php
$rolenumber=$_SESSION['rolenumber'];
$result_payment=$dbh->query("select * from payments where status=0 and clientid='$rolenumber' order by autoid desc");
$row_payment=$result_payment->fetchObject(); 
$count_payment=$result_payment->rowCount();
if($count_payment>0){ $r=1; do{
$result_item=$dbh->query("select * from client_policies where clientid='$row_payment->clientid'");
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();	
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_item->planid'"); 
$row_plan=$result_plan->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->pac'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem'"); 
$row_prem=$result_prem->fetchObject();    
if($row_pac->item3<=1){$ident="person";}
else{$ident="people";}
$result_user=$dbh->query("select * from users where rolenumber='$row_payment->ouruser'"); 
$row_user=$result_user->fetchObject();	
echo "<tr>
<td>".$r++.".</td>
<td>".$row_payment->payed_on."<br><span style='color:blue'></td>
<td>".$row_user->firstname." ".$row_payment->lastname."<br><span style='color:maroon'>[".$row_user->phonenumber."]</span></td>
<td>".$row_plan->item2."<br><span>[".$row_pol->item2."]</span><br><span style='color:maroon'>".$row_pac->item2."-[".$row_pac->item3." ".$ident."]</span></td>
<td>".number_format($row_payment->amount_paid)."<br><span style='color:maroon'>[".$row_prem->item2."]</span></td>
<td>".number_format($row_payment->balance)."</td>
<td>".$row_payment->next_pay."</td>
</tr>";
}while($row_payment=$result_payment->fetchObject());}
else{echo "<div>No Policies Registered At The Moment</div>";}
?>
</table>
</div>
</div>
</div>  
<?php lscripts(); ?>

</body>
</html>