<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}
th{background: #333;color: #ffffff;font-weight: bold;}
td, th{padding: 6px;border:2px solid #0000ff;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
.td{border: none;border-bottom: 1px solid #0000ff;position: relative;padding-left: 50%;}
.td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
.td:nth-of-type(1):before{content: "No";}
.td:nth-of-type(2):before{content: "Package";}
.td:nth-of-type(3):before{content: "Abouts";}
.td:nth-of-type(4):before{content: "Price";}
.td:nth-of-type(5):before{content: "Term";}
.td:nth-of-type(6):before{content: "Action";}
} 
</style> 
<script src='../js/jquery.js'></script>
<script src='../js/thousandseparator.js'></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<?php
$planid=$_GET['planid'];
$name=$_GET['name'];
?>
<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h4 class="card-title"><b><?php echo $name ?> Packages</b></h4></div>
<div class="card-body">
<?php
if(isset($_POST['submit_request'])){
$clientid=$rolenumber;
$planid=$_POST['planid'];
$plan_type=$_POST['plan_type'];
$branch_name=$_POST['branch_name'];
$pac=$_POST['pac'];
$prem=$_POST['prem'];
$price=$_POST['price'];
$dateadded=date('Y-m-d');
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$reqid="rq".$fyy.$mm.$dd.$hi.$mi.$fsa;
$insert_request=$dbh->query("insert into client_policies(planid,plan_type,clientid,dateadded,branch,reqid,pac,prem,price) value('$planid','$plan_type','$clientid','$dateadded','$branch_name','$reqid','$pac','$prem','$price')");
if($insert_request){echo "<div class='alert alert-success'>Success: Request added but pending approval</div>"; }else{echo "<div class='alert alert-danger'>Failed: Make sure branch is attached</div>";}	
}
?>	
<table>
<thead>
<tr>
<th>No</th>
<th>Package</th>
<th>Plan Abouts</th>
<th>Price</th>
<th>Term</th>
<th>Action</th>
</tr>  
</thead>  
<?php
$result_item=$dbh->prepare("select * from itempricing where planid=:memid");
$result_item->bindParam(':memid',$planid);
$result_item->execute(); 
$row_item=$result_item->fetchObject(); 
$count_item=$result_item->rowCount();
if($count_item>0){ $r=1; do{
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_item->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_item->package'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_item->prem_term'"); 
$row_prem=$result_prem->fetchObject();    
if($row_pac->item3<=1){$ident="person";}
else{$ident="people";}
echo "<tr>
<td class='td'>".$r++.".</td>
<td class='td'>".$row_pac->item2."<br><span style='color:maroon'>[".$row_pac->item3." ".$ident."]</span></td>
<td class='td'>".$name."<br><span style='color:maroon'>[".$row_pol->item2."]</span></td>
<td class='td'>UGX:".number_format($row_item->price1)."</td>
<td class='td'>".$row_prem->item2."</td>
<td class='td'><button onClick='show_dis(".$row_item->autoid.")' class='btn btn-sm btn-primary btn-block'>Request</button></td>
</tr><tr></tr>
<tr id='dis_edit".$row_item->autoid."' style='border-bottom: 2px solid red;border-top: 2px solid red;display:none;'><form method='post'>
<input type='hidden' name='planid' value='".$row_item->planid."'>
<input type='hidden' name='plan_type' value='".$row_item->plan_type."'>  
<input type='hidden' name='pac' value='".$row_pac->item."'>
<input type='hidden' name='prem' value='".$row_prem->item."'>
<input type='hidden' name='price' value='".$row_item->priceid."'>      
<td colspan='6'><div class='row'>
<div class='col-lg-2'>Policy : 
<input type='text' class='form-control' value='".$row_pol->item2."' readonly></div>
<div class='col-lg-2'>Plan : 
<input type='text' class='form-control' value='".$name."' readonly></div>
<div class='col-lg-2'>Package : 
<input type='text' class='form-control' value='".$row_pac->item2."' readonly></div>
<div class='col-lg-2'>Premium Term : 
<input type='text' class='form-control' value='".$row_prem->item2."' readonly></div>
<div class='col-lg-2'>Amount : 
<input type='text' class='form-control' value='".$row_item->price1."' readonly></div>
<div class='col-lg-2'>Nearest Branch :
<select class='form-control' name='branch_name' required>
<option>Select Branch</option>";
$result_scrap=$dbh->query("select * from scrap where type='branch'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
$result_loc=$dbh->query("select * from scrap where type='loc' and item='$row_scrap->item3'"); 
$row_loc=$result_loc->fetchObject(); 
$count_loc=$result_loc->rowCount();  
echo "<option value='".$row_scrap->item."'>".$row_scrap->item2."-<span>[".$row_loc->item2." Branch]</span></option>";
}while($row_scrap=$result_scrap->fetchObject());}
echo "</select></div></div>
<div class='col-lg-12'><br></div>      
<div class='form-group'><input type='submit' name='submit_request' class='btn btn-sm btn-success form-control' value='Submit Request'></div></td></form></tr>";
}while($row_item=$result_item->fetchObject());}
else{echo "<div>No Packages In this Plan</div>";}
?>
</table>
</div>
</div>
</div>  
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
</script> 
<?php lscripts(); ?>

</body>
</html>