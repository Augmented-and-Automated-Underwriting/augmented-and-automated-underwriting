<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style>
.blink {
animation: blink-animation 1s steps(5, start) infinite;
-webkit-animation: blink-animation 1s steps(5, start) infinite;
}
@keyframes blink-animation {
to {
visibility: hidden;
}
}
@-webkit-keyframes blink-animation {
to {
visibility: hidden;
}
}
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div id='loadin' style='position:absolute;z-index:9;width:0%;height:0%;background-color: grey;opacity:0.4;overflow-y: hidden'>
<img src='../dist/img/loadin.gif' style='width:20%;margin-left:40%;margin-top:20%;'>
</div> 
<?php kleftbar(); ?>
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Manage Clients Accounts</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Pending Approval</a></li>
<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Approved Clients</a></li>   </ul>
</div><!-- /.card-header -->
<div class="card-body">
<?php
if(isset($_POST['approve_client'])){
$userid=$_POST['userid'];
$status='active';
$status2=1;
$ouruser=$rolenumber;
$result_user1=$dbh->query("select * from users where role='cls' and rolenumber='$userid'");
$count_user1=$result_user1->rowCount();
$row_user1=$result_user1->fetchObject();
if($count_user1>0){
$result_keys=$dbh->query("select * from keyfields where rolenumber='$row_user1->rolenumber'");
$row_keys=$result_keys->fetchObject(); 
$client_email=$row_user1->email;
$client_name=$row_user1->firstname;
$myusername=$row_keys->username;
$mypassword=$row_keys->password;   
}
//email
$altselector="approve_client";

include('mailer/mailshooter.php');  
$update_client=$dbh->query("UPDATE keyfields SET status='$status2' WHERE rolenumber='$userid'");
$update_users=$dbh->query("UPDATE users SET ouruser='$ouruser', status='$status' WHERE rolenumber='$userid'");
if($update_users&$update_client){echo "<div class='alert alert-success'>Success: Client Account Activated</div>";}
else{echo "<div class='alert alert-danger'>Failed: Account Not Activated</div>";}
}
?>  
<?php
if(isset($_POST['reject_request'])){
$userid=$_POST['userid'];
$approved_on=date('Y-m-d');
$approver_comment=$_POST['approver_comment'];
$status=2;
$ouruser=$rolenumber;
$insert_notifications=$dbh->query("insert into notifications(clientid,about,ouruser) values('$userid','$approver_comment','$ouruser')");
if($insert_notifications){echo "<div class='alert alert-success'>Notification Sent</div>";}
$update_users=$dbh->query("UPDATE users SET ouruser='$ouruser',status='$status' WHERE rolenumber='$userid'");
if($update_users){echo "<div class='alert alert-success'>Success: Client Account Rejected</div>";}
else{echo "<div class='alert alert-danger'>Failed: Proccess Failed</div>";}
}
?>
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Full Name</th>
<th>NIN Number</th>
<th>Phone Number</th>
<th>Address</th>
<th>Occupation</th>
<th>Gender</th>
<th>Marital Status</th>
<th colspan="2">Action</th>
</tr>
</thead>
<?php
if($role=="agt"){$daquery=" and ouruser='$rolenumber'";}
else{$daquery=" ";}
$result_user=$dbh->query("select * from users where role='cls' and status='0' $daquery");
$count_user=$result_user->rowCount();
$row_user=$result_user->fetchObject();
if($count_user>0){$r=1;do{
echo "
<tr>
<td>".$r++."</td>
<td>".$row_user->firstname." ".$row_user->lastname."</td>
<td>".$row_user->nin_number."</td>
<td>".$row_user->phonenumber."</td>
<td>".$row_user->address."</td>
<td>".$row_user->occupation."</td>
<td>".$row_user->gender."</td>
<td>".$row_user->marital."</td>
<td class='td'>
<form method='post'>
<input type='hidden' name='userid' value='".$row_user->rolenumber."'> 
<input type='submit' name='approve_client' class='btn btn-sm btn-success' value='Approve'>
</form>
</td>
<td class='td'><button onClick='show_dis2(".$row_user->autoid.")' class='btn btn-sm btn-danger btn-block'>Reject</button></td>
</tr><tr></tr>
<tr id='dis_edit2".$row_user->autoid."' style='border-bottom: 2px solid red;border-top: 2px solid red;display:none;'><form method='post'>
<input type='hidden' name='userid' value='".$row_user->rolenumber."'>     
<td colspan='11'><div class='row'>
<div class='col-lg-10'><label>Comment</label>
<input type='text' class='form-control' name='approver_comment' placeholder='Add Comment'></div>     
<div class='col-lg-2'><br>
<input type='submit' name='reject_request' class='btn btn-sm btn-warning btn-block' value='Submit'></div></di></td></form></tr>";
}while($row_user=$result_user->fetchObject());}
?>
</table>


</div>
<!-- /.tab-pane -->
<div class='tab-pane' id='tab_2'>

<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Full Name</th>
<th>NIN Number</th>
<th>Phone Number</th>
<th>Address</th>
<th>Birth Date</th>
<th>Status</th>
</tr>
</thead>
<?php
if($role=="agt"){$daquery=" and ouruser='$rolenumber'";}
else{$daquery=" ";}
$result_user=$dbh->query("select * from users where role='cls' and status='active' $daquery");
$count_user=$result_user->rowCount();
$row_user=$result_user->fetchObject();
if($count_user>0){$r=1;do{
echo "
<tr>
<td>".$r++."</td>
<td>".$row_user->firstname." ".$row_user->lastname."</td>
<td>".$row_user->nin_number."</td>
<td>".$row_user->phonenumber."</td>
<td>".$row_user->address."</td>
<td>".$row_user->dbirth."</td>
<td><a href='client_status.php?ourclient=".$row_user->rolenumber."'><button class='btn btn-sm btn-success'><i class='fa fa-eye'>View Status</i></button></a></td>
</tr>
";  
}while($row_user=$result_user->fetchObject());}
?>
</table>

</div>

</div>

</div>
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
function show_person(){ $("#newperson").toggle(500);}
var page_loading=function(){$("#loadin").animate({width: "100%", height: "100%", opacity: "0.4"},500);}
var page_close=function(){$("#loadin").animate({width: "0%", height: "0%", opacity: "0"},500);}
</script>
<?php lscripts(); ?>
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
function show_dis2(ai){$("#dis_edit2"+ai).toggle(500);}
</script>
</body>
</html>
