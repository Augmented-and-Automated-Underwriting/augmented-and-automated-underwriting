<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<script type="text/javascript">
function change_values(obj){
var page="client_pols";
var uid=obj.value;
var tt=obj.id;
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,uid:uid,tt:tt},
success: function(user_out){
document.getElementById("div_cp").innerHTML=user_out}
});

return false; }
</script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<?php kleftbar(); ?>
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Enter Client Payments</b></h3>
</div><!-- /.card-header -->
<div class="card-body">
<?php
if(isset($_POST['submit_payment'])){
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$payid="pmt".$fyy.$mm.$dd.$hi.$mi.$fsa;
$client_name=$_POST['client_name'];
$reqid=$_POST['reqid'];
$expected_price=$_POST['plan_price'];
$exprice=intval(preg_replace('/[^\d.]/', '', $expected_price));
$amount_paid=$_POST['amount_paid'];
$payprice=intval(preg_replace('/[^\d.]/', '', $amount_paid));
$balance=$_POST['balance'];
$rmbal=intval(preg_replace('/[^\d.]/', '', $balance));
$pay_date=$_POST['pay_date'];
$next_pay_date=$_POST['next_pay_date'];
if($role=='agt'){
$typez='agt';
}else{ $typez='ad'; }
$role=$_SESSION['role'];
if ($role=='agt') {
$status=1;
}else {$status=0;}
$insert_payment=$dbh->query("insert into payments(clientid,reqid,expected_amount,amount_paid,balance,payed_on,next_pay,ouruser,payid,typez,status) values('$client_name','$reqid','$exprice','$payprice','$rmbal','$pay_date','$next_pay_date','$rolenumber','$payid','$typez','$status')");
if($insert_payment){echo "<div class='alert alert-success'>Success: Payment Added</div>";}
else{echo "<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}

?>
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<form method="post" autocomplete="off">  
<div class='row'>
<div class="col-lg-4">
<label>Client</label>  
<select name="client_name" class="form-control" onchange="change_values(this);" id="client_name">
<option>Select Client</option>  
<?php
$result_client=$dbh->query("select * from users where role='cls' order by firstname asc");
$count_client=$result_client->rowCount();
$row_client=$result_client->fetchObject();
if($count_client>0){do{
echo"<option value='".$row_client->rolenumber."'>".$row_client->firstname." ".$row_client->lastname."</option>";
}while($row_client=$result_client->fetchObject());}
?>  
</select>
</div>
<div class="col-lg-4" id="div_cp">
<label>Policy</label>  
<select class="form-control" id="reqid" name="reqid">
  <option>Select</option>
</select>
</div>
<div class="col-lg-4">
  <label>Package</label>
<input type="text" name="package_name" id="package_name" placeholder="Package" class="form-control" readonly="">
</div></div>
<div class="row">
<div class="col-lg-4">
  <label>Term</label>
<input type="text" name="prem_term" id="prem_term" placeholder="Premium Term" class="form-control" readonly>
</div>
<div class="col-lg-4">
<label>Expected Amount</label>  
<input type='text' class='form-control' name="plan_price" id="plan_price" value="0" readonly>
</div>
<div class="col-lg-4">
<label>Paid Amount</label>  
<input type='text' class='form-control' name="amount_paid" id="amount_paid" value="0">
</div></div><div class="col-lg-12"><br></div>
<div class="row">
<div class="col-lg-4">
<label>Balance</label>  
<input type='text' class='form-control' name="balance" id="balance" value="0" readonly>
</div>
<div class="col-lg-4">
<label>Payment Date</label>  
<input type="date" name="pay_date" class="form-control">
</div>
<div class="col-lg-4">
<label>Next Payment Date</label>  
<input type="date" name="next_pay_date" class="form-control">
</div>
</div><div class="col-lg-12"><br></div>
<div class="form-group"><input type="submit" name="submit_payment" class="btn btn-sm btn-info btn-block" value="Submit"></div>
</form>

</div>

</div>

</div>

</div>

<?php lscripts(); ?>
 <script>
var countnewitems=function() {
if(document.getElementById('reqid').value==''){var reqid =''; var sitem=''}else{var reqid=document.getElementById('reqid').value; }var sitem=reqid
if(document.getElementById('amount_paid').value==''){var amount_paid =0; }else{var amount_paid=document.getElementById('amount_paid').value; }
<?php
$result_pols=$dbh->query("select * from client_policies where autoid>0");
$row_pols=$result_pols->fetchObject();
$count_pols=$result_pols->rowCount();
if($count_pols>0){ do{ 
$result_price=$dbh->query("select * from itempricing where priceid='$row_pols->price'"); 
$row_price=$result_price->fetchObject();
$result_pac=$dbh->query("select * from scrap where type='pac' and item='$row_pols->pac'"); 
$row_pac=$result_pac->fetchObject(); 
$result_prem=$dbh->query("select * from scrap where type='prem_term' and item='$row_pols->prem'"); 
$row_prem=$result_prem->fetchObject();    
?>
if(sitem=="<?php echo $row_pols->reqid; ?>"){
var planPrice=parseInt("<?php echo $row_pols->total_amount; ?>");
document.getElementById("plan_price").value=planPrice.toLocaleString();
document.getElementById("plan_price").style.color = 'blue';

var premTerm="<?php echo $row_prem->item2; ?>";
document.getElementById("prem_term").value=premTerm;
document.getElementById("prem_term").style.color = 'blue';

var myPac="<?php echo $row_pac->item2; ?>";
document.getElementById("package_name").value=myPac;
document.getElementById("package_name").style.color = 'blue';

var myBal=parseInt(planPrice-amount_paid);
document.getElementById("balance").value=myBal.toLocaleString();
document.getElementById("balance").style.color ='red';

}
<?php }while($row_pols=$result_pols->fetchObject());} ?>           
}
setInterval(countnewitems,500);
</script>
</body>
</html>
