<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>

<script type="text/javascript">
function change_values(obj){
var page="get_policy";
var val=obj.value;
var tt=obj.id;
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,val:val,tt:tt},
success: function(user_out){
  $("#lt"+obj.id).show();
document.getElementById("lt"+obj.id).innerHTML=user_out;
}
});
return false; }
function get_values(names,uid,obj){
document.getElementById("id"+obj).value=uid;
document.getElementById(obj).value=names;
$("#lt"+obj).hide();

if(obj=="policy"){
var page="plan_cats";
$.ajax({
type: "POST",
url: "middlez.php",
data: {page:page,names:names,uid:uid},
success: function(user_out){
document.getElementById("div_cp").innerHTML=user_out;
}
});
return false;}}
</script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>

<?php
/* 
$role=$_SESSION['role'];
if($role=='cls'){?>
<div class='alert alert-warning' style='text-align:center;font-weight:bold;font-style:italic;'>Hello, <span style='color:maroon'><?php echo $_SESSION['firstname']; ?></span> Your Last Policy Renewal Was On: <span style='color:maroon'><?php echo lastSavedOn(); ?></span></div>    <?php }
*/
?>
<form method='post' action='auto_packages.php' autocomplete="off">
<h5 class="crad-title text-center"><b>Find Your Package</b></h5>    
<div class='row col-lg-12' style='color:maroon;'>  
<div class="col-lg-2">  
<input type="hidden" id="idpolicy" name="policy1">
<label>Insurance Policy</label>
<input type='text' onKeyup="change_values(this)" class='form-control' id='policy' placeholder='Search Insurance Policy' name="policy" required>
<div id='ltpolicy' class='lt'></div>
</div>
<div id="div_cp" class="col-lg-2">
 <label>Insurance Plan</label>      
<select class="form-control" id="planid" name="planid">
<option>Select</option>
</select>
</div> 
<div class="col-lg-2">
<label>Insurance Package</label>  
<select name="package_name" class="form-control">
<option>select</option>
<?php
$result_scrap=$dbh->query("select * from scrap where type='pac'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
  if($row_scrap->item3<=1){$ident="person";}
  else{$ident="people";}
echo "
<option value='".$row_scrap->item."'>".$row_scrap->item2."-<span style='color:maroon'>[".$row_scrap->item3." ".$ident."]</span></option>";
}while($row_scrap=$result_scrap->fetchObject());}
?>  
</select>     
</div>
<div class="col-lg-2">
 <label>Premium Term</label>      
<select name="term_name" class="form-control">
<option>select</option>
<?php
$result_scrap=$dbh->query("select * from scrap where type='prem_term'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
echo "
<option value='".$row_scrap->item."'>".$row_scrap->item2."</option>";
}while($row_scrap=$result_scrap->fetchObject());}
?>  
</select>     
</div>
<div class="col-lg-2">
<label>Min Price</label>      
<input type='number' name='min_price' class='form-control'>
<label>Max Price</label>      
<input type='number' name='max_price' class='form-control'>
</div>
<div class='col-lg-1'>
<br>    
<input type='submit' class='btn btn-sm btn-success btn-block' name='filter' value='Search'></div> 
</div>
</form>

<div class="col-lg-12">
<div class="card card-default">
<div class="card-header"><h3 class="card-title text-center"><b style="font-style: italic;font-size: 30px;">Switch To Digital Insurance(Select Policy)</b></h3></div>
<div class="card-body">
<table class="table table-striped table-bordered">
<tr style="text-align: center;">
<td><a href="view_policy.php?asin=life"><i class="fa fa-ambulance fa-2X" style="color:maroon;"></i><br><b style="color:#000000;">Life Insurance</b></a></td>
<td><a href="view_policy.php?asin=health"><i class="fa fa-stethoscope fa-2X" style="color:maroon;"></i><br><b style="color:#000000;">Health Insurance</b></a></td>   
</tr>
<tr style="text-align:center;">
<td><a href="view_policy.php?asin=motor"><i class="fa fa-car fa-2X" style="color:maroon;"></i><br><b style="color:#000000;">Motor Insurance</b></a></td>
<td><a href="view_policy.php?asin=cycle"><i class="fa fa-bicycle fa-2X" style="color:maroon;"></i><br><b style="color:#000000;">Cycle Insurance</b></a></td>  
</tr>
<tr style="text-align:center;">
<td><a href="view_policy.php?asin=travel"><i class="fa fa-plane fa-2X" style="color:maroon;"></i><br><b style="color:#000000;">Travel Insurance</b></a></td>
<td><a href="view_policy.php?asin=prop"><i class="fa fa-home fa-2X" style="color:maroon;"></i><br><b style="color:#000000;">Property Insurance</b></a></td>
</tr>
<tr style="text-align:center;">
<td><a href="view_policy.php?asin=mobile"><i class="fa fa-phone fa-2X" style="color:maroon;"></i><br><b style="color:#000000;">Mobile Insurance</b></a></td>
<td><a href="view_policy.php?asin=bite"><i class="fa fa-shopping-cart fa-2X" style="color:maroon;"></i><br><b style="color:#000000;">Bite-Size Insurance</b></b></td>  
</tr>
</table>      
</div>
</div>
</div>   
<?php lscripts(); ?>

</body>
</html>