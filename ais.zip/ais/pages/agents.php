<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>

<style>
.blink {
animation: blink-animation 1s steps(5, start) infinite;
-webkit-animation: blink-animation 1s steps(5, start) infinite;
}
@keyframes blink-animation {
to {
visibility: hidden;
}
}
@-webkit-keyframes blink-animation {
to {
visibility: hidden;
}
}
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<?php kleftbar(); ?>
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3">Manage Agents</h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">New Agent</a></li>
<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Registered Agent</a></li>   </ul>
</div><!-- /.card-header -->
<div class="card-body">
<?php
if(isset($_POST['submit_agent'])){
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$branch=$_POST["branch"];
$title='agt';
$fulltitle="Agent";

$linkd=date("Y-m-d h:i:sa");
$datefrom=date("Y-m-d");
$dateto=date("Y-m-d", strtotime( $datefrom." + 90 days" ));

$result_user2=$dbh->prepare("select * from users order by autoid desc");
$result_user2->execute();
$row_user2=$result_user2->fetchObject();
$count_users=$result_user2->rowCount();
if($count_users<0) {do{$rolenumbers=$title.($row_user2->autoid+1);}while($row_user2=$result_user2->fetchObject());}
$rolenumbers=$title.($row_user2->autoid+1);
$ourusername=strtolower(substr($fname,0,1).$lname);
//mails
$client_email=$email;
$client_name=$fname;
$myusername=$ourusername;
$mypassword=$phone; 
$altselector="approve_client";

include('mailer/mailshooter.php');
$result_user=$dbh->query("select * from users where email='$email' or phonenumber='$phone'");
$count_user=$result_user->rowCount();
if($count_user<=0){    
$insert_users=$dbh->prepare("insert into users (firstname,lastname,branch,phonenumber,email,role,rolenumber,fulltitle,username) values('$fname','$lname','$branch','$phone','$email','$title','$rolenumbers','$fulltitle','$ourusername')");
$insert_users->execute();

$insert_keyfields=$dbh->prepare("insert into keyfields (rolenumber,username,password,pswdexpiry,status) values('$rolenumbers','$ourusername','$phone','$dateto','1')");
$insert_keyfields->execute();
echo "<div class='alert alert-success'>Success: Agent Added</div>";
}else{echo "<div class='alert alert-danger'>Failed: make sure all details are filled</div>";}
}
?>
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<form method="post" class='col-lg-12'>  
<div class='row'>
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>First Name</th>
<th>Last Name</th>
<th>Email</th>
<th>Phone</th>
<th>Branch</th>
<th>Action</th>
</tr>
</thead>
<tr>

<td><input type='text' class='form-control' name="fname" placeholder='First Name' required></td>
<td><input type='text' class='form-control' name="lname" placeholder='Last Name' required></td>
<td><input type='email' name='email' class='form-control' placeholder='Email'></td>
<td><input type='text' name='phone' class='form-control' placeholder='Contact'></td>
<td>
<select name="branch" class="form-control">
<option>select</option>
<?php
$result_scrap=$dbh->query("select * from scrap where type='branch'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();
if($count_scrap>0){ $r=1; do{
echo "
<option value='".$row_scrap->item."'>".$row_scrap->item2."</option>";
}while($row_scrap=$result_scrap->fetchObject());}
?>  
</select>   
</td>
<td>
<input type="submit" name="submit_agent" class="btn btn-success btn-sm btn-block" value="Submit">    
</td>
</tr>
</table>
</form>


</div>

</div>
<!-- /.tab-pane -->
<div class='tab-pane' id='tab_2'>

<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>Full Name</th>
<th>Email</th>
<th>Phone</th>
<th>Branch</th>
</tr>
</thead>
<?php
$result_user=$dbh->query("select * from users where role='agt' order by firstname asc");
$count_user=$result_user->rowCount();
$row_user=$result_user->fetchObject();
if($count_user>0){$r=1;do{
$result_scrap=$dbh->query("select * from scrap where type='branch' and item='$row_user->branch'"); 
$row_scrap=$result_scrap->fetchObject(); 
$count_scrap=$result_scrap->rowCount();	
echo "
<tr>
<td>".$r++."</td>
<td>".$row_user->firstname." ".$row_user->lastname."</td>
<td>".$row_user->email."</td>
<td>".$row_user->phonenumber."</td>
<td>".$row_scrap->item2."</td>
</tr>
";	
}while($row_user=$result_user->fetchObject());}
?>
</table>

</div>

</div>

</div>
<script>
function show_dis(ai){$("#dis_edit"+ai).toggle(500);}
function show_person(){ $("#newperson").toggle(500);}
var page_loading=function(){$("#loadin").animate({width: "100%", height: "100%", opacity: "0.4"},500);}
var page_close=function(){$("#loadin").animate({width: "0%", height: "0%", opacity: "0"},500);}
</script>
<?php lscripts(); ?>
</body>
</html>
