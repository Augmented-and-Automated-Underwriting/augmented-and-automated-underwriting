<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?> 

<style>
.switch {
position: relative;
display: inline-block;
width: 60px;
height: 34px;
}

.switch input {display:none;}

.slider {
position: absolute;
cursor: pointer;
top: 0;
left: 0;
right: 0;
bottom: 0;
background-color: blue;
-webkit-transition: .4s;
transition: .4s;
}

.slider:before {
position: absolute;
content: "";
height: 26px;
width: 26px;
left: 4px;
bottom: 4px;
background-color: white;
-webkit-transition: .4s;
transition: .4s;
}

input:checked + .slider {
background-color: #2196F3;
}

input:focus + .slider {
box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
-webkit-transform: translateX(26px);
-ms-transform: translateX(26px);
transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
border-radius: 34px;
}

.slider.round:before {
border-radius: 50%;
}
</style>


</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>

<?php
if(isset($_POST["delete_user"])){
$rn=$_POST["rn"];

$result_rn=$dbh->query("select * from users where rolenumber='$rn'");
$row_rn=$result_rn->fetchObject();
$result_k=$dbh->query("select * from keyfields where rolenumber='$rn'");
$row_k=$result_k->fetchObject();

$insert_users=$dbh->query("insert into deletedusers (firstname,lastname,gender,phonenumber,email,branch,address,password,role,rolenumber,fulltitle,username) values('$row_rn->firstname','$row_rn->lastname','$row_rn->gender','$row_rn->phonenumber','$row_rn->email','$row_rn->branch','$row_rn->address','$row_k->password','$row_rn->role','$row_rn->rolenumber','$row_rn->fulltitle','$row_rn->username')");

$tables=array('users','keyfields');
foreach ($tables as $del_tables) {$delete_tables=$dbh->query("delete from $del_tables where rolenumber='$rn'");}
}

if(isset($_POST["lockstatus"])){
$lockstatus=$_POST["lockstatus"];
if($lockstatus==1){$lockstatus=$_POST["lockstatus"]; $owner=""; $userstatus=1; $listss=1;}
elseif($lockstatus==0){$lockstatus=0; $owner="and rolenumber!='$rolenumber'"; $userstatus="0"; $listss=0;}

$rolenumber=$_SESSION["rolenumber"];

$result_pwdexp=$dbh->prepare("select * from keyfields");
$result_pwdexp->execute();
$row_pwdexp=$result_pwdexp->fetchObject();
$count_pwdexp=$result_pwdexp->rowCount();

if($count_pwdexp>0){
do{
$update_pwdexp=$dbh->query("update keyfields set status='$lockstatus' where rolenumber='$row_pwdexp->rolenumber' $owner");

$update_users=$dbh->query("update keyfields set status='$userstatus' where rolenumber='$row_pwdexp->rolenumber' $owner");

}while($row_pwdexp=$result_pwdexp->fetchObject());

}
}

$rolenumber=$_SESSION["rolenumber"];
$result_pwdexp=$dbh->prepare("select * from keyfields where status='1' and rolenumber not like '$rolenumber'");
$result_pwdexp->execute();
$row_pwdexp=$result_pwdexp->fetchObject();
$count_pwdexp=$result_pwdexp->rowCount();

if($count_pwdexp>1){$color="green"; $status="ON";}else{$color="danger"; $status="OFF";}
?>
<div class="card card-default">
<div class="card-body">  
<i><b>Warning</b>: The switch on the right can lock or Unlock the entire system</i>
<form method='post'>
<?php
$rolenumber=$_SESSION["rolenumber"];
$result_pwdexp=$dbh->prepare("select * from keyfields where status='1' and rolenumber not like '$rolenumber'");
$result_pwdexp->execute();
$row_pwdexp=$result_pwdexp->fetchObject();
$count_pwdexp=$result_pwdexp->rowCount();

if($count_pwdexp>1){
echo "
<label class='switch' style='float:right;margin-top:-30px'>
<input type='checkbox' name='lockstatus' onchange='this.form.submit()' value='0'>
<span style='background-color:red;' class='slider round'></span>
</label></form>";

}else{
echo "<label style='float:right;' class='switch'>
<input type='checkbox' name='lockstatus' onchange='this.form.submit()' value='1' >
<span style='background-color:green;' class='slider round'></span>
</label>";
}
?>
</div></div>
<div class="card card-default">
  <div class="card-header"><h4 class="card-title">Activate/Deactivate User Accounts</h4></div>
<div class="card-body">  
<table class="table table-striped">
<thead>
<tr>
<th>No</th>
<th>Names</th>
<th>Phone Nos</th>
<th>Email</th>
<th>Fulltitle</th>
<th>Expires on</th>
<th colspan='2' align='center'><b>Action</b></th>
</tr></thead>
<?php
//updating user lock status
if(isset($_POST["userlock"])){
$userlock=$_POST["userlock"];
$userid=$_POST["userid"];
if($userlock==1){$userlock=$_POST["userlock"]; $userst=1;$lists=1;}
elseif($userlock==0){$userlock=0; $userst=0;$lists=0;}

$update_pwdexp=$dbh->query("update keyfields set status='$userlock' where rolenumber='$userid'");
$update_users=$dbh->query("update keyfields set status='$userst' where rolenumber='$userid'");
}

//updating user lock status
$result_pwdexp=$dbh->prepare("select * from keyfields where rolenumber!='$rolenumber' and rolenumber not like '%ln%'");
$result_pwdexp->execute();
$row_pwdexp=$result_pwdexp->fetchObject();
$count_pwdexp=$result_pwdexp->rowCount();

if($count_pwdexp>0){
$x=1;
do{


$result_users=$dbh->prepare("select * from users where rolenumber='$row_pwdexp->rolenumber'");
$result_users->execute();
$row_users=$result_users->fetchObject();
$count_pwdexp=$result_users->rowCount();
echo "
<tr>
<td>".$x++."</td>
<td>"; if($count_pwdexp>0){echo $row_users->firstname." ".$row_users->lastname; } echo "</td>
<td>"; if($count_pwdexp>0){echo $row_users->phonenumber; } echo "</td>
<td>"; if($count_pwdexp>0){echo $row_users->email; ; } echo "</td>
<td>";if($count_pwdexp>0){echo  $row_users->fulltitle;}else{echo"No Title";}echo"</td>
<td>".$row_pwdexp->pswdexpiry."</td>
<td>
<form method='post'>
<input type='hidden' name='userid' value='".$row_pwdexp->rolenumber."'>"; 
if($row_pwdexp->status==1){
echo "
<label style='float:right;' class='switch'>
<input type='checkbox' name='userlock' onchange='this.form.submit()' value='0'  >
<span style='background-color:red;' class='slider round'></span>
</label>";

}elseif($row_pwdexp->status==0){
echo "
<label style='float:right;' class='switch'>
<input type='checkbox' name='userlock' onchange='this.form.submit()' value='1'  >
<span style='background-color:green;' class='slider round'></span>
</label>";
}
echo "
</form></td>"; ?>

<td><form method='post' onsubmit="return delete_checker('<?php if($count_pwdexp>0){echo $row_users->firstname." ".$row_users->lastname; } ?>','deleted from');">
<input type='hidden' name='rn' value='<?php echo $row_pwdexp->rolenumber; ?>'>
<input type='submit' name='delete_user' class='btn btn-sm btn-danger' value='Delete'>

<?php echo "</form>
</td>
</tr>";
}while($row_pwdexp=$result_pwdexp->fetchObject());
}else{
echo "
<tr>
<td colspan='7' align='center'>Please contact the developers. </td>
</tr> ";
}
?></table>
</div></div>
<?php
if(isset($_POST["restore_user"])){
$rn=$_POST["rn"];

$result_rn=$dbh->query("select * from deletedusers where rolenumber='$rn'");
$row_rn=$result_rn->fetchObject();

$insert_users=$dbh->query("insert into users (firstname,lastname,gender,phonenumber,email,address,role,rolenumber,fulltitle,username,branch) values('$row_rn->firstname','$row_rn->lastname','$row_rn->gender','$row_rn->phonenumber','$row_rn->email','$row_rn->address','$row_rn->role','$row_rn->rolenumber','$row_rn->fulltitle','$row_rn->username','$row_rn->branch')");

$datefrom=date("Y-m-d");
$dateto=date("Y-m-d", strtotime( $datefrom." +1 month" ));

$insert_pwdexpiry=$dbh->query("insert into keyfields (rolenumber,password,status,pswdexpiry,username) values('$row_rn->rolenumber','$row_rn->password','1','$dateto','$row_rn->username')");

$tables=array('deletedusers');
foreach ($tables as $del_tables) {$delete_tables=$dbh->query("delete from $del_tables where rolenumber='$rn'");}

}
?>
<div class="card card-default"><!--Initiative-->

<div class="card-body">
  <div class="card-header"><h4 class="card-title">Manage Deleted Users</h4></div>
<table class="table table-striped">
<thead>
<tr>
<th>No</th>
<th>Names</th>
<th>Phone Nos</th>
<th>Email</th>
<th>Fulltitle</th>
<th>Action</th>
</tr></thead>
<?php
$result_deleteuser = $dbh->query("select * from deletedusers order by autoid desc");
$row_deleteuser = $result_deleteuser->fetchObject();
$count_deleteuser = $result_deleteuser->rowCount();

if($count_deleteuser>0){
$r=1;
do{
$times=date("Y-m-d");
echo "<tr>
<td>".$r++."</td>
<td>".$row_deleteuser->firstname.",  ".$row_deleteuser->lastname."<br>
<span style='color:red;'><i>Deleted On : ".$times."</i></span></td>
<td>".$row_deleteuser->phonenumber."</td>
<td>".$row_deleteuser->email."</td>
<td>".$row_deleteuser->fulltitle."</td>
<td>"; ?>
<form method='post' onsubmit="return delete_checker('<?php echo $row_deleteuser->firstname." ".$row_deleteuser->lastname; ?>','restored back in');">
<input type='hidden' name='rn' value='<?php echo $row_deleteuser->rolenumber; ?>'>
<input type='submit' name='restore_user' class='btn btn-sm btn-warning' value='Restore'>
</form>

<?php echo "</td></tr>";
}while($row_deleteuser = $result_deleteuser->fetchObject());
}else{echo "<tr><td colspan='10' align='center'>There are no users deleted here , so far. </td></tr>";}
?>
</table>
</div>
</div>
<?php lscripts(); ?>
<script>
function delete_checker(names, act){
var confirmer=confirm("User : "+names+" will be "+act+" the system; Are u sure.? ");
if(confirmer==false){return false;} }
</script>       

</body>
</html>