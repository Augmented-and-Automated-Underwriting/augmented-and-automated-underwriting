<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>

</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">

<?php kleftbar(); ?>
<div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Notifications</b></h3>
</div><!-- /.card-header -->
<div class="card-body">
<div class="tab-content">
<div class="tab-pane active" id="tab_1">
<div class="row">  
<?php
$result_nots=$dbh->query("select * from notifications where clientid='$rolenumber' order by autoid desc"); 
$row_nots=$result_nots->fetchObject(); 
$count_nots=$result_nots->rowCount();
if($count_nots>0){ $r=1; do{
$result_reqs=$dbh->query("select * from client_policies where reqid='$row_nots->reqid'"); 
$row_reqs=$result_reqs->fetchObject();
$count_reqs=$result_reqs->rowCount();
if($count_reqs>0){
$result_pol=$dbh->query("select * from scrap where type='policy' and item='$row_reqs->plan_type'"); 
$row_pol=$result_pol->fetchObject();
$result_plan=$dbh->query("select * from scrap where type='plan' and item='$row_reqs->planid'"); 
$row_plan=$result_plan->fetchObject();	
} 	
echo "<table class='table table-striped'><tr>
<td><i class='fa fa-bell' style='color:blue;font-weight:bold'></i>&nbsp&nbsp<span>".datediff($today,$row_nots->autodate)."</span><br><span style='color:maroon;font-weight:bold;font-style:italic'>".$row_pol->item2."</span>->".$row_plan->item2."<br>".$row_nots->about."</td>
</tr></table>";
}while($row_nots=$result_nots->fetchObject());}
?>
</div></div></div></div>
</div>
<?php lscripts(); ?>
</body>
</html>
