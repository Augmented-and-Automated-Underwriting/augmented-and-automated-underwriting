<?php
session_start();
$role=$_SESSION["role"];
if($role=="cls"){include("client_main.php");}
else{include("dashboard.php");}
?>