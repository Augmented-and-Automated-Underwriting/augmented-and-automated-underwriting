<?php
$sub_val=$_POST["sub_val"];

$result_scrap1=$dbh->query("select * from scrap where type='plan' and item3='$sub_val'");
$row_scrap1=$result_scrap1->fetchObject();
$count_scrap1=$result_scrap1->rowcount();

$result_scrap2=$dbh->query("select * from scrap where type='policy' and item='$sub_val'");
$row_scrap2=$result_scrap2->fetchObject();

echo "<div style='font-size:18px;text-align:center;'><u><b>".$row_scrap2->item2."</b></u></div>";

if($count_scrap1>0){ do{ ?>
<table width='100%'>
<tr><td width='5%'>                             
<input onClick="chk_small('<?php echo $row_scrap1->item; ?>')" type="radio" name='sub' value="" >
</td>
<td> <?php echo $row_scrap1->item2; ?></td></tr>
<tr><td colspan='2'><br></td></tr></table>

<?php }while($row_scrap1=$result_scrap1->fetchObject());}
else{echo "There is no data as yet."; }
?>