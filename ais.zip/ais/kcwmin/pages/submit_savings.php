<?php
@session_start();
include 'connect.php';
$userid=$_POST["userid"];
$share_amount=$_POST["share_amount"];
$datepaid=$_POST["datepaid"];
$paymethod=$_POST["paymethod"];
$approver=$_SESSION['rolenumber'];
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$sharid="sv".$fyy.$mm.$dd.$hi.$mi.$fsa;
$insert_savings=$dbh->query("insert into savings (owner,ouruser,methodid,amount,savingid,datepaid) values('$userid','$approver','$paymethod','$share_amount','$sharid','$datepaid')");
?>