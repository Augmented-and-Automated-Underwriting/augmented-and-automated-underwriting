<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}th{background: #333;color: #ffffff;font-weight: bold;}td, th{padding: 6px;border:1px solid #ccc;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Date Paid";}
td:nth-of-type(3):before{content: "Owner";}
td:nth-of-type(4):before{content: "Payment Method";}
td:nth-of-type(5):before{content: "Ammount Paid";}
td:nth-of-type(6):before{content: "Approver";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="row">
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-4">
<span class="info-box-icon bg-info elevation-1"><i class="fas fa-edit"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Pending Loans</b></span>
<span class="info-box-number">
<?php echo "<span style='color:maroon'>".countTables("loans",0)."</span>"; ?></span></div></div></div>
          <!-- /.col -->
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-4">
<span class="info-box-icon bg-danger elevation-1"><i class="fas fa-clock"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Active Loans</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".countTables("loans",1)."</span>"; ?></span>
</div></div></div>
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-4">
<span class="info-box-icon bg-primary elevation-1"><i class="fas fa-check-circle"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Cleared Loans</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".countTables("loans",2)."</span>"; ?></span>
</div></div></div>
          <!-- /.col -->
<div class="clearfix hidden-md-up"></div>
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-4">
<span class="info-box-icon bg-success elevation-1"><i class="fas fa-briefcase"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Total Savings</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".number_format(getSavings(0))."</span>"; ?></span>
</div>
</div></div>
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-2">
<span class="info-box-icon bg-primary elevation-1"><i class="fas fa-handshake"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Total Shares</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".number_format(getShares(0))."</span>"; ?></span>
</div></div></div>
<div class="col-12 col-sm-6 col-md-2">
<div class="info-box mb-2">
<span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>
<div class="info-box-content">
<span class="info-box-text"><b>Total Members</b></span>
<span class="info-box-number"><?php echo "<span style='color:maroon'>".number_format(countMembers())."</span>"; ?></span>
</div></div></div>
</div>
<div class='alert alert-warning' style='text-align:center;font-weight:bold;font-style:italic;'>Hello, <span style='color:maroon'><?php echo $_SESSION['firstname']; ?></span> You Last Saved On: <span style='color:maroon'><?php echo lastSavedOn(); ?></span></div>    
<div class="col-lg-12">
<div class="row">
  <div class="col-lg-6">
    <div class="card card-default">
      <div class="card-header"><h5 class="crad-title"><b>Recent Savings</b></h5></div>
      <div class="card-body">
  <table id="box">
<thead>
<tr>
<th>No</th>
<th>Date Paid</th>
<th>Owner</th>
<th>Payment Method</th>
<th>Amount Paid</th>
<th>Approver</th>
</tr>
</thead>  
<?php
$result_savings=$dbh->query("select * from savings where status=0 order by autoid desc limit 10");
$count_savings=$result_savings->rowCount();
$row_savings=$result_savings->fetchObject();
if($count_savings>0){$r=1; do{
$result_approver=$dbh->query("select * from users where rolenumber='$row_savings->ouruser'");
$row_approver=$result_approver->fetchObject(); 
$result_owner=$dbh->query("select * from users where rolenumber='$row_savings->owner'");
$row_owner=$result_owner->fetchObject();
$result_paymethod=$dbh->query("select * from scrap where item='$row_savings->methodid'");
$row_paymethod=$result_paymethod->fetchObject();
echo "
<tr>
<td>".$r++."</td>
<td>".$row_savings->datepaid."</td>
<td>".$row_owner->firstname." ".$row_owner->lastname."</td>
<td>".$row_paymethod->item2."</td>
<td><span style='color:maroon'>".number_format($row_savings->amount)."</span></td>
<td>".$row_approver->firstname." ".$row_approver->lastname."</td>
</tr>
";     
}while($row_savings=$result_savings->fetchObject());}
?>
</table>      
      </div>
    </div>
  </div>
 <div class="col-lg-6">
    <div class="card card-default">
      <div class="card-header"><h5 class="crad-title"><b>Recent Shares</b></h5></div>
      <div class="card-body">
    <table id="box">
<thead>
<tr>
<th>No</th>
<th>Date Paid</th>
<th>Owner</th>
<th>Payment Method</th>
<th>Amount Paid</th>
<th>Approver</th>
</tr>
</thead>  
<?php
$result_shares=$dbh->query("select * from shares where status=0 order by autoid desc limit 10");
$count_shares=$result_shares->rowCount();
$row_shares=$result_shares->fetchObject();
if($count_shares>0){$r=1; do{
$result_approver=$dbh->query("select * from users where rolenumber='$row_shares->ouruser'");
$row_approver=$result_approver->fetchObject(); 
$result_owner=$dbh->query("select * from users where rolenumber='$row_shares->owner'");
$row_owner=$result_owner->fetchObject();
$result_paymethod=$dbh->query("select * from scrap where item='$row_shares->methodid'");
$row_paymethod=$result_paymethod->fetchObject();
echo "
<tr>
<td>".$r++."</td>
<td>".$row_shares->datepaid."</td>
<td>".$row_owner->firstname." ".$row_owner->lastname."</td>
<td>".$row_paymethod->item2."</td>
<td><span style='color:maroon'>".number_format($row_shares->amount)."</span></td>
<td>".$row_approver->firstname." ".$row_approver->lastname."</td>
</tr>
";     
}while($row_shares=$result_shares->fetchObject());}
?>
</table>    
      </div>
    </div>
  </div>
</div>  
</div>      
<?php lscripts(); ?>

</body>
</html>