<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}th{background: #333;color: #ffffff;font-weight: bold;}td, th{padding: 6px;border:1px solid #ccc;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Date Paid";}
td:nth-of-type(3):before{content: "Owner";}
td:nth-of-type(4):before{content: "Payment Method";}
td:nth-of-type(5):before{content: "Ammount Paid";}
td:nth-of-type(6):before{content: "Approver";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="container-fluid">
<div class="row mb-2"><div class="col-sm-6"><h5><b>Track Loans</b></h5></div>
<div class="col-sm-6"><ol class="breadcrumb float-sm-right">
<li class="breadcrumb-item"><a href="index.php">Home</a></li>
</ol></div></div></div>
<div class="col-lg-12"><div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Tracker Payment</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><b>Loan Tracker</b></li>
</ul></div>
<div class="card-body">
<table id="example">
<thead><tr>
<th>No</th>  
<th>Name</th>
<th>Nin</th>
<th>Total loan</th>
<th>Insts</th>
<th>EMI</th>
<th>Amount Paid</th>
<th>Remaining amount</th>
<th>Total Fine</th>
<th>Current inst.</th>
<th>Remaining inst.</th>
<th>Next pay date</th>
<th>Action</th>
</tr></thead>
<?php
$result_loans=$dbh->query("select * from loans where status=1 order by autoid asc");
$row_loans=$result_loans->fetchObject();
$count_loans=$result_loans->rowCount();
if($count_loans>0){$r=1; do{
$result_ownner=$dbh->query("select * from users where rolenumber='$row_loans->owner'");
$row_owner=$result_ownner->fetchObject();  
$result_fine=$dbh->query("select sum(fine) from payments where loanid='$row_loans->loanid'");
$count_fine=$result_fine->rowCount();
if ($count_fine>0) { $row_fine=$result_fine->fetch(); }
else{ $row_fine='0'; }
$totalfine=$row_fine['0'];   
echo"
<tr>
<td>".$r++."</td>
<td>".$row_owner->firstname."".$row_owner->lastname."</td>
<td>".$row_owner->nin_number."</td>
<td><span style='color:maroon'>".number_format($row_loans->total_loan)."</span></td>
<td>".$row_loans->installments."</td>
<td><span style='color:maroon'>".number_format($row_loans->emi_loan)."</span> shs/month</td>
<td><span style='color:maroon'>".number_format($row_loans->amount_paid)."</span></td>
<td><span style='color:blue'>".number_format($row_loans->amount_remain)."</span></td>
<td>".number_format($totalfine)."</td>
<td>".$row_loans->current_inst."</td>
<td>".$row_loans->remain_inst."</td>
<td>".$row_loans->next_date."</td>
 <td><div><a class='btn btn-info' href='individual_loan.php?loanid=".$row_loans->loanid."'>view</a></div></td>
</tr>";
}while($row_loans=$result_loans->fetchObject());} ?>
</table>
</div></div>       

<?php lscripts(); ?>
</body>
</html>
