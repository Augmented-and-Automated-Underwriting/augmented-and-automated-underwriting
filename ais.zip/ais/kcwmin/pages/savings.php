<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<script src='../js/jquery.js'></script>  
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}th{background: #333;color: #ffffff;font-weight: bold;}td, th{padding: 6px;border:1px solid #ccc;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Date Paid";}
td:nth-of-type(3):before{content: "Owner";}
td:nth-of-type(4):before{content: "Payment Method";}
td:nth-of-type(5):before{content: "Ammount Paid";}
td:nth-of-type(6):before{content: "Approver";}
} 
</style> 
<script type="text/javascript">
$(document).ready(function (e) {
$("#newsavings").on('submit',(function(e) {
e.preventDefault();
$.ajax({
url: "submit_savings.php",
type: "POST",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,
beforeSend : function(){ $("#err").fadeOut(); },
success: function(data){
if(data=='invalid'){
$("#err").html("<div class='alert alert-danger'>savings Not Added: Check All Fields</div>").fadeIn();
}else
{
$("#preview").html("<div class='alert alert-success'>Success: Member savings Added</div>").fadeIn();
$("#new_member")[0].reset(); 
}
},
error: function(e) 
{
$("#err").html(e).fadeIn();
}          
    });
 }));
}); 

</script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="col-lg-12"><div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Member Savings</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><button class="btn btn-sm btn-success" onclick="toggleC()">New Saving</button></li>&nbsp&nbsp
<li class="nav-item"><button class="btn btn-sm btn-warning" onclick="toggleBox()">View Savings</button></li>
</ul></div>
<div class="card-body">
<div id="preview"></div><br>  
<table id="box">
<thead>
<tr>
<th>No</th>
<th>Date Paid</th>
<th>Owner</th>
<th>Payment Method</th>
<th>Amount Paid</th>
<th>Approver</th>
</tr>
</thead>  
<?php
$result_savings=$dbh->query("select * from savings where status=0 order by autoid desc");
$count_savings=$result_savings->rowCount();
$row_savings=$result_savings->fetchObject();
if($count_savings>0){$r=1; do{
$result_approver=$dbh->query("select * from users where rolenumber='$row_savings->ouruser'");
$row_approver=$result_approver->fetchObject(); 
$result_owner=$dbh->query("select * from users where rolenumber='$row_savings->owner'");
$row_owner=$result_owner->fetchObject();
$result_paymethod=$dbh->query("select * from scrap where item='$row_savings->methodid'");
$row_paymethod=$result_paymethod->fetchObject();
echo "
<tr>
<td>".$r++."</td>
<td>".$row_savings->datepaid."</td>
<td>".$row_owner->firstname." ".$row_owner->lastname."</td>
<td>".$row_paymethod->item2."</td>
<td><span style='color:maroon'>".number_format($row_savings->amount)."</span></td>
<td>".$row_approver->firstname." ".$row_approver->lastname."</td>
</tr>
";     
}while($row_savings=$result_savings->fetchObject());}
?>
</table>
</div>
<div class="col-lg-12 recep" style="display: none;">
<form id="newsavings">
<div class="row">
<div class='col-lg-3'>
 <label>Owner</label> 
<select class='form-control' name='userid' required>
<option value=''>Member</option> 
<?php
$result_users=$dbh->query("select * from users where role!='tech' order by firstname asc");
$count_users=$result_users->rowCount();
$row_users=$result_users->fetchObject();
if($count_users>0){do{
echo "<option value='".$row_users->rolenumber."'>".$row_users->firstname." ".$row_users->lastname."</option>";
}while($row_users=$result_users->fetchObject());}
?>
</select>
</div>
<div class='col-lg-3'>
  <label>Saving Amount</label>
<input type="text" name="share_amount" class="form-control" placeholder="Amount">
</div>
<div class='col-lg-3'>
  <label>Date Paid</label>
<input type='date' name='datepaid' class='form-control' required>
</div>
<div class='col-lg-3'>
<label>Pay Method</label>
<select class='form-control' name='paymethod' required>
<option value=''>Payment Method</option> 
<?php
$result_scrap=$dbh->query("select * from scrap where type='paymethod'");
$count_scrap=$result_scrap->rowCount();
$row_scrap=$result_scrap->fetchObject();
if($count_scrap>0){do{
echo "<option value='".$row_scrap->item."'>".$row_scrap->item2."</option>";  
}while($row_scrap=$result_scrap->fetchObject());}
?>
</select>
</div>
</div><div class="col-lg-12"><br></div>
<input type="submit" class="btn btn-block btn-success" value="Submit">
</form>
<div id="err"></div>
</div></div>   
 <script>
function toggleC (divID) {
    $("#box").hide();
    $("#"+divID).show();
    $(".recep").show();
}
function toggleBox (divID) {
    $("#box").show();
    $("#"+divID).show();
    $(".recep").hide();
}
</script>         
<?php lscripts(); ?>
</body>
</html>
