<?php
session_start();
$role=$_SESSION["role"];
if($role="tech"){include("dashboard.php");}
else{include("dashboard.php");}
?>