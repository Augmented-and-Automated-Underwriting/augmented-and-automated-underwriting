<?php
@session_start();
include 'connect.php';
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$phone1=$_POST["phone1"];
$email=$_POST["email"];
$title=$_POST['title'];
$username=strtolower(substr($lname, 0,1).$fname);
$password=$phone1;
$address=$_POST["address"];
$work_status=$_POST["occupation"];
$gender=$_POST['gender'];
$dob=$_POST['dob'];
$approver=$_SESSION['rolenumber'];
$nin_number=$_POST['nin_number'];
$datefrom=date("Y-m-d");
$dateto=date("Y-m-d", strtotime( $datefrom." +12 month" ));
$result_user2=$dbh->query("select * from users order by autoid desc");
$row_user2=$result_user2->fetchObject();
$theno=$row_user2->autoid+1;
$rolenumber=$title.$theno;
$result_scrap=$dbh->query("select * from scrap where item2='$title' and type='role'");
$row_scrap=$result_scrap->fetchObject();
if(!empty($_FILES['coapcimg']['tmp_name'])){
$filename = str_replace(' ','_', date('i')."".date('s').$_FILES['coapcimg']['name']);
// destination of the file on the server
$destination = '../dist/img/' . $filename;
// get the file extension
$extension = pathinfo($filename, PATHINFO_EXTENSION);
// the physical file on a temporary uploads directory on the server
$file = $_FILES['coapcimg']['tmp_name'];
$size = $_FILES['coapcimg']['size'];
if (!in_array($extension, ['pdf', 'docx', 'xls','png','jpg','jpeg','gif','xlsx','doc','odt','txt','ods'])) {
echo "You file extension must be .pdf, .xls, .png, .jpg, .jpeg, .gif, .xlsx, .doc, .odt, .txt, .ods or .docx";
} elseif ($_FILES['coapcimg']['size'] > 1000) { // file shouldn't be larger than 1Megabyte
echo "File too large!";
}else {
// move the uploaded (temporary) file to the specified destination
if(move_uploaded_file($file, $destination)){echo "<div class='alert alert-success'>Caopc Uploaded</div>";}
}}
$result_nin=$dbh->query("select * from users where nin_number='$nin_number'");
$count_nin=$result_nin->rowCount();
if ($count_nin<=0) {
$insert_pwdexpiry=$dbh->exec("insert into keyfields (rolenumber,password,username,pswdexpiry,status) values('$rolenumber','$password','$username','$dateto','1')");
$insert_users=$dbh->query("insert into users (role,firstname,lastname,phonenumber,nin_number,email,username,status,rolenumber,address,occupation,gender,fulltitle,dbirth,img,fsize,approver) values('$title','$fname','$lname','$phone1','$nin_number','$email','$username','active','$rolenumber','$address','$work_status','$gender','$row_scrap->item','$dob','$filename','$size','$approver')");
}
?>