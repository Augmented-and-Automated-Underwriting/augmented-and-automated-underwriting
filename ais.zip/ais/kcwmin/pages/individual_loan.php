<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}th{background: #333;color: #ffffff;font-weight: bold;}td, th{padding: 6px;border:1px solid #ccc;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Date Paid";}
td:nth-of-type(3):before{content: "Owner";}
td:nth-of-type(4):before{content: "Payment Method";}
td:nth-of-type(5):before{content: "Ammount Paid";}
td:nth-of-type(6):before{content: "Approver";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="container-fluid">
<div class="row mb-2"><div class="col-sm-6"><h5><b>Loans Payments</b></h5></div>
<div class="col-sm-6"><ol class="breadcrumb float-sm-right">
<li class="breadcrumb-item"><a href="index.php">Home</a></li>
</ol></div></div></div>
<div class="col-lg-12"><div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Tracker Payment</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><b>Loan Tracker</b></li>
</ul></div>
<div class="card-body">
<?php 
$loanid = $_GET['loanid']; 
$result_loans=$dbh->query("select * from loans where loanid='$loanid'");
$row_loans=$result_loans->fetchObject();
$count_loans=$result_loans->rowCount();
if($count_loans>0){
$result_ownner=$dbh->query("select * from users where rolenumber='$row_loans->owner'");
$row_owner=$result_ownner->fetchObject();
?>	
<div class="list-group">
<a class="list-group-item">Name: <?php echo $row_owner->firstname." ".$row_owner->lastname; ?></a>
<a class="list-group-item">Nin: <?php echo $row_owner->nin_number; ?></a>
<a class="list-group-item">Phone: <?php echo $row_owner->phonenumber; ?></a>
<a class="list-group-item">Address: <?php echo $row_owner->address; ?></a>
<?php } ?>
</div>
<hr>
<div class="row"><a href="loan_status.php" class="btn btn-primary ml-4">Back to loan status</a></div>
<h5 style="color: #000000;font-weight: bold;text-align: center;text-decoration: underline;">Loan Payment history</h5>
<table>
<thead>
<tr>
<th>No</th>
<th>Pay Date</th>
<th>Amount paid</th>
<th>Installment</th>
<th>Fine</th>
</tr></thead>
<?php 
$result_payment=$dbh->query("select * from payments where loanid='$loanid'");
$row_payment=$result_payment->fetchObject();
$count_payments=$result_payment->rowCount(); 
$sum = 0; $inst = 0;
if ($count_payments){$r=1; do{
$sum =  $sum+$row_payment->pay_amount;
$inst =$inst+ $row_payment->current_inst;
echo"<tr>
<td>".$r++."</td>
<td>".$row_payment->pay_date."</td>
<td>".$row_payment->pay_amount."</td>
<td>".$row_payment->current_inst."</td>
<td>".$row_payment->fine."</td>
</tr>"; }while($row_payment=$result_payment->fetchObject());
echo"<tfoot>
<th></th>
<th></th>
<th>Total: ".number_format($sum)."</th>
<th>Total Completed Installment: ".$inst."</th>
</tfoot>";
} ?>
</table>
</div></div>       

<?php lscripts(); ?>
</body>
</html>
