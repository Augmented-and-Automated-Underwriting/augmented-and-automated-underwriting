<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-4">
  <div class="card">
<div class="card-header"><h4 class="card-title"><b>New Roles</b></h4></div>
<div class="card-body"> 
<?php
if(isset($_POST["submit_role"])){
$title=$_POST["title"];
$role=$_POST["role"];

$insert_scrap=$dbh->prepare("insert into scrap (item,item2,type) values('$title','$role','role')");
$insert_scrap->execute();
}
?>
<form method="post">
 <div class="row">
<div class='col-lg-6'>
<input type='text' class='form-control' name='title' placeholder='Title' required>
</div>
<div class='col-lg-6'>
<input type='text' class='form-control' name='role' placeholder='Role Initials' required>
</div></div>
<br>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_role" value="Submit">
</div>
</form>
</div>
</div></div> 
<div class="col-lg-4">
  <div class="card">
<div class="card-header"><h4 class="card-title"><b>Payment Methods</b></h4></div>
<div class="card-body"> 
<?php
if(isset($_POST["submit_pay"])){
$account_name=$_POST["account_name"];
$account_num=$_POST["account_num"];
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$payid="pm".$fyy.$mm.$dd.$hi.$mi.$fsa;
$insert_scrap=$dbh->query("insert into scrap (item,item2,item3,type) values('$payid','$account_name','$account_num','paymethod')");
if($insert_scrap){echo "<div class='alert alert-success'>Added Successfully</div>";}
}
?>
<form method="post">
 <div class="row">
<div class='col-lg-6'>
<input type='text' class='form-control' name='account_name' placeholder='Account Name' required>
</div>
<div class='col-lg-6'>
<input type='text' class='form-control' name='account_num' placeholder='Account Number' required>
</div></div>
<br>
<div class='form-group'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_pay" value="Submit">
</div>
</form>
</div>
</div></div> 

<div class="col-lg-4">
<div class="card">
<div class="card-header"><h4 class="card-title"><b>New Departments</b></h4></div>
  <div class="card-body">        
<?php
if(isset($_POST["submit_dept"])){
$title=$_POST["dept"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $deptid="dept10"; }else{
$deptid="dept10".($row_scrap->autoid+1); }
$insert_scrap=$dbh->query("insert into scrap (item,item2,type) values('$title','$deptid','dept')");
if($insert_scrap){echo "<div class='alert alert-success'>Added Successfully</div>";}
}
?>
<form method="post">
 <div class="row">
<div class='col-lg-6'>
<input type='text' class='form-control' name='dept' placeholder='Department' required>
</div>
<div class='col-lg-6'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_dept" value="Submit">
</div></div>
</form>
</div>
</div> </div></div>
<div class="col-lg-12"><br></div>
<div class="row">
<div class="col-lg-4">
<div class="card">
<div class="card-header">Work Status</div>
<div class="card-body">
<?php
if(isset($_POST["submit_work"])){
$work_status=$_POST["work_status"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
if ($count_scrap<0) { $brandid="w10"; }else{
$brandid="w10".($row_scrap->autoid+1);
}
$insert_scrap=$dbh->query("insert into scrap (item,item2,type) values('$brandid','$work_status','workstatus')");
if($insert_scrap){echo "<div class='alert alert-success'>Added Successfully</div>";}

}
?>
<form method="post">
 <div class="row">
<div class='col-lg-6'>
<input type='text' class='form-control' name='work_status' placeholder='Work Status' required>
</div>
<div class='col-lg-6'>
<input type="submit" class="btn btn-sm btn-success btn-block" name="submit_work" value="Submit">
</div></div>
</form>
</div>
</div></div>
<!--
<div class="col-lg-4">
<div class="card">
<div class="card-header">Share Costs</div>
<div class="card-body">
<?php
if(isset($_POST["submit_cost"])){
$title=$_POST["share"];

$ssharecostupdate = $dbh->exec("UPDATE scrap SET item='$title' where item2='share cost' order by autoid asc limit 1");
}
?>
<form method="post">
 <div class="row">
<div class='col-lg-6'>
<input type='text' class='form-control' name='share' placeholder=' Share Cost' required>
</div>
<div class='col-lg-6'>
<input type="submit" class="btn btn-sm btn-success form-control" name="submit_cost" value="Submit">
</div></div>
</form>
</div>
</div> 
</div>
<div class="col-lg-4">
<div class="card">  
<div class="card-header">New Division</div>
<div class="card-body">
  <?php
if(isset($_POST["submit_div"])){
$title=$_POST["divss"];
$select_scrap=$dbh->query("select * from scrap order by autoid desc");
$count_scrap=$select_scrap->rowCount();
$row_scrap=$select_scrap->fetchObject();
         if ($count_scrap<0) {
            $devid="div10";
         }else{
            $devid="div10".($row_scrap->autoid+1);
         }

$insert_scrap=$dbh->query("insert into scrap (item,item2,type) values('$title','$devid','division')");
if($insert_scrap){echo "<div class='alert alert-success'>Added Successfully</div>";}
}
?>
<form method="post">
 <div class="row">
<div class='col-lg-6'>
<input type='text' class='form-control' name='divss' placeholder='Division' required>
</div>
<div class='col-lg-6'>
<input type="submit" class="btn btn-sm btn-success btn-block" name="submit_div" value="Submit">
</div></div>
</form></div></div> </div>-->

</div> 
<?php lscripts(); ?>
</body>
</html>