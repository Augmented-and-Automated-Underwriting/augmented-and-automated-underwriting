<style>
.candidatelisting{
	background: #A6FBBB none repeat scroll 0 0;
    padding:10px;
}
body
{background: #041932 none repeat scroll 0 0;
    margin-bottom: 30px;}
	.whitepara{width:100%; background:white; padding:50px; vertical-align:middle; margin-top:20%;}

</style><?php
$target_dir = "../dist/img/";
$temp = explode(".", $_FILES["fileToUpload"]["name"]);
$newfilename = $nin_number. '.' . end($temp);
$target_file = $target_dir . basename($newfilename);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "<p class='whitepara'>File is an image - ".$check["mime"].".";
        $uploadOk = 1;
    } else {
        echo "<div class='alert alert-danger'>File is not an image.</div>";
        $uploadOk = 0;
    }
}
// Check if file already exists
//if (file_exists($target_file)) {
  //  echo "<div class='alert alert-danger'>File already exists. </div>";
  //  $uploadOk = 0;
    
//}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 100000000000000) {
    echo "<div class='alert alert-danger'>Sorry, your file is too large.</div>";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "PNG" && $imageFileType != "JPEG" && $imageFileType != "GIF" && $imageFileType != "JPG") {
    echo "<div class='alert alert-danger'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "<div class='alert alert-danger'>No file was uploaded.</div>";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "<br><div class='alert alert-success'>The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.</div></p>";
    } else {
        echo "<div class='alert alert-danger'>Sorry, there was an error uploading your file.</div></p>";
    }
}
$img=basename($newfilename);
echo $_FILES["fileToUpload"]["error"]['0'];
?> 