<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<script src='../js/jquery.js'></script>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}th{background: #333;color: #ffffff;font-weight: bold;}td, th{padding: 6px;border:1px solid #ccc;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Date Paid";}
td:nth-of-type(3):before{content: "Owner";}
td:nth-of-type(4):before{content: "Payment Method";}
td:nth-of-type(5):before{content: "Ammount Paid";}
td:nth-of-type(6):before{content: "Approver";}
} 
</style> 
<script type="text/javascript">
$(document).ready(function (e) {
 $("#new_member").on('submit',(function(e) {
  e.preventDefault();
  $.ajax({
   url: "submit_member.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend : function()
   {
    //$("#preview").fadeOut();
    $("#err").fadeOut();
   },
   success: function(data)
      {
    if(data=='invalid')
    {
     // invalid file format.
     $("#err").html("<div class='alert alert-danger'>Member Not Added: Check Nin Number And Try Again</div>").fadeIn();
    }
    else
    {
     // view uploaded file.
     $("#preview").html("<div class='alert alert-success'>Success: New Member Added</div>").fadeIn();
     $("#new_member")[0].reset(); 
    }
      },
     error: function(e) 
      {
    $("#err").html(e).fadeIn();
      }          
    });
 }));
}); 

</script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="col-lg-12"><div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Manage Menbers</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab" onclick="toggleBox()">Pending Membership</a></li>
<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Approved Members</a></li>
<li class="nav-item"><button class="btn btn-sm btn-success" onclick="toggleC()">New Member</button></li>&nbsp&nbsp
</ul></div>
<div class="card-body">
  <?php
if(isset($_POST['approve_mem'])){
  $userid=$_POST['userid'];
  $status="Active";
  $approve_member=$dbh->query("update users set status='Active', approver='$rolenumber' where rolenumber='$userid'");
  $update_member=$dbh->query("update keyfields set status='1' where rolenumber='$userid'");
  echo "<div class='alert alert-success'>Member Details Approved</div>";
}

  ?>
<div id="preview"></div><br>
<div class="tab-content">
<div class="tab-pane active" id="tab_1" style="overflow-y: scroll;height:450px;">
<div id="box">  
<table id="example">
<thead><tr>
<th>No</th>  
<th>Name</th>
<th>Nin</th>
<th>Gender</th>
<th>Mobile</th>
<th>Email</th>
<th>Address</th>
<th>Working Status</th>
<th>Action</th>
</tr></thead>
<?php
$result_users=$dbh->query("select * from users where role='mr' and status='0' order by firstname asc");
$count_users=$result_users->rowCount();
$row_users=$result_users->fetchObject();
if($count_users>0){$r=1; do{
$result_scrap=$dbh->query("select * from scrap where type='workstatus' and item='$row_users->occupation'");
$row_scrap=$result_scrap->fetchObject(); 
echo "
<tr>
<td>".$r++."</td>
<td>".$row_users->firstname." ".$row_users->lastname."</td>
<td>".$row_users->nin_number."</td>
<td>".$row_users->gender."</td>
<td>".$row_users->phonenumber."</td>
<td>".$row_users->email."</td>
<td>".$row_users->address."</td>
<td>".$row_scrap->item2."</td>
<td><form method='post'>
<input type='hidden' name='userid' value='".$row_users->rolenumber."'>
<input type='submit' name='approve_mem' class='btn btn-sm btn-success' value='Approve'>
</form></td>
</tr>";
}while($row_users=$result_users->fetchObject());}
?>
</table></div>
<div class="col-lg-12 mems" style="display: none">
<form  id="new_member" enctype="multipart/form-data">
<div class="row">
<div class="col-lg-4">  
<label>First Name</label>                      
<input type="text" name="fname" class="form-control" placeholder="Enter First Name"></div>
<div class="col-lg-4">  
<label>Last Name</label>                      
<input type="text" name="lname" class="form-control" placeholder="Enter Last Name"></div>  <div class="col-lg-4">
<label>National ID number</label>                      
<input type="text" name="nin_number" class="form-control" placeholder="Nin Number" value=""></div></div>
<div class="row">
<div class="col-lg-3">  
<label>Gender</label>                      
<select class="form-control" name="gender">
<option>Select</option>  
<option value="Male">Male</option>
<option value="Female">Female</option></select></div>
<div class="col-lg-3">
<label>Mobile</label>  
<input type="text" name="phone1" class="form-control positive-integer"  placeholder="Phone Number"></div>
<div class="col-lg-3">
<label>Email</label>                      
<input type="text" name="email" class="form-control"  placeholder="Email">
</div>
<div class="col-lg-3">
<label>Role</label>                      
<select class="form-control" name="title" >
<option value="">Select</option>
<?php
$result_scrapr=$dbh->query("select * from scrap where type='role'");
$count_scrapr=$result_scrapr->rowCount();
$row_scrapr=$result_scrapr->fetchObject();
if($count_scrapr){do{
echo "<option value='".$row_scrapr->item2."'>".$row_scrapr->item."</option>";  
}while($row_scrapr=$result_scrapr->fetchObject());}
?>
</select></div>
</div>
<div class="row">
<div class="col-lg-3">  
<label>Date of Birth</label>                      
<input type="date" name="dob" class="form-control is-datepick"></div>
<div class="col-lg-3">
<label>Address</label>                      
<input type="text" name="address" class="form-control" placeholder="Address">
</div>
<div class="col-lg-3">
<label>Working Status</label>                      
<select class="form-control" name="occupation" >
<option value="">Select</option>
<?php
$result_scrapws=$dbh->query("select * from scrap where type='workstatus'");
$count_scrapws=$result_scrapws->rowCount();
$row_scrapws=$result_scrapws->fetchObject();
if($count_scrapws){do{
echo "<option value='".$row_scrapws->item."'>".$row_scrapws->item2."</option>";  
}while($row_scrapws=$result_scrapws->fetchObject());}
?>
</select></div>
<div class="col-lg-3">
<label>Member Photo</label>
<input type='file' name='coapcimg' required>
</div></div><hr>
<div class="form-group">
<input type="submit" class="btn btn-success form-control" value="submit">
</div></form></div>
<div id="err"></div>
</div>
<div class="tab-pane" id="tab_2" style="overflow-y: scroll;height:450px;">
<table id="example">
<thead><tr>
<th>No</th>  
<th>Name</th>
<th>Nin</th>
<th>Gender</th>
<th>Mobile</th>
<th>Email</th>
<th>Address</th>
<th>Working Status</th>
<th>Aproved By</th>
</tr></thead>
<?php
$result_users=$dbh->query("select * from users where role='mr' and status='active' order by firstname asc");
$count_users=$result_users->rowCount();
$row_users=$result_users->fetchObject();
if($count_users>0){$r=1; do{
$result_scrap=$dbh->query("select * from scrap where type='workstatus' and item='$row_users->occupation'");
$row_scrap=$result_scrap->fetchObject();  
$result_appr=$dbh->query("select * from users where rolenumber='$row_users->approver'");
$row_appr=$result_appr->fetchObject();  
echo "
<tr>
<td>".$r++."</td>
<td>".$row_users->firstname." ".$row_users->lastname."</td>
<td>".$row_users->nin_number."</td>
<td>".$row_users->gender."</td>
<td>".$row_users->phonenumber."</td>
<td>".$row_users->email."</td>
<td>".$row_users->address."</td>
<td>".$row_scrap->item2."</td>
<td>".$row_appr->firstname." ".$row_appr->lastname."</td></tr>";
}while($row_users=$result_users->fetchObject());}
?>
</table>
</div></div>
</div></div>       
<script>
function toggleC (divID) {
    $("#box").hide();
    $("#"+divID).show();
    $(".mems").show();
}
function toggleBox (divID) {
    $("#box").show();
    $("#"+divID).show();
    $(".mems").hide();
}
</script>        
<?php lscripts(); ?>
</body>
</html>
