<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
 <script>
        function calculateEMI() {
            var loan_amount =document.myform.loan_amount.value;
            if (!loan_amount)
                loan_amount = '0';

            var loan_percent = document.myform.loan_percent.value;
            if (!loan_percent)
                loan_percent = '0';

             var installments = document.myform.installments.value;
            if (!installments)
                installments = '0';


            var loan_amount = parseFloat(loan_amount);
            var loan_percent = parseFloat(loan_percent);
            var installments = parseFloat(installments);

            var total = loan_amount+(loan_amount*(loan_percent/100));

            document.myform.total_amount.value = parseFloat(total).toFixed(2);
            document.myform.borrower_emi.value = parseFloat((total/installments)).toFixed(2);
        }
      
      </script>

</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="container-fluid">
<div class="row mb-2"><div class="col-sm-6"><h4>Request Loans</h4></div>
<div class="col-sm-6"><ol class="breadcrumb float-sm-right">
<li class="breadcrumb-item"><a href="index.php">Home</a></li>
</ol></div></div></div>
<div class="col-lg-12"><div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Loan Application Form</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><b>Loan Manager</b></li>
</ul></div>
<div class="card-body">
<?php
if (isset($_POST['submit_loan'])) {
$userid=$_POST["userid"];
$loan_amount=$_POST["loan_amount"];
$loan_percent=$_POST["loan_percent"];
$installments=$_POST['installments'];
$total_amount=$_POST['total_amount'];
$borrower_emi=$_POST["borrower_emi"];
$ouruser=$_SESSION['rolenumber'];
$pay_date=$_POST['pay_date'];
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$loanid="lna".$fyy.$mm.$dd.$hi.$mi.$fsa;
$result_loans=$dbh->query("select * from loans where owner='$userid' and amount_remain>0");
$count_loans=$result_loans->rowCount();
$row_loan=$result_loans->fetchObject();
if($count_loans<=0){
$insert_loan=$dbh->query("insert into loans (owner,ouruser,expected_loan,loan_percentage,installments,total_loan,emi_loan,loanid,remain_inst,next_date) values('$userid','$ouruser','$loan_amount','$loan_percent','$installments','$total_amount','$borrower_emi','$loanid','$installments','$pay_date')");
echo "<div class='alert alert-success'>New Loan Pending Approval Added Successfully</div>";
}else{
echo "<div class='alert alert-danger'>You Still Have Unsettled Loan Worth UGX: ".$row_loan->amount_remain.", Cleared It To Get New Loan</div>";
}
}
?>
<div id="preview"></div><br>      
<form name="myform" id="myform" method="post">
<div class="row">
  <div class="col-lg-4">
<label>Borrower: </label>
<select class='form-control' name='userid' required>
<option value=''>Member</option> 
<?php
$role=$_SESSION['role'];
if($role=='xc' || $role=='ad' || $role=='tech'){
$result_users=$dbh->query("select * from users where role!='tech' order by firstname asc");
$count_users=$result_users->rowCount();
$row_users=$result_users->fetchObject();
if($count_users>0){do{
echo "<option value='".$row_users->rolenumber."'>".$row_users->firstname." ".$row_users->lastname."</option>";
}while($row_users=$result_users->fetchObject());}
}else{
 echo "<option value='".$rolenumber."'>".$_SESSION['firstname']." ".$_SESSION['lastname']."</option>";   
}
?>
</select>                      
</div>
<div class="col-lg-4">
<label>Expected Loan Amount</label>                      
<input type="number"  onkeyup="calculateEMI()" name="loan_amount" class="form-control" id="loanamount" placeholder="Enter Expected Loan" required></div>
<div class="col-lg-4">
<label>Loan Percentage</label>                      
<input type="number" onkeyup="calculateEMI()" name="loan_percent" class="form-control" id="loanpercentage" placeholder="Enter Loan Percent" required>
</div></div>
<div class="row">
<div class="col-lg-3">  
<label>Set Number of Installments</label>                      
<input type="number" onkeyup="calculateEMI()" name="installments" class="form-control"  placeholder="Enter installments number" required></div>
<div class="col-lg-3">
<label>Total Amount Including Interest</label>                      
<input type="text"  name="total_amount" class="form-control"readonly required>
</div>
<div class="col-lg-3">
<label>Automated Calculated EMI</label>  
<input type="text" name="borrower_emi" class="form-control positive-integer" id="inputBorrowerMobile" readonly required></div>
<div class="col-lg-3">
<label>First Payment Date</label>  
<input type="date" name="pay_date" class="form-control" required></div>
</div><hr>
<div class="form-group">
<input type="submit" class="btn btn-success form-control" value="Submit" name="submit_loan"></div>
</form></div>       
<div id="err"></div>
<?php lscripts(); ?>
</body>
</html>
