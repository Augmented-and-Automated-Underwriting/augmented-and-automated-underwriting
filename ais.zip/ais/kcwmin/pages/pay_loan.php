<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="container-fluid">
<div class="row mb-2"><div class="col-sm-6"><h4>Pay Loans</h4></div>
<div class="col-sm-6"><ol class="breadcrumb float-sm-right">
<li class="breadcrumb-item"><a href="index.php">Home</a></li>
</ol></div></div></div>
<div class="col-lg-12"><div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Loan Payment Form</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><b>Payment Manager</b></li>
</ul></div>
<div class="card-body">
<?php
if (isset($_POST['get_borrower'])) {
$userid=$_POST['userid'];
$result_users=$dbh->query("select * from users where rolenumber='$userid'");
$count_users=$result_users->rowCount();
$row_users=$result_users->fetchObject();
if($count_users>0){
$result_loans=$dbh->query("select * from loans where owner='$row_users->rolenumber' and status>0");
$row_loans=$result_loans->fetchObject();
$count_loans=$result_loans->rowCount();
if ($count_loans>0) {
$emi=$row_loans->emi_loan;
$nxtdate=$row_loans->next_date;
$crinst=$row_loans->current_inst;
$rminst=$row_loans->remain_inst;
$tloan=$row_loans->total_loan;
$apaid=$row_loans->amount_paid;
$aremain=$row_loans->amount_remain;
$loanid=$row_loans->loanid;
}
else{echo "<div class='alert alert-warning'>Loan Not Yet Approved</div>";}
$name=$row_users->firstname." ".$row_users->lastname;  
}else{echo "<div class='alert alert-danger'>Wrong Rolenumber</div>";}
}
?>
<?php 
if (isset($_POST['payment_submit'])) {
$loanid=$_POST['loanid'];
$borrower_name=$_POST['borrower_name'];
$payment=$_POST['payment'];
$next_date=$_POST['next_date'];
$fine_amount=$_POST['fine_amount'];
$pay_date=$_POST['pay_date'];
$current_inst=$_POST['current_inst'];
$remain_inst=$_POST['remain_inst'];
$total_amount=$_POST['total_amount'];
$paid_amount=$_POST['paid_amount'];
$totalinsts=$_POST['totalinsts'];
$yy=date("Y");$fyy=substr($yy,2,2);
$mm=date("m");$dd=date("d");$hi=date("h");
$mi=date("i");$sa=date("sa");
$fsa=substr($sa,0,2);
$payid="py".$fyy.$mm.$dd.$hi.$mi.$fsa;
$remain_amount = $total_amount -$paid_amount;
$fine = 0;
//fine calculation needed field
if (isset($fine_amount)) { $fine = $fine_amount; }
$insert_payment=$dbh->query("insert into payments (loanid,pay_amount,pay_date,current_inst,remain_inst,fine,paymentid) 
values('$loanid','$payment','$pay_date','$current_inst','$remain_inst','$fine','$payid')");
                
$update_loans=$dbh->prepare("UPDATE loans SET amount_paid='$paid_amount', amount_remain='$remain_amount', current_inst='$current_inst', remain_inst='$remain_inst', next_date='$next_date' WHERE loanid = '$loanid'");
$update_loans->execute();
echo "<div class='alert alert-success'>Success Partial Payment Made</div>";
}
?>
<form method="POST">
<div class="row">
<div class="col-lg-4">  
<label>Borrower: </label>
<div class="input-group">                      
<input type="text" name="userid" class="form-control" id="inputBorrowerFirstName" placeholder="Search By Rolenumber">
<button class="btn btn-success btn-sm" name="get_borrower" type="submit">Go</button></div></div>
<input type="hidden" name="loanid" value="<?php echo $loanid; ?>">
<div class="col-lg-4">
<label>Full Name</label>                      
<input type="text" name="borrower_name" class="form-control" id="inputBorrowerFirstName" value="<?php if(isset($name)) echo $name; ?>" required readonly></div>
<div class="col-lg-4">
<label>Payment amount(EMI)</label>                      
<input type="number"  name="payment" class="form-control"  value="<?php if(isset($emi)) echo $emi; ?>" readonly></div></div>
<div class="row">
<?php if (isset($nxtdate)) { ?>
<div class="col-lg-3">  
<label>Expected Last date of payment</label>                      
<input type="date" class="form-control" id="nextdate" value="<?php echo $nxtdate; ?>" readonly></div>
<div class="col-lg-3">
<label>Next date of payment</label>                      
<input type="date"  name="next_date" class="form-control" id="nextdate" value="<?php echo date('Y-m-d',strtotime('+30 days',strtotime($nxtdate))); ?>" readonly></div>
<?php 
$current_date = strtotime(date('d-m-Y'));       
$last_date = strtotime($nxtdate);   
if ($current_date > $last_date) { ?>
<div class="col-lg-3">
<label>Fine Calculation(2% of EMI):</label>
<input type="number" name="fine_amount" class="form-control"  value="<?php 
echo  $emi * (2/100);
?>" readonly></div> <?php } ?><?php  } ?>
           
<div class="col-lg-3">
<label >Select Payment Date</label>                      
<input type="date"  name="pay_date" class="form-control" id="loanpercentage">
</div></div>
<div class="row">
 <div class="col-lg-4"> 
<label>Current Installment</label>
<input type="number" name="current_inst" class="form-control"   value="<?php if(isset($crinst)) echo $crinst+1; ?>" readonly>
</div>
<div class="col-lg-4">
<label>Remaining Installment</label>
<input type="number" name="remain_inst" class="form-control"   value="<?php if(isset($rminst)) echo $rminst - 1; ?>" readonly>
</div>
<div class="col-lg-4">
<label>Total Amount to be paid:</label>
<input type="number"  name="total_amount" class="form-control"   value="<?php if(isset($tloan)) echo $tloan; ?>" readonly>
</div></div> 
<div class="row">
<div class="col-lg-4">  
<label>Paid Amount</label>
<input type="number" name="paid_amount" class="form-control"  value="<?php if(isset($apaid)) echo $apaid+$emi; ?>" readonly>
</div>
<div class="col-lg-4">
<label>Amount Remaining</label>
<input type="number" name="remain_amount" class="form-control"  value="<?php if(isset($aremain)) echo $aremain; ?>" readonly>
                 </div>
<div class="col-lg-4">
<label>Action</label><br>
<input type="submit" name="payment_submit" class="btn btn-success form-control" value="Submit">
</div></div></form>
</div></div>       

<?php lscripts(); ?>
</body>
</html>
