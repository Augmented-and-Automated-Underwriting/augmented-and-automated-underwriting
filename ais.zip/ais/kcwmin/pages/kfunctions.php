<?php
@session_start();
include("connect.php");
if (!isset($_SESSION['rolenumber'])) {
header('Location:../index.php?wasgoinghere='.urlencode($_SERVER['REQUEST_URI']));
}

$goodusers="and status='active'";
$rolenumber=$_SESSION["rolenumber"];
$role=$_SESSION["role"];

$today=date("Y-m-d H:m:s");
$todaynow=date("Y-m-d h:i:s");
$currentyear=date("y");
$currentmonth=date("m");

//log Out if session has expired
$result_scrap = $dbh->prepare("select * from scrap where type='timeout'");
$result_scrap->execute();
$row_scrap  = $result_scrap->fetchObject();
?>
<script>
var sess_taker=function(){
var sess = "<?php echo $_SESSION["rolenumber"]; ?>";
if(sess == ''){window.location='../logout.php';} }
setInterval(sess_taker,500);

var timeout;
document.onmousemove = function(){
  clearTimeout(timeout);
  timeout = setTimeout(function(){window.location='../logout.php'}, <?php echo $row_scrap->item; ?>);

}
</script>
<script src="../tinymce/tinymce.min.js"></script> 
  <script>
tinymce.init({ selector:".para",
  paste_as_text: true,
  plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste code'
  ],

  toolbar: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
  content_css: '//www.tinymce.com/css/codepen.min.css'
});
</script>
<style type="text/css">
.pagination {
list-style-type: none;padding: 10px 0;display: inline-flex;
justify-content: space-between;box-sizing: border-box;}
.pagination li {box-sizing: border-box;padding-right: 10px;}
.pagination li a {box-sizing: border-box;background-color: #e2e6e6;padding: 8px;
text-decoration: none;font-size: 12px;font-weight: bold;color: #616872;border-radius: 4px;}.pagination li a:hover {background-color: #d4dada;}
.pagination .next a, .pagination .prev a {text-transform: uppercase;font-size: 12px;}
.pagination .currentpage a {background-color: #518acb;color: #fff;}
.pagination .currentpage a:hover {background-color: #518acb;}
</style>

<?php
//log Out if session has expired
function datediff($date1, $date2)
{
    $date_1 = new DateTime($date1);
    $date_2 = new DateTime($date2);
    $diff = $date_1->diff($date_2);

    if ($diff->days > 365) {
        return $date_1->format('Y-m-d');
    } elseif ($diff->days > 7) {
        return $date_1->format('Y-M d');
    } elseif ($diff->days > 2) {
        return $date_1->format('l - H:i');
    } elseif ($diff->days == 2) {
        return "Yesterday ".$date_1->format('H:i');
    } elseif ($diff->days > 0 OR $diff->h > 1) {
        return $date_1->format('H:i');
    } elseif ($diff->i >= 1) {
        return $diff->i." min ago";
    } else {
        return "Just now";
    }
}
function fixTitle(&$input)
{
  $input = str_replace('-', ' ',$input);
  $pos = strpos($input,'.');
  if($pos > 0)
    $input = substr($input,0,$pos);
  $input = ucwords($input);
}
 function kheader(){
$aTitle = explode('/',trim($_SERVER['REQUEST_URI'],'/'));
$aTitle = array_reverse($aTitle);
array_walk($aTitle, 'fixTitle');
 echo "<meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <meta http-equiv='x-ua-compatible' content='ie=edge'>

  <title>KCW-".implode(' | ',$aTitle)."</title>

  <!-- Font Awesome Icons -->
  <link rel='stylesheet' href='../plugins/fontawesome-free/css/all.min.css'>
  <!-- overlayScrollbars -->
  <link rel='stylesheet' href='../plugins/overlayScrollbars/css/OverlayScrollbars.min.css'>
  <!-- Theme style -->
  <link rel='stylesheet' href='../dist/css/adminlte.min.css'>
  <!-- Google Font: Source Sans Pro -->
  <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700' rel='stylesheet'>
  <link href='../css/bootstrap-datetimepicker.min.css' rel='stylesheet' media='screen'>";
 }

 function kleftbar(){
 include("connect.php");
 $rolenumber=$_SESSION["rolenumber"];

 echo " <div class='wrapper'>
 <!-- Navbar -->
  <nav class='main-header navbar navbar-expand navbar-white navbar-light border-bottom'>
    <!-- Left navbar links -->
    <ul class='navbar-nav'>
      <li class='nav-item'>
        <a class='nav-link' data-widget='pushmenu' href='#'><i class='fas fa-bars'></i></a>
      </li>
      <li class='nav-item d-none d-sm-inline-block'>
        <a href='index.php' class='nav-link'>Home</a>
      </li>

      <li class='nav-item d-none d-sm-inline-block'>
        <a href='index3.html' class='nav-link'>Performance</a>
      </li>

      <!-- Messages Dropdown Menu -->
      <li class='nav-item dropdown nav-item d-none d-sm-inline-block'>
        <a href='#' data-toggle='dropdown' class='nav-link'>Contacts</a>
        
          <div class='dropdown-menu dropdown-menu-lg dropdown-menu-right' style='overflow-y:scroll;height:400px;'>";

$result_users=$dbh->query("select * from users where status='active'");
$row_users=$result_users->fetchObject();
$count_users=$result_users->rowCount();

if($count_users>0){ do{
  if(!empty($row_users->img)){$img=$row_users->img;}
else{$img="avatar.png";}

          echo "<a href='#' class='dropdown-item'>
            <!-- Message Start -->
            <div class='media'>
              <img src='../dist/img/".$img."' alt='User Avatar' class='img-size-50 mr-3 img-circle'>
              <div class='media-body'>
                <h3 class='dropdown-item-title'>
                  ".$row_users->firstname." ".$row_users->lastname."                  
                </h3>
                <p class='text-sm'>E:".$row_users->email."</p>
                <p class='text-sm'>P:".$row_users->phonenumber.", ".$row_users->phonenumber2."</p>
                <p class='text-sm'>T:".$row_users->department."</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class='dropdown-divider'></div>";
  }while($row_users=$result_users->fetchObject());}
         
 echo "</li>
      
    </ul>
    <!-- Right navbar links -->
    <ul class='navbar-nav ml-auto'>
    
      <!-- Notifications Dropdown Menu -->
      <li class='nav-item dropdown'>
        <a class='nav-link' data-toggle='dropdown' href='#'>
          <i class='far fa-user'></i>
        </a>
        <div class='dropdown-menu dropdown-menu-lg dropdown-menu-right'>
          <a href='edit_profile.php' class='dropdown-item'>
            <i class='fas fa-users mr-2'></i> User profile
          </a>
          <div class='dropdown-divider'></div>
          <a href='../logout.php' class='dropdown-item'>
            <i class='fas fa-arrow-right mr-2'></i> Log Out
          </a>
          <div class='dropdown-divider'></div>
          
          <div class='dropdown-divider'></div>
          <a href='#' class='dropdown-item dropdown-footer'>Settings</a>
        </div>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class='main-sidebar sidebar-dark-primary elevation-4'>
    <!-- Brand Logo -->
    <a href='index.php' class='brand-link'>
      <img src='../dist/img/AdminLTELogo.png' alt='AdminLTE Logo' class='brand-image img-circle elevation-3'
           style='opacity: .8'>
      <span class='brand-text font-weight-light'>KCW SACCO</span>
    </a>";

$result_users=$dbh->query("select * from users where rolenumber='$rolenumber'");
$row_users=$result_users->fetchObject();

  if(!empty($row_users->img)){$img=$row_users->img;}
else{$img="avatar.png";}

echo "    <!-- Sidebar -->
    <div class='sidebar'>
      <!-- Sidebar user panel (optional) -->
      <div class='user-panel mt-3 pb-3 mb-3 d-flex'>
        <div class='image'>
          <img src='../dist/img/".$img."' class='img-circle elevation-2' alt='User Image'>
        </div>
        <div class='info'>
          <a href='edit_profile.php' class='d-block'>".$_SESSION["firstname"]." ".$_SESSION["lastname"]."<br><span style=color:#ffffff>[".$_SESSION['fulltitle']."]</span></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class='mt-2'>
        <ul class='nav nav-pills nav-sidebar flex-column' data-widget='treeview' role='menu' data-accordion='false'>
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->";

$role=$_SESSION["role"];
$rolenumber=$_SESSION["rolenumber"];
$result_menutable=$dbh->query("select * from menu where role like '%$role%' and type='' order by itemorder asc");
$row_menutable=$result_menutable->fetchObject();
$count_menutable=$result_menutable->rowCount();

if($count_menutable>0){ do{
if(substr($_SERVER['REQUEST_URI'],6)==$row_menutable->link){$act="active";}
else{$act='';}  
$result_menutablex=$dbh->query("select * from menu where role like '%$role%' and type='$row_menutable->link' order by itemorder asc");
$row_menutablex=$result_menutablex->fetchObject();
$count_menutablex=$result_menutablex->rowCount();
if($count_menutablex>0){ 
if(substr($_SERVER['REQUEST_URI'],6)==$row_menutablex->link){$acti="active";}
else{$acti='';}    
echo "<li class='nav-item has-treeview'>
<a href='#' class='nav-link active'><i class='nav-icon fas fa-tachometer-alt'></i>
<p>".$row_menutable->item."<i class='right fas fa-angle-left'></i></p></a>
<ul class='nav nav-treeview'>";
do{echo "<li class='nav-item'>
<a href='".$row_menutablex->link."' class='nav-link ".$acti."'><p>
<i class='far fa-".$row_menutablex->img."' style='color:".$row_menutablex->color."'></i>&nbsp".$row_menutablex->item."</p></a></li>";
}while($row_menutablex=$result_menutablex->fetchObject());
echo "</ul></li>";}
else{echo "<li class='nav-item has-treeview menu-open'>
<a href=".$row_menutable->link." class='nav-link ".$act."'>
<i class='nav-icon fas fa-".$row_menutable->img."' style='color:".$row_menutable->color."'></i>
<p>".$row_menutable->item."</p></a></li>";}
}while($row_menutable=$result_menutable->fetchObject());}
          
          echo "</ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->

  </aside>
    <!-- Content Wrapper. Contains page content -->
  <div class='content-wrapper'>
    <div class='content-header'>
      <div class='container-fluid'>";
 }
 function lscripts(){
 echo "  </div></div></div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->

  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class='main-footer'>
    <strong>Copyright &copy; ".date("Y")." 
    <div class='float-right d-none d-sm-inline-block'>
      <b>Kingline Press LTD</b>
    </div>
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src='../plugins/jquery/jquery.min.js'></script>
<!-- Bootstrap -->
<script src='../plugins/bootstrap/js/bootstrap.bundle.min.js'></script>
<!-- overlayScrollbars -->
<script src='../plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js'></script>
<!-- AdminLTE App -->
<script src='../dist/js/adminlte.js'></script>

<!-- OPTIONAL SCRIPTS -->
<script src='dist/js/demo.js'></script>

<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src='../plugins/jquery-mousewheel/jquery.mousewheel.js'></script>
<script src='../plugins/raphael/raphael.min.js'></script>
<script src='../plugins/jquery-mapael/jquery.mapael.min.js'></script>
<script src='../plugins/jquery-mapael/maps/world_countries.min.js'></script>
<!-- ChartJS -->
<script src='../plugins/chart.js/Chart.min.js'></script>

<!-- PAGE SCRIPTS -->
<script src='../dist/js/pages/dashboard2.js'></script>
<script src='../plugins/jquery/jquery.min.js'></script>
<script src='../plugins/moment/moment.min.js'></script>
<script src='../plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js'></script>
<script type='text/javascript' src='../js/bootstrap-datetimepicker.js' charset='UTF-8'></script>
<script type='text/javascript'>
    $('.form_datetime').datetimepicker({
        //language:  'fr',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        forceParse: 0,
        showMeridian: 1,
        hours12: true
    });
    $('.form_date').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: 2,
        forceParse: 0
    });
    $('.form_time').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 1,
        minView: 0,
        maxView: 1,
        hours12: true,
        forceParse: 0,
    });



</script>
";

 }
//useractivity
$ip_ad=$_SERVER['REMOTE_ADDR'];
if(isset($_SERVER['HTTP_REFERER'])){$previouspage=$_SERVER['HTTP_REFERER'];}
else{$previouspage='';}
$currentpage=$_SERVER['SCRIPT_NAME'];
$kbrowser=$_SERVER['HTTP_USER_AGENT'];
$insertactivity = $dbh->exec("insert into useractivity 
    (activity,browser,previouspage,deviceid,userid,currentpage) 
values('On page','$kbrowser','$previouspage','$ip_ad','$rolenumber','$currentpage')");
//useractivity
//my classes
function getSavings($status)
{
   include("connect.php");
$result_savings=$dbh->query("select sum(amount) from savings where status='$status'");
$count_savings=$result_savings->rowCount();
if ($count_savings>0) { $rowsavings=$result_savings->fetch(); }
else{ $rowsavings='0'; }
$totalsum=$rowsavings['0'];   
return $totalsum;
}
//total savings
function getShares($status)
{
   include("connect.php");
$result_savings=$dbh->query("select sum(amount) from shares where status='$status'");
$count_savings=$result_savings->rowCount();
if ($count_savings>0) { $rowsavings=$result_savings->fetch(); }
else{ $rowsavings='0'; }
$totalsum=$rowsavings['0'];   
return $totalsum;
}
//last saved on
function lastSavedOn()
{
include("connect.php");
$result_savings=$dbh->query("select * from savings where owner='$rolenumber' order by autoid desc limit 1");
$count_savings=$result_savings->rowCount();
$row_savings=$result_savings->fetchObject();
if($count_savings>0){$lastsavedon=$row_savings->datepaid;}
else{$lastsavedon="No Savings Made Yet";} 
return $lastsavedon;
}
//count members
function countMembers(){
include("connect.php");
$result_users=$dbh->query("select * from users where role!='tech'");
$count_users=$result_users->rowCount();
return $count_users;
}
//count all tables
function countTables($tbl,$status){
include("connect.php");
$result_table=$dbh->query("select * from $tbl where status='$status'");
$count_table=$result_table->rowCount();
return $count_table;
}
//get loan by id
function getLoanById($loanid)
  {
include("connect.php");    
$result_loans=$dbh->query("select * from loans where loanid='$loanid'");
$count_loans=$result_loans->rowCount();
$row=$result_loans->fetchObject();
if($count_loans>0){
$result_owner=$dbh->query("select * from users where rolenumber='$row->owner'");
$row=$result_owner->fetchObject();
}
return $row;
  }


?>