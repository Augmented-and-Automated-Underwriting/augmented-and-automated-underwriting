<?php
require_once('kfunctions.php');
require_once('../dist/js/fpdf/fpdf.php');
require_once ('../dist/js/fpdf/rotation.php');


class PDF extends PDF_Rotate
{
	function Header()
	{
		//Put the watermark
		//$this->SetFont('Arial','B',50);
		//$this->SetTextColor(255,192,203);
		//$this->RotatedText(65,190,'A p p r o v e d',45);
	}
	function RotatedText($x, $y, $txt, $angle)
	{
		//Text rotated around its origin
		$this->Rotate($angle,$x,$y);
		$this->Text($x,$y,$txt);
		$this->Rotate(0);
	}
}

if (isset($_GET['loanid'])) {
        $loanid = $_GET['loanid'];    
    }

//$pdf = new FPDF();
$pdf=new PDF();
$pdf->AddPage();



$iubat='KCW SACCO' ;				

		
		
//$pdf->Image('assets/brac.jpg',10,15,17);

$pdf->Ln();
$pdf-> Cell(20);
$pdf->SetFont('Times','',12);
$pdf->Write(4,'KCW SACCO<br> Together We Can');
$pdf->Ln();
$pdf-> Cell(20);
$pdf->SetFont('Times','',12);
$pdf->Write(4, 'P.O BOX 1234, kampala');
$pdf->Ln();
$pdf-> Cell(20);
$pdf->SetFont('Times','',12);
$pdf->Write(4,'Phone: 0703301150, Email:kcwsacco.com');
$pdf->Ln();
$pdf-> Cell(20);
$pdf->SetFont('Times','',12);
$pdf->Write(4,'Web: www.kcwsacco.com');
$pdf-> Cell(20);
$pdf->SetFont('Times','',8);
$pdf->Write(5, '__________________________________________________________________________________________________________________________________');
$pdf->Ln();
$pdf->Ln();

$pdf-> Cell(85);
$pdf->SetFont('Times','U',12);
$pdf->Write(5, 'Member Loan Application Report');
$pdf->Ln();

$pdf->Ln(2);			


			 $row=getLoanById($loanid);
				$pdf-> Cell(5);
				$pdf->SetFont('Times','',14);
				$pdf->Cell(60,10,'Name ', 1);
				$pdf->Cell(80,10,$row['owner'], 1);
				$pdf->Ln();

				$pdf-> Cell(5);
				$pdf->Cell(60,10,'Expected Loan', 1);
				$pdf->Cell(80,10,$row['expected_loan']." Shs", 1);
				$pdf->Ln();

				$pdf-> Cell(5);
				$pdf->Cell(60,10,'Loan percentage', 1);
				$pdf->Cell(80,10,$row['loan_percentage']." %", 1);
				$pdf->Ln();

				$pdf-> Cell(5);
				$pdf->Cell(60,10,'Total Loan', 1);
				$pdf->Cell(80,10,$row['total_loan']." Shs", 1);
				$pdf->Ln();

				$pdf-> Cell(5);
				$pdf->Cell(60,10,'Installments', 1);
				$pdf->Cell(80,10,$row['installments'], 1);
				$pdf->Ln();


				$pdf-> Cell(5);
				$pdf->Cell(60,10,'EMI', 1);
				$pdf->Cell(80,10,$row['emi_loan']." Shs/month", 1);
				$pdf->Ln();
				// $pdf->Cell(80,20,'National ID',1);
				// $pdf->Cell(80,20,'Mobile',1);
				// $pdf->Cell(80,20,'Date of Birth',1);
				// $pdf->Cell(80,20,'Total Loan',1);
				// $pdf->Cell(80,20,'EMI',1);
				// $pdf->Cell(80,20,'Status',1);
				// $pdf->Ln();
				
    		// 			$pdf-> Cell(5);
						// $pdf->SetFont('Times','',14);
						// $pdf->Cell(30,20,'Name ', 1);
						// $pdf->Cell(80,20,'National ID',1);
						// $pdf->Cell(80,20,'Mobile',1);
						// $pdf->Cell(80,20,'Date of Birth',1);
						// $pdf->Cell(80,20,'Total Loan',1);
						// $pdf->Cell(80,20,'EMI',1);
						// $pdf->Cell(80,20,'Status',1);
						// $pdf->Ln();
                
		
$pdf->Ln();
$pdf->Ln();		
$pdf->Output();
