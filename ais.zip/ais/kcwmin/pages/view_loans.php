<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php kheader(); ?>
<style type="text/css">
table{width: 100%;border-collapse: collapse;background:  }
tr:nth-of-type(odd){background: #eee;}th{background: #333;color: #ffffff;font-weight: bold;}td, th{padding: 6px;border:1px solid #ccc;text-align: left;}
@media
only screen and (max-width: 760px),
(min-device-width:768px) and (max-device-width:1024px ){
table,thead,tbody,th,td,tr{display: block;}
thead tr{position: absolute;top: -9999px;left: -9999px;}
tr{border: 1px solid #ccc; }
td{border: none;border-bottom: 1px solid #eee;position: relative;padding-left: 50%;}
td:before{position: absolute;top:6px;left: 6px;width: 45%;padding-right: 10px;white-space: nowrap;}
td:nth-of-type(1):before{content: "No";}
td:nth-of-type(2):before{content: "Date Paid";}
td:nth-of-type(3):before{content: "Owner";}
td:nth-of-type(4):before{content: "Payment Method";}
td:nth-of-type(5):before{content: "Ammount Paid";}
td:nth-of-type(6):before{content: "Approver";}
} 
</style> 
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed"> 
<?php kleftbar(); ?>
<div class="container-fluid">
<div class="row mb-2"><div class="col-sm-6"><h5><b>Manage Loans</b></h5></div>
<div class="col-sm-6"><ol class="breadcrumb float-sm-right">
<li class="breadcrumb-item"><a href="index.php">Home</a></li>
</ol></div></div></div>
<div class="col-lg-12"><div class="card">
<div class="card-header d-flex p-0">
<h3 class="card-title p-3"><b>Approve & View Loans</b></h3>
<ul class="nav nav-pills ml-auto p-2">
<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Pending Loans</a></li>
<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Approved Loans</a></li>
</ul></div>
<div class="card-body">
  <?php
if(isset($_POST['approve_loan'])){
  $loanid=$_POST['loanid'];
  $approve_loan=$dbh->query("UPDATE loans SET status='1', approver='$rolenumber', apprdate='$today' WHERE loanid='$loanid'");
  if($approve_loan){echo "<div class='alert alert-success'>Loan Details Approved</div>";}
}
 ?>
<div class="tab-content">
<div class="tab-pane active" id="tab_1" style="overflow-y: scroll;height:450px;">
<table id="example">
<thead><tr>
<th>No</th>
<th>Name</th>
<th>Nin</th>
<th>Mobile</th>
<th>Expected Loan</th>
<th>Percentage</th>
<th>Installments</th>
<th>Total Loan</th>
<th>EMI</th>
<th>Verification</th>
</tr></thead>
<?php
$role=$_SESSION['role'];
$result_loans=$dbh->query("select * from loans where status=0 order by autoid asc");
$row_loans=$result_loans->fetchObject();
$count_loans=$result_loans->rowCount();
if($count_loans>0){$r=1; do{
$result_ownner=$dbh->query("select * from users where rolenumber='$row_loans->owner'");
$row_owner=$result_ownner->fetchObject();  
echo"
<tr>
<td>".$r++."</td>
<td>".$row_owner->firstname."".$row_owner->lastname."</td>
<td>".$row_owner->nin_number."</td>
<td>".$row_owner->phonenumber."</td>
<td><span style='color:maroon'>".number_format($row_loans->expected_loan)."</span></td>
<td>".$row_loans->loan_percentage."</td>
<td>".$row_loans->installments."</td>
<td><span style='color:maroon'>".number_format($row_loans->total_loan)."</span></td>
<td><span style='color:maroon'>".number_format($row_loans->emi_loan)."</span> shs/month</td><td>"; ?>
<form method='post' onsubmit="return loan_checker('Loan','Verified');">
<?php
if($role=='tech' || $role=='xc'){  
echo"
<input type='hidden' name='loanid' value='".$row_loans->loanid."'>
<input type='submit' name='approve_loan' class='btn btn-sm btn-success' value='Approve'>"; }else{echo "<label class='badge badge-warning'>Pending</label>";}echo"</form></td></tr>";
}while($row_loans=$result_loans->fetchObject());} ?>
</table>
</div>
<div class="tab-pane" id="tab_2" style="overflow-y: scroll;height:450px;">
<table id="example" >
<thead><tr>
<th>No</th>
<th>Approved On</th>
<th>Name</th>
<th>Nin</th>
<th>ExpectedLoan</th>
<th>Percentage</th>
<th>Inst</th>
<th>TotalLoan</th>
<th>EMI</th>
<th>Report</th>
<th>Status</th>
</tr></thead>
<tbody>
<?php
$role=$_SESSION['role'];
$result_loans=$dbh->query("select * from loans where status=1 order by autoid asc");
$row_loans=$result_loans->fetchObject();
$count_loans=$result_loans->rowCount();
if($count_loans>0){$r=1; do{
$result_ownner=$dbh->query("select * from users where rolenumber='$row_loans->owner'");
$row_owner=$result_ownner->fetchObject();  
echo"
<tr>
<td>".$r++."</td>
<td>".datediff($row_loans->apprdate,$today)."</td>
<td>".$row_owner->firstname."".$row_owner->lastname."</td>
<td>".$row_owner->nin_number."</td>
<td><span style='color:maroon'>".number_format($row_loans->expected_loan)."</span></td>
<td>".$row_loans->loan_percentage."</td>
<td>".$row_loans->installments."</td>
<td><span style='color:maroon'>".number_format($row_loans->total_loan)."</span></td>
<td><span style='color:maroon'>".number_format($row_loans->emi_loan)."</span> shs/month</td>
<td><a target='_blank' href='loan_report.php?loanid=".$row_loans->loanid."'>report</a></td>
<td><label class='badge badge-success'>Approved</label></td>
</tr>";
}while($row_loans=$result_loans->fetchObject());} ?>
</table>
</div></div></div></div></div>      
<script>
function loan_checker(names, act){
var confirmer=confirm(names+" Will  Be "+act+" Click Ok; To Confirm ");
if(confirmer==false){return false;} }
</script> 
<?php lscripts(); ?>
</body>
</html>
