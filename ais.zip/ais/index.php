<!DOCTYPE html>
<html lang="en">
<head>
<?php
include("pages/connect.php");
$result_scraptitle = $dbh->query("select * from scrap where type='title'");
$row_scraptitle  = $result_scraptitle->fetchObject();
echo "<title>".$row_scraptitle->item."</title>";
?>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="logins/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="logins/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="logins/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="logins/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="logins/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="logins/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="logins/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="logins/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="logins/css/util.css">
	<link rel="stylesheet" type="text/css" href="logins/css/main.css">
<!--===============================================================================================-->
</head>
<body>

<div class="limiter">
<div class="container-login100">
<div class="wrap-login100">
<?php
	 session_start();
if(isset($_POST["login_user"])){
include("pages/connect.php");
$mypassword=$_POST["mypassword"];
$myusername=$_POST["myusername"];
$status='1';
$currentdate=date("Y-m-d");
$result_users=$dbh->prepare("select * from keyfields where password=:passd and username=:usern and pswdexpiry>='$currentdate' and status=:stat  order by autoid desc limit 1");
$result_users->bindParam(':passd', $mypassword);
$result_users->bindParam(':usern', $myusername);
$result_users->bindParam(':stat', $status);
$result_users->execute();
$row_users=$result_users->fetchObject();
$count_users=$result_users->rowCount();

if($count_users>0){
    $result_use=$dbh->query("select * from users where rolenumber='$row_users->rolenumber' and autoid>0");
    $row_use=$result_use->fetchObject();
$_SESSION["username"] = $row_users->username; 
$_SESSION["firstname"]= $row_use->firstname;
$_SESSION["lastname"]= $row_use->lastname;
$_SESSION["role"] = $row_use->role;
$_SESSION["rolenumber"] = $row_users->rolenumber;
$_SESSION["fulltitle"] = $row_use->fulltitle;
$_SESSION["branch"] = $row_use->branch;



echo "<div class='alert alert-success' style='text-align:center'>Access Granted.</div>";
?>
<script>
var allowed=function(){window.location='pages/';}
setTimeout(allowed,1000);
</script>
<?php
}else{echo "<div class='alert alert-danger' style='text-align:center'>Authenication failed. </div>";}
        }
?>
<?php        
if(isset($_POST["signup_user"])){
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$phone1=$_POST["phone1"];
$email=$_POST["email"];
$title="cls";
$address=$_POST["address"];
$work_status=$_POST["work_status"];
$gender=$_POST['gender'];
$dob=$_POST['dob'];
$nin_number=$_POST['nin_number'];
$branch=$_POST['branch'];
$marital=$_POST['marital'];
$username=strtolower(substr($lname, 0,1).$fname);
$password=$phone1;
$datefrom=date("Y-m-d");
$dateto=date("Y-m-d", strtotime( $datefrom." +12 month" ));
$result_user2=$dbh->query("select * from users order by autoid desc");
$row_user2=$result_user2->fetchObject();
$theno=$row_user2->autoid+1;
$rolenumber=$title.$theno;
$result_scrap=$dbh->query("select * from scrap where item2='$title' and type='role'");
$row_scrap=$result_scrap->fetchObject();
$result_nin=$dbh->query("select * from users where nin_number='$nin_number' and email='$email'");
$count_nin=$result_nin->rowCount();
if ($count_nin<=0) {
$insert_pwdexpiry=$dbh->exec("insert into keyfields (rolenumber,password,username,pswdexpiry,status) values('$rolenumber','$password','$username','$dateto','0')");
$insert_users=$dbh->prepare("insert into users (role,firstname,lastname,phonenumber,nin_number,email,username,status,rolenumber,address,occupation,gender,fulltitle,dbirth,branch,marital) values('$title','$fname','$lname','$phone1','$nin_number','$email','$username','0','$rolenumber','$address','$work_status','$gender','$row_scrap->item','$dob','$branch','$marital')");
$insert_users->execute();
echo "<div class='alert alert-success' style='text-align:center'>Success:Account Pending Approval.</div>";
}else{
echo"<div class='alert alert-success' style='text-align:center'>Account Not Registered.</div>";
}
}
?>	
<div  id="company">
<form method="post" autocomplete="off">
<span class="login100-form-title p-b-30" style="font-size: 20px">Welcome To <br><i style="font-size: 30px;font-weight: bold;color: #000000"><?php echo $row_scraptitle->item; ?></i></span>
<span class="login100-form-title p-b-48"><img src="logins/images/logo.png" width="90px" height="90px"></span>
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="myusername" placeholder="Enter Username"></div>
<div class="wrap-input100 validate-input">
<input class="input100" type="password" name="mypassword" placeholder="Enter Password"></div>
<div class="container-login100-form-btn">
<div class="wrap-login100-form-btn"><div class="login100-form-bgbtn"></div>
<button class="login100-form-btn" type="submit" name="login_user">Sign In</button></div></div>
<div class="text-center p-t-40">
<span onClick='show_pan()' style="cursor: pointer;font-size: 14px;font-weight: bold;color: #00000">Don’t have an account?Sign Up</span></div>
<div class="text-center p-t-20">					
<a class="login100-form-title" style="font-size: 12px;font-weight">Developed By BSSE22-13</a></div>					
</form></div>
<div style='width:100%;display: none;overflow-y: scroll;height:600px' id='pan'>
<form method='post' autocomplete="off">
<span class="login100-form-title" style="font-size: 20px">User Registration</span>		
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="fname">
<span class="focus-input100" data-placeholder="Firstname"></span></div>
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="lname">
<span class="focus-input100" data-placeholder="Lastname"></span></div>
<div class="wrap-input100 validate-input">
<input class="input100" type="email" name="email">
<span class="focus-input100" data-placeholder="Email"></span></div>
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="phone1">
<span class="focus-input100" data-placeholder="Phone1"></span></div>
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="nin_number">
<span class="focus-input100" data-placeholder="Nin Number/Valid Id"></span></div>
<div class="wrap-input100 validate-input">
<label>DOB</label>	
<input class="input100" type="date" name="dob">
<span class="focus-input100"></span></div>
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="address">
<span class="focus-input100" data-placeholder="Address"></span></div>
<div class="wrap-input100 validate-input">
	<label>Nearest Branch</label>
<select class="input100" name="branch" >
<option value="">Select</option>
<?php
$result_scrapws=$dbh->query("select * from scrap where type='branch'");
$count_scrapws=$result_scrapws->rowCount();
$row_scrapws=$result_scrapws->fetchObject();
if($count_scrapws){do{
echo "<option value='".$row_scrapws->item."'>".$row_scrapws->item2."</option>";  
}while($row_scrapws=$result_scrapws->fetchObject());}
?>
</select>
</div>
<div class="wrap-input100 validate-input">
	<label>Gender</label>
<select class="input100" name="gender">
<option>Select</option>  
<option value="Male">Male</option>
<option value="Female">Female</option></select>
</div>
<div class="wrap-input100 validate-input">
<label>Marital Status</label>
<select class="form-control" name="marital">
<option value="S">Single</option>
<option value="M">Married</option>
<option value="D">Divorced</option>  
</select> 
</div>
<div class="wrap-input100 validate-input">
<input class="input100" type="text" name="work_status">
<span class="focus-input100" data-placeholder="Occupation"></span></div>
<div class="wrap-login100-form-btn"><div class="login100-form-bgbtn"></div>
<button class="login100-form-btn" type="submit" name="signup_user">Sign Up</button></div>
<div class="text-center p-t-40">
<span class="txt1" onClick='show_login()' style="cursor: pointer;">Aready Amember?Sign In</span></div>
</form></div></div></div></div>
<script>
function show_pan(){
$("#pan").show();
$("#company").hide();
}
function show_login(){
$("#company").show();
$("#pan").hide();
}
</script>
<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
<script src="logins/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="logins/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="logins/vendor/bootstrap/js/popper.js"></script>
	<script src="logins/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="logins/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="logins/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="logins/js/main.js"></script>

</body>
</html>